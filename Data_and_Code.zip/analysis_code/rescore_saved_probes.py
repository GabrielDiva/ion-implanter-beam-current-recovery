# -*- coding: utf-8 -*-
"""Threshold sensitivity from saved probes only. No optimization or refitting."""
from pathlib import Path
import json,sys,hashlib,os
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
OLD=Path(os.environ.get('REFINELAB_PREVIOUS_ANALYSIS',str(ROOT)))
SRC=Path(os.environ.get('REFINELAB_FILTERED_ARCHIVE',str(ROOT/'private_filtered_archive')))
OUT=Path(os.environ.get('REFINELAB_TOLERANCE_OUT',str(ROOT/'recomputed_tolerance')))
AN=OUT/'analysis';AN.mkdir(exist_ok=True,parents=True)
sys.path.insert(0,str(Path(__file__).resolve().parent))
from archive_common import block_intervals
E=json.loads((OLD/'analysis/paper_evidence.json').read_text(encoding='utf-8'))
TOLS=[.02,.03,.05,.07]

def main():
    sys.stdout.reconfigure(encoding='utf-8')
    f=pd.read_csv(SRC/'refinelab_v40_frozen_tasks.csv',usecols=['task_id','machine_id','source_order','target_beam','initial_beam'])
    f=f.set_index('task_id');assert len(f)==12096 and f.machine_id.ne(0).all()
    initial=((f.initial_beam-f.target_beam).abs()/f.target_beam).to_numpy()
    lookup={x:i for i,x in enumerate(f.index)}
    results=[];details=[];frames={};checks=[]
    for label,name in E['configuration_sources'].items():
        s=pd.read_csv(SRC/name,usecols=['task_id','success','total_probes','total_rounds','first_success_probe','target']).set_index('task_id').reindex(f.index)
        assert s.success.notna().all()
        first=np.full((len(f),len(TOLS)),np.inf);rounds=first.copy()
        for j,t in enumerate(TOLS):
            q=initial<=t+1e-12;first[q,j]=0;rounds[q,j]=0
        counts=np.zeros(len(f),dtype=int);best=initial.copy()
        file=SRC/name.replace('_summary.csv','_summary_probes.csv')
        for g in pd.read_csv(file,usecols=['task_id','probe_index','round_index','beam','target'],chunksize=160000):
            assert g.target.gt(0).all()
            idx=g.task_id.map(lookup).to_numpy();assert not pd.isna(idx).any()
            idx=idx.astype(int);p=g.probe_index.to_numpy();r=g.round_index.to_numpy()
            err=np.abs(g.beam.to_numpy()-g.target.to_numpy())/g.target.to_numpy()
            np.add.at(counts,idx,1);np.minimum.at(best,idx,err)
            for j,t in enumerate(TOLS):
                q=err<=t+1e-12
                # A chronological minimum is enough because each task has one
                # probe index per action; round index is monotone with it.
                np.minimum.at(first[:,j],idx[q],p[q]);np.minimum.at(rounds[:,j],idx[q],r[q])
        assert np.array_equal(counts,s.total_probes.to_numpy())
        hit=np.isfinite(first)
        assert np.array_equal(hit[:,2],s.success.to_numpy())
        assert np.array_equal(first[hit[:,2],2],s.loc[s.success,'first_success_probe'].to_numpy())
        d=f.copy();d['configuration']=label;d['original_success_5']=s.success;d['original_probes']=s.total_probes;d['original_rounds']=s.total_rounds;d['best_relative_error_observed']=best
        for j,t in enumerate(TOLS):
            suffix=str(round(100*t));d['hit_'+suffix]=hit[:,j];d['first_probe_'+suffix]=np.where(hit[:,j],first[:,j],np.nan);d['first_round_'+suffix]=np.where(hit[:,j],rounds[:,j],np.nan)
            # Stricter endpoints are censored by the original ±5% success stop.
            censored=(~hit[:,j])&s.success.to_numpy() if t<.05 else np.zeros(len(f),bool)
            d['success_stop_censored_'+suffix]=censored
            results.append(dict(configuration=label,tolerance=t,n=len(f),observed_hits=int(hit[:,j].sum()),
                observed_attainment=float(hit[:,j].mean()),initially_qualified=int((first[:,j]==0).sum()),
                mean_first_probe=float(first[hit[:,j],j].mean()),mean_first_round=float(rounds[hit[:,j],j].mean()),
                unresolved_success_stop_censored=int(censored.sum()),
                attainment_if_all_success_stop_censored_eventually_hit=float((hit[:,j]|censored).mean()),
                interpretation='Observed stopped-trajectory attainment; stricter-policy success is unobserved' if t<.05 else 'First-hit rescoring of the recorded policy prefix'))
        frames[label]=d;details.append(d.reset_index())
        checks.append(dict(configuration=label,summary_tasks=len(s),probe_rows=int(counts.sum()),success_5_reproduced=True,task_ID0_present=False,probe_sha256=hashlib.sha256(file.read_bytes()).hexdigest()))
        print(label,dict(zip([2,3,5,7],np.round(hit.mean(axis=0)*100,3))),flush=True)
    pd.DataFrame(results).to_csv(AN/'tolerance_results.csv',index=False,encoding='utf-8-sig')
    pd.concat(details,ignore_index=True).to_csv(AN/'per_task_tolerance_rescoring.csv',index=False,encoding='utf-8-sig')
    paired=[]
    for a,b in [('PSO_Res','BO'),('RF_Res','BO'),('RF_Res','PSO_Res'),('PSO_Res','PSO_None'),('RF_Res','RF_None')]:
        z=f[['machine_id','source_order']].copy()
        for t in [2,3,5,7]:z['diff_'+str(t)]=frames[a]['hit_'+str(t)].astype(int)-frames[b]['hit_'+str(t)].astype(int)
        ci=block_intervals(z,['diff_'+str(t) for t in [2,3,5,7]])
        for t in [2,3,5,7]:
            col='diff_'+str(t);paired.append(dict(method=a,baseline=b,tolerance=t/100,n=len(z),
              difference=float(z[col].mean()),ci_low=ci[col][0],ci_high=ci[col][1],
              interval_scope='Conditional observed-prefix attainment; omits simulator error and stopping counterfactual'))
    pd.DataFrame(paired).to_csv(AN/'tolerance_paired_contrasts.csv',index=False,encoding='utf-8-sig')
    equipment=[]
    a,b=frames['RF_Res'],frames['PSO_Res']
    for mid,g in f.groupby('machine_id'):
        aa,bb=a.loc[g.index],b.loc[g.index];both=aa.hit_5&bb.hit_5
        equipment.append(dict(equipment=int(mid),n=len(g),RF_success=int(aa.hit_5.sum()),XGB_success=int(bb.hit_5.sum()),
           RF_success_rate=float(aa.hit_5.mean()),XGB_success_rate=float(bb.hit_5.mean()),
           success_gain_pp=float(100*(aa.hit_5.mean()-bb.hit_5.mean())),common_successes=int(both.sum()),
           paired_measurement_difference=float((aa.loc[both,'first_probe_5']-bb.loc[both,'first_probe_5']).mean())))
    eq=pd.DataFrame(equipment);eq.to_csv(AN/'RF_vs_XGB_by_equipment.csv',index=False,encoding='utf-8-sig')
    report=dict(tasks=12096,equipment_groups=len(eq),configurations=17,
       rf_equipment_improved=int(eq.success_gain_pp.gt(1e-10).sum()),rf_equipment_declined=int(eq.success_gain_pp.lt(-1e-10).sum()),
       rf_equipment_tied=int(eq.success_gain_pp.abs().le(1e-10).sum()),rf_gain_min_pp=float(eq.success_gain_pp.min()),
       rf_gain_max_pp=float(eq.success_gain_pp.max()),rf_worst_group=int(eq.loc[eq.success_gain_pp.idxmin(),'equipment']),
       initial_qualified_7=int((initial<=.07+1e-12).sum()),all_tolerance_curves_monotone=True,
       source_policy_stop_tolerance=.05,strict_tolerance_counterfactual_rerun=False,
       simulator_uncertainty_resolved_by_threshold_analysis=False,new_training_or_replay=False)
    (AN/'sensitivity_evidence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (AN/'rescore_integrity.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
