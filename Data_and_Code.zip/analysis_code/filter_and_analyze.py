# -*- coding: utf-8 -*-
"""Create a coherent publication cohort from existing outputs. No training/replay."""
from pathlib import Path
import pandas as pd
import numpy as np
import json,hashlib,sys,shutil
from archive_common import RUNS,SRC,OUT,block_intervals

BASE=Path(__file__).resolve().parent.parent
PRIVATE=OUT/'private_filtered_archive'
AN=OUT/'analysis'

def filter_csv(source,dest,ids):
    # Read strings so the archived numeric and JSON field values are not rounded/recomputed.
    first=True;before=after=0
    for chunk in pd.read_csv(source,dtype=str,keep_default_na=False,chunksize=100000):
        before+=len(chunk);c=chunk[chunk.task_id.isin(ids)];after+=len(c)
        c.to_csv(dest,index=False,mode='w' if first else 'a',header=first,encoding='utf-8' if not first else 'utf-8-sig')
        first=False
    return dict(file=source.name,source_rows=before,retained_rows=after,removed_rows=before-after,
        bytes=dest.stat().st_size,sha256=hashlib.sha256(dest.read_bytes()).hexdigest())

def main():
    sys.stdout.reconfigure(encoding='utf-8')
    PRIVATE.mkdir(parents=True,exist_ok=True);AN.mkdir(parents=True,exist_ok=True)
    f=pd.read_csv(SRC/'refinelab_v40_frozen_tasks.csv');source=f.copy()
    random=~f.initial_state_selection.str.contains('halved')
    ref=f.reference_environment_beam;target=f.target_beam
    valid=(random&f.machine_id.ne(0)&np.isfinite(f.initial_beam)&f.initial_beam.ge(0)
      &np.isfinite(ref)&ref.gt(0)&target.gt(0)&f.initial_beam.lt(.9*ref)
      &(f.initial_beam-target).abs().gt(.05*target))
    bounds=json.loads((BASE/'analysis/paper_evidence.json').read_text(encoding='utf-8'))['parameter_bounds']
    for i,m in enumerate(f.initial_controls_json.map(json.loads)):
        if valid.iloc[i]:assert all(bounds[k][0]-1e-8<=m[k]<=bounds[k][1]+1e-8 for k in bounds)
    assert valid.sum()==12096
    selected=f[valid].set_index('task_id');ids=set(selected.index)
    decision=pd.DataFrame(dict(task_id=f.task_id,equipment_id=f.machine_id,qualifying_random_start=random,
      excluded_ID0=f.machine_id.eq(0),negative_initial=f.initial_beam.lt(0),
      already_qualified=(f.initial_beam-target).abs().le(.05*target),retained=valid))
    decision.to_csv(AN/'task_selection_audit.csv',index=False,encoding='utf-8-sig')
    manifest=[filter_csv(SRC/'refinelab_v40_frozen_tasks.csv',PRIVATE/'refinelab_v40_frozen_tasks.csv',ids)]
    frames={};summary=[];pergroup=[];episodes=[]
    for key,(filename,family,search,adapter) in RUNS.items():
        print('Filtering',key,'summary and probes',flush=True)
        for name in [filename,filename.replace('_summary.csv','_summary_probes.csv')]:
            record=filter_csv(SRC/name,PRIVATE/name,ids);record['configuration']=key;manifest.append(record)
        d=pd.read_csv(PRIVATE/filename).set_index('task_id').reindex(selected.index)
        assert len(d)==12096 and d.success.notna().all() and not d.cancelled.any()
        d['source_order']=selected.source_order;d['charged_probes']=np.where(d.success,d.total_probes,240)
        assert d.machine_id.ne(0).all();frames[key]=d
        tiny=d[['machine_id','success','total_probes','total_rounds','charged_probes','first_success_parameter']].copy()
        tiny['configuration']=key;episodes.append(tiny.reset_index())
        masks=[('main',np.ones(len(d),bool)),('without_ID2',d.machine_id.ne(2)),
               ('reference_in_bounds',d.reference_solution_in_search_space.astype(bool))]
        for cohort,mask in masks:
            g=d[mask];s=g[g.success]
            summary.append(dict(label=key,predictor=family,search=search,adapter=adapter,cohort=cohort,
                n=len(g),groups=g.machine_id.nunique(),success_count=int(g.success.sum()),success=g.success.mean(),
                successful_probes=s.total_probes.mean(),successful_rounds=s.total_rounds.mean(),
                charged_probes=g.charged_probes.mean(),actual_probes=g.total_probes.mean(),
                initialization_success_fraction=g.initialization_success.mean()))
        for mid,g in d.groupby('machine_id'):
            pergroup.append(dict(label=key,group=int(mid),n=len(g),success=g.success.mean(),
                success_count=int(g.success.sum()),successful_probes=g.loc[g.success,'total_probes'].mean(),
                charged_probes=g.charged_probes.mean()))
    pd.DataFrame(summary).to_csv(AN/'configuration_results.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(pergroup).to_csv(AN/'results_by_equipment_label.csv',index=False,encoding='utf-8-sig')
    pd.concat(episodes).to_csv(AN/'episode_metrics.csv',index=False,encoding='utf-8-sig')
    comparisons=[]
    pairs=[('PSO_Res','BO'),('PSO_None','BO'),('PSO_Res','PSO_None'),('PSO_Res','PSO_Cal'),
        ('CMA_Res','CMA_None'),('RS_Res','RS_None'),('RF_Res','RF_None'),('CMA_Res','PSO_Res'),
        ('RS_Res','PSO_Res'),('RF_Res','PSO_Res'),('PSO_WRes','PSO_Res'),('CMA_WRes','CMA_Res'),
        ('RS_WRes','RS_Res'),('RF_WRes','RF_Res')]
    for a,b in pairs:
        left,right=frames[a],frames[b]
        masks=[('main',np.ones(len(left),bool)),('without_ID2',left.machine_id.ne(2)),
            ('reference_in_bounds',left.reference_solution_in_search_space.astype(bool))]
        for cohort,mask in masks:
            aa,bb=left[mask],right[mask]
            z=aa[['machine_id','source_order']].copy();z['success']=aa.success.astype(int)-bb.success.astype(int)
            z['cost']=aa.charged_probes-bb.charged_probes;q=block_intervals(z,['success','cost'])
            both=aa.success&bb.success
            comparisons.append(dict(method=a,baseline=b,cohort=cohort,n=len(aa),success_diff=z.success.mean(),
                success_lo=q['success'][0],success_hi=q['success'][1],cost_diff=z.cost.mean(),
                cost_lo=q['cost'][0],cost_hi=q['cost'][1],common_success_n=int(both.sum()),
                common_success_probe_diff=(aa.loc[both,'total_probes']-bb.loc[both,'total_probes']).mean()))
    pd.DataFrame(comparisons).to_csv(AN/'paired_comparisons.csv',index=False,encoding='utf-8-sig')
    metric=pd.read_csv(SRC/'refinelab_v40_model_metrics.csv')
    # Original global diagnostics cannot be recomputed from filtered task rows.
    metric=metric[~((metric.model_role=='Per-machine SIM')&metric.machine_id.astype(str).eq('0'))].copy()
    metric['training_provenance']='Archived original fits; pooled global training includes ID0; no refit'
    metric.to_csv(AN/'archived_model_metrics.csv',index=False,encoding='utf-8-sig')
    sim=metric[(metric.model_role=='Per-machine SIM')&(metric.estimator=='XGBoost')]
    evidence=dict(primary_tasks=12096,evaluated_equipment_groups=13,paired_method_episodes=12096*17,
        original_input_rows=106522,original_global_history_rows=90544,original_holdout_rows=15978,
        original_training_includes_ID0=True,new_training_or_replay_performed=False,
        original_archived_tasks=len(source),removed_fallback=int((~random).sum()),
        removed_ID0_after_random=int((random&f.machine_id.eq(0)).sum()),
        removed_negative_after_ID0=int((random&f.machine_id.ne(0)&f.initial_beam.lt(0)).sum()),
        removed_qualified_after_previous=int((random&f.machine_id.ne(0)&f.initial_beam.ge(0)&(f.initial_beam-target).abs().le(.05*target)).sum()),
        reference_in_bounds=int(frames['PSO_Res'].reference_solution_in_search_space.sum()),
        weighted_SIM_OOF_MAPE_percent=float(np.average(sim.mape_percent,weights=sim.n_evaluation)),
        sim_OOF_MAPE_min=float(sim.mape_percent.min()),sim_OOF_MAPE_max=float(sim.mape_percent.max()),
        parameter_bounds=bounds,configuration_sources={k:v[0] for k,v in RUNS.items()},
        selection_rule='Qualifying random draw; ID!=0; nonnegative finite initial; 12 controls in bounds; initial <0.9 reference; outside recorded-target +/-5%',
        later_negative_feedback='Preserved and disclosed; no method-specific trajectory deletion or clipping')
    (AN/'paper_evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
    (PRIVATE/'filter_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    # The publication package supplies the original settings under an English alias.
    shutil.copy2(BASE/'control_settings.txt',PRIVATE/'control_settings.txt')
    (OUT/'README_current.txt').write_text('Current publication cohort: 12,096 tasks across 13 evaluated equipment-ID groups.\n'
        'All filtering is based on provenance and pre-action task properties, not policy outcomes.\n'
        'These are archived experiments with post-filtered evaluation; global training still includes ID0.\n'
        'No model was retrained and no replay was rerun. Original external archives were not altered.\n'
        'private_filtered_archive is for local review and is not automatically included in the public supplementary ZIP.\n',encoding='utf-8')
    print(json.dumps(evidence,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':main()
