from pathlib import Path
import os
import numpy as np
import pandas as pd
BASE = Path(__file__).resolve().parents[1]
OUT = Path(os.environ.get('REFINELAB_ANALYSIS_OUT', str(BASE/'recomputed')))
SRC = Path(os.environ.get('REFINELAB_ARCHIVE', str(BASE/'private_source_not_distributed')))
RUNS={
 'BO':('refinelab_v40BO_summary.csv','GP','BO','None'),
 'PSO_None':('refinelab_v40PSO_withoutAdapter_summary.csv','XGB','PSO','None'),
 'PSO_Cal':('refinelab_v40PSOCali_summary.csv','XGB','PSO','Affine'),
 'PSO_Res':('refinelab_v403_summary.csv','XGB','PSO','Residual'),
 'PSO_WRes':('refinelab_v403PSOWR_summary.csv','XGB','PSO','Weighted residual'),
 'CMA_None':('refinelab_v40CMA-None_summary.csv','XGB','CMA-ES','None'),
 'CMA_Cal':('refinelab_v40CMA-Cali_summary.csv','XGB','CMA-ES','Affine'),
 'CMA_Res':('refinelab_v403CMA-ES_summary.csv','XGB','CMA-ES','Residual'),
 'CMA_WRes':('refinelab_v40CMA-WR_summary.csv','XGB','CMA-ES','Weighted residual'),
 'RS_None':('refinelab_v40RandomNone_summary.csv','XGB','Random shooting','None'),
 'RS_Cal':('refinelab_v40RandomCali_summary.csv','XGB','Random shooting','Affine'),
 'RS_Res':('refinelab_v40Random_summary.csv','XGB','Random shooting','Residual'),
 'RS_WRes':('refinelab_v40RS-WR_summary.csv','XGB','Random shooting','Weighted residual'),
 'RF_None':('refinelab_v40RF_None_summary.csv','RF','PSO','None'),
 'RF_Cal':('refinelab_v40RF_Cali_summary.csv','RF','PSO','Affine'),
 'RF_Res':('refinelab_v40RF-R-15188_summary.csv','RF','PSO','Residual'),
 'RF_WRes':('refinelab_v40RF_WR_summary.csv','RF','PSO','Weighted residual')}

def block_intervals(d,columns,reps=4000,block=50):
    """Resample ID groups, then non-overlapping row blocks within each selected group."""
    rng=np.random.default_rng(20261118);groups=[]
    for _,g in d.sort_values('source_order').groupby('machine_id',sort=True):
        a=g[columns].to_numpy(float);n=len(a);labels=np.arange(n)//block
        sums=np.stack([a[labels==k].sum(axis=0) for k in np.unique(labels)]);counts=np.bincount(labels)
        groups.append((sums,counts))
    totals=np.zeros((reps,len(columns)));den=np.zeros(reps)
    sampled=rng.integers(len(groups),size=(reps,len(groups)))
    for slot in range(len(groups)):
        for k,(s,c) in enumerate(groups):
            mask=sampled[:,slot]==k
            if not mask.any():continue
            ix=rng.integers(len(s),size=(int(mask.sum()),len(s)))
            totals[mask]+=s[ix].sum(axis=1);den[mask]+=c[ix].sum(axis=1)
    qs=np.quantile(totals/den[:,None],[.025,.975],axis=0)
    return {c:[float(qs[0,i]),float(qs[1,i])] for i,c in enumerate(columns)}
