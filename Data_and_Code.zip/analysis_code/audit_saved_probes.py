from pathlib import Path
import sys,collections,json
import pandas as pd
import numpy as np
from archive_common import RUNS,OUT
SRC=OUT/'private_filtered_archive'

def main():
    sys.stdout.reconfigure(encoding='utf-8');f=pd.read_csv(SRC/'refinelab_v40_frozen_tasks.csv');ids=set(f.task_id)
    assert len(ids)==12096 and f.machine_id.ne(0).all() and f.initial_beam.ge(0).all()
    assert ((f.initial_beam-f.target_beam).abs()>.05*f.target_beam).all()
    reports=[]
    for key,(file,*_) in RUNS.items():
        s=pd.read_csv(SRC/file,usecols=['task_id','total_probes','success','first_success_probe']).set_index('task_id')
        assert set(s.index)==ids
        counts=collections.Counter();negative=collections.Counter();hits={};total=0
        for g in pd.read_csv(SRC/file.replace('_summary.csv','_summary_probes.csv'),
          usecols=['task_id','probe_index','round_index','beam','target','success'],chunksize=150000):
            assert set(g.task_id).issubset(ids);assert g.round_index.between(1,20).all() and g.probe_index.between(1,240).all()
            assert np.array_equal((g.beam-g.target).abs().le(.05*g.target+1e-8),g.success)
            counts.update(g.task_id);negative.update(g.loc[g.beam.lt(0),'task_id']);total+=len(g)
            for task,probe in g.loc[g.success,['task_id','probe_index']].itertuples(index=False,name=None):
                assert task not in hits;hits[task]=int(probe)
        assert all(counts[k]==int(s.loc[k,'total_probes']) for k in ids)
        assert set(hits)==set(s.index[s.success])
        assert all(hits[k]==int(s.loc[k,'first_success_probe']) for k in hits)
        reports.append(dict(configuration=key,eligible_tasks=12096,probe_records=total,negative_feedbacks=sum(negative.values()),
          tasks_with_negative_feedback=len(negative),negative_feedback_fraction=sum(negative.values())/total,
          summary_count_matches=True,success_markers_match=True))
        print(key,total,'PASS',flush=True)
    pd.DataFrame(reports).to_csv(OUT/'analysis/probe_log_integrity.csv',index=False,encoding='utf-8-sig')

if __name__=='__main__':main()
