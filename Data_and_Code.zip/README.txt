Publication-graphics synchronization, 24 November 2026.
Fig. 1 now uses the author-provided vector Illustrator PDF export.
The PDF/SVG publication copies and quality notes match Figures.zip;
TIFF alternatives are supplied in the separate Figures.zip.
The 12,096-task cohort, numerical results and implementation are unchanged.

Access V1.1 update, 23 November 2026.
Current Figs2/3 are assembled from the author-retained SVG panels; Fig3 uses 3a/3b/3c/3d.
The 12096-task cohort, numerical results and implementation are unchanged.
Current publication graphics and their quality notes are in publication_graphics/.
Legacy V3 images remain source records, not the current publication layout.

IEEE Access V1 adaptation, 22 November 2026.
The original 12096-task results and implementation are unchanged.
access_diagnostics adds descriptive analyses of the same cohort.
Run access_diagnostics/plot_from_aggregates.py to reproduce Fig S2 using only the supplied aggregate CSVs.
diagnostics.py is the author-side source analysis and requires the commercially restricted task and episode archive.
The remaining README text documents the retained experiment archive.

TSM-V2 supplementary aggregate data and code, 19 November 2026
12,096 common tasks; sixteen framework configurations plus one BO comparator.
The original fitted models and recovery runs remain unchanged. Current evaluation
tasks/probes exclude the mixed-provenance group, as documented in selection_manifest.

Main Figure 4:
python plotting/make_fig4_v2.py --published-data figure_data --output recreated_figures
Tolerance Figure S1:
python plotting/make_sensitivity_figure.py
Dependencies: numpy, pandas, matplotlib. Neither command fits models or runs tuning.

analysis/ contains configuration summaries, paired contrasts and original model
diagnostics. figure_data/ contains the Figure 4 data, all threshold rescoring
aggregates, equipment contrasts and a transcription of the early model screen.
The early screen uses MAE, not MAPE; its relative MAE is normalized to XGBoost
within that same preliminary ten-input comparison. Final recovery inputs differ.

Tolerance results are first attainment in saved trajectories stopped at ±5%.
At ±2% and ±3%, the success-stop-censored column identifies unresolved stricter
hits. These are not new complete-policy runs, or a simulator-error validation.
At ±7%, 46 initial states qualify and are counted at zero paid feedback.

implementation_snapshot/ preserves the original implementation for traceability.
analysis_code/ uniformly filters the saved archive, bootstraps paired statistics
and checks probe integrity. For private-source analysis set REFINELAB_ARCHIVE
and REFINELAB_ANALYSIS_OUT as described in analysis_code/archive_common.py.
Model training history and recovery eligibility are distinct. Original source
hashes and filtering metadata remain preserved in the manifests.

To reproduce threshold statistics from the authorized filtered private archive,
set REFINELAB_FILTERED_ARCHIVE to the directory of the 12,096-task frozen file
and seventeen summary/probe pairs. Optionally set REFINELAB_TOLERANCE_OUT, then
run python analysis_code/rescore_saved_probes.py. Its paired bootstrap imports
the distributed archive_common.py. It does not train or run recovery policies.

No proprietary production workbook, individual targets, full task/probe records
or serialized models are included. Figures 2/3 are exploratory SHAP illustrations;
their original fitted models and point arrays are unavailable. The Focus sweeps
reported in the text are qualitative operator observations; scan records are not included in this package.

English-language submission packaging, 24 November 2026.
Figure documentation is named Figure_Quality_Checklist.csv and README_Figures.txt.
The original parameter-settings source is distributed under the public alias
control_settings.txt; its content hash is unchanged. Source paths in diagnostic
metadata are logical aliases rather than author-local directory names.
No model was retrained and no recovery experiment or numerical result was changed.

Author-side archive analysis requires restricted files that are not distributed.
REFINELAB_PUBLICATION_ROOT selects the publication archive for the optional Fig. 4 archive mode.
REFINELAB_ANALYSIS_DIR selects the private analysis tables for access_diagnostics/diagnostics.py.
REFINELAB_FILTERED_ARCHIVE selects the filtered private task archive.
REFINELAB_DIAGNOSTICS_OUT selects the output directory for that source analysis.
The published-data plotting commands above work directly with the supplied aggregate tables.
