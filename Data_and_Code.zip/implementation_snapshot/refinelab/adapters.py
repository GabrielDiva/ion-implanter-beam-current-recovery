from __future__ import annotations

from typing import Any, Optional

import numpy as np

from .models import RegressorFactory


class BeamAdapter:
    def fit_pre(self, X: np.ndarray, y: np.ndarray) -> None:
        return None

    def update(self, X: np.ndarray, y: np.ndarray) -> None:
        return None

    def predict(self, X: np.ndarray) -> np.ndarray:
        raise NotImplementedError

    def clone_for_episode(self) -> "BeamAdapter":
        raise NotImplementedError


class NoAdapter(BeamAdapter):
    def __init__(self, base_model: Any):
        self.base_model = base_model

    def predict(self, X: np.ndarray) -> np.ndarray:
        return np.asarray(self.base_model.predict(X), dtype=float).reshape(-1)

    def clone_for_episode(self) -> "NoAdapter":
        return NoAdapter(self.base_model)


class LinearCalibrator(BeamAdapter):
    def __init__(self, base_model: Any, max_keep: int = 2500):
        self.base_model = base_model
        self.max_keep = max(2, int(max_keep))
        self._pred: list[float] = []
        self._true: list[float] = []
        self.a = 1.0
        self.b = 0.0

    def _trim(self) -> None:
        self._pred = self._pred[-self.max_keep :]
        self._true = self._true[-self.max_keep :]

    def _refit(self) -> None:
        if len(self._pred) < 2:
            return
        x = np.asarray(self._pred, dtype=float)
        y = np.asarray(self._true, dtype=float)
        design = np.column_stack([x, np.ones_like(x)])
        solution, *_ = np.linalg.lstsq(design, y, rcond=None)
        self.a, self.b = map(float, solution)

    def fit_pre(self, X: np.ndarray, y: np.ndarray) -> None:
        pred = np.asarray(self.base_model.predict(X), dtype=float).reshape(-1)
        self._pred = pred.tolist()
        self._true = np.asarray(y, dtype=float).reshape(-1).tolist()
        self._trim()
        self._refit()

    def update(self, X: np.ndarray, y: np.ndarray) -> None:
        pred = np.asarray(self.base_model.predict(X), dtype=float).reshape(-1)
        self._pred.extend(pred.tolist())
        self._true.extend(np.asarray(y, dtype=float).reshape(-1).tolist())
        self._trim()
        self._refit()

    def predict(self, X: np.ndarray) -> np.ndarray:
        base = np.asarray(self.base_model.predict(X), dtype=float).reshape(-1)
        return self.a * base + self.b

    def clone_for_episode(self) -> "LinearCalibrator":
        clone = LinearCalibrator(self.base_model, self.max_keep)
        clone._pred = self._pred.copy()
        clone._true = self._true.copy()
        clone.a = float(self.a)
        clone.b = float(self.b)
        return clone


class ResidualAdapter(BeamAdapter):
    """Cached historical prior plus a small, episode-local online correction.

    The historical residual model is fitted once for each machine/energy cache
    key and remains read-only. Episode clones share that prior safely. New replay
    probes train only a bounded online correction to the prior prediction; the
    full historical A matrix is never refitted after every tuning round.
    """

    def __init__(
        self,
        base_model: Any,
        factory: RegressorFactory,
        weighted: bool = False,
        min_points: int = 8,
        max_keep: int = 2500,
    ):
        self.base_model = base_model
        self.factory = factory
        self.online_factory = RegressorFactory(factory.estimator, factory.seed, profile="online")
        self.weighted = bool(weighted)
        self.min_points = max(2, int(min_points))
        self.max_keep = max(self.min_points, int(max_keep))
        self.max_online_keep = min(256, self.max_keep)
        self._online_X: list[np.ndarray] = []
        self._online_r: list[float] = []
        self.prior_model: Optional[Any] = None
        self.online_model: Optional[Any] = None
        self._online_refit_count = 0

    def _trim(self) -> None:
        self._online_X = self._online_X[-self.max_online_keep :]
        self._online_r = self._online_r[-self.max_online_keep :]

    def _refit_online(self) -> None:
        if len(self._online_X) < self.min_points:
            return
        model = self.online_factory.create(seed_offset=90_000 + self._online_refit_count)
        X = np.asarray(self._online_X, dtype=float)
        residual = np.asarray(self._online_r, dtype=float)
        if self.weighted:
            # Smoothly prioritize later observations without assigning a
            # scientifically opaque giant weight to one replay round.
            model.fit(X, residual, sample_weight=np.linspace(1.0, 2.0, len(residual)))
        else:
            model.fit(X, residual)
        try:
            model.set_params(n_jobs=1)
        except (AttributeError, ValueError):
            pass
        self.online_model = model
        self._online_refit_count += 1

    def fit_pre(self, X: np.ndarray, y: np.ndarray) -> None:
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float).reshape(-1)
        if len(X) > self.max_keep:
            X = X[-self.max_keep :]
            y = y[-self.max_keep :]
        base = np.asarray(self.base_model.predict(X), dtype=float).reshape(-1)
        residual = y - base
        if len(X) < self.min_points:
            return
        model = self.factory.create(seed_offset=70_000)
        model.fit(X, residual)
        try:
            model.set_params(n_jobs=1)
        except (AttributeError, ValueError):
            pass
        self.prior_model = model

    def update(self, X: np.ndarray, y: np.ndarray) -> None:
        X = np.asarray(X, dtype=float)
        if len(X) == 0:
            return
        prior_prediction = self._prior_prediction(X)
        residual = np.asarray(y, dtype=float).reshape(-1) - prior_prediction
        self._online_X.extend(row.copy() for row in X)
        self._online_r.extend(residual.tolist())
        self._trim()
        self._refit_online()

    def _prior_prediction(self, X: np.ndarray) -> np.ndarray:
        base = np.asarray(self.base_model.predict(X), dtype=float).reshape(-1)
        if self.prior_model is None:
            return base
        return base + np.asarray(self.prior_model.predict(X), dtype=float).reshape(-1)

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        prediction = self._prior_prediction(X)
        if self.online_model is not None:
            prediction = prediction + np.asarray(self.online_model.predict(X), dtype=float).reshape(-1)
        return prediction

    def clone_for_episode(self) -> "ResidualAdapter":
        clone = ResidualAdapter(
            self.base_model,
            self.factory,
            weighted=self.weighted,
            min_points=self.min_points,
            max_keep=self.max_keep,
        )
        # Safe to share: both estimators are prediction-only in the new clone;
        # update() creates a new episode-local online model reference.
        clone.prior_model = self.prior_model
        clone.online_model = self.online_model
        return clone


def build_adapter(
    name: str,
    base_model: Any,
    factory: RegressorFactory,
    max_keep: int = 2500,
) -> BeamAdapter:
    key = name.lower().replace(" ", "")
    if key in {"none", "noadapter"}:
        return NoAdapter(base_model)
    if key in {"calibrator", "linear", "linearcalibrator"}:
        return LinearCalibrator(base_model, max_keep=max_keep)
    if key in {"residual", "residualxgb", "residualadapter"}:
        return ResidualAdapter(base_model, factory, weighted=False, max_keep=max_keep)
    if key in {"weightedresidual", "weightedresidualxgb", "weighted"}:
        return ResidualAdapter(base_model, factory, weighted=True, max_keep=max_keep)
    raise ValueError(f"Unknown adapter: {name}")
