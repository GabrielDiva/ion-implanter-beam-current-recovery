from __future__ import annotations

import hashlib
import json
import threading
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import asdict, dataclass
from typing import Callable, Dict, Iterable

import numpy as np
import pandas as pd
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, Matern, WhiteKernel

from .adapters import BeamAdapter, build_adapter
from .config import ColumnRoles, ControlBound, GLOBAL_TRAINING_ROLE, ReplayConfig
from .coordinates import CoordinateBridge, identity_bridge
from .data import ROLE_COL, TOOL_ORDER_COL, numeric_matrix
from .models import GlobalModelSet, HiddenEnvironmentSet, RegressorFactory
from .optimizers import SearchSpace, cma_es, pso_batch, random_search_batch
from .tasks import ReplayTask, TaskManifest, feature_vector


ENERGY_SCOPE = "Same machine + exact task energy"
MACHINE_SCOPE = "Same machine (all energies)"
NOT_APPLICABLE_SCOPE = "Not applicable"


def within_tolerance(value: float, target: float, tolerance_fraction: float = 0.05) -> bool:
    return abs(float(value) - float(target)) <= tolerance_fraction * max(abs(float(target)), 1e-9)


def _stable_seed(base_seed: int, *parts: object) -> int:
    payload = "|".join([str(base_seed), *map(str, parts)]).encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:4], "little")


@dataclass(frozen=True)
class AdapterHistoryInfo:
    requested_scope: str
    used_scope: str
    task_energy: float
    available_rows: int
    used_rows: int
    fallback_to_all_energies: bool


@dataclass(frozen=True)
class ProbeRecord:
    task_id: str
    machine_id: str
    energy: float
    algorithm: str
    adapter: str
    predictor_estimator: str
    simulator_estimator: str
    adapter_history_requested: str
    adapter_history_used: str
    adapter_history_available_rows: int
    adapter_history_used_rows: int
    adapter_history_fallback: bool
    phase: str
    round_index: int
    probe_index: int
    parameter: str
    previous_parameter_value: float
    proposed_parameter_value: float
    parameter_value: float
    requested_delta: float
    applied_delta: float
    max_delta_per_probe_steps: int
    max_delta_per_probe: float
    max_delta_range: float | None
    movement_clipped: bool
    beam: float
    target: float
    relative_error_fraction: float
    success: bool
    sim_parameter_value: float | None = None
    sim_applied_delta: float | None = None
    sim_movement_clipped: bool = False


@dataclass(frozen=True)
class EpisodeSummary:
    task_id: str
    machine_id: str
    energy: float
    algorithm: str
    adapter: str
    predictor_estimator: str
    simulator_estimator: str
    adapter_history_requested: str
    adapter_history_used: str
    adapter_history_available_rows: int
    adapter_history_used_rows: int
    adapter_history_fallback: bool
    target: float
    target_source: str
    initial_state_selection: str
    initial_beam: float
    initial_target_ratio: float
    final_beam: float
    success: bool
    initialization_success: bool
    online_success: bool
    cancelled: bool
    first_success_probe: int | None
    first_success_phase: str | None
    first_success_parameter: str | None
    first_success_online_probe: int | None
    initialization_rounds_budget: int
    online_rounds_budget: int
    initialization_rounds: int
    online_rounds: int
    total_rounds: int
    initialization_probes: int
    initialization_probes_budget: int
    online_probes: int
    total_probes: int
    total_probes_budget: int
    max_rounds: int
    tolerance_fraction: float
    reference_environment_beam: float
    reference_error_fraction: float
    reference_within_tolerance: bool
    reference_controls_within_bounds: bool
    reference_solution_in_search_space: bool
    initial_controls_within_bounds: bool
    movement_limit_policy: str
    movement_limits_json: str
    clipped_probe_count: int
    clipped_probe_fraction: float
    task_seed: int


@dataclass
class ReplayResults:
    summaries: list[EpisodeSummary]
    probes: list[ProbeRecord]

    def summary_frame(self) -> pd.DataFrame:
        return pd.DataFrame([asdict(x) for x in self.summaries])

    def probe_frame(self) -> pd.DataFrame:
        return pd.DataFrame([asdict(x) for x in self.probes])


def select_adapter_history(
    annotated: pd.DataFrame,
    roles: ColumnRoles,
    machine_id: str,
    task_energy: float,
    requested_scope: str = ENERGY_SCOPE,
    minimum_energy_rows: int = 50,
    history_cap: int = 2500,
) -> tuple[np.ndarray, np.ndarray, AdapterHistoryInfo]:
    """Select leakage-safe A from Global Training rows only.

    Exact-energy selection is attempted first. If it does not meet the declared
    minimum, selection falls back to all Global Training rows for that machine.
    The most recent rows are retained when a positive cap is supplied.
    """
    machine_mask = (annotated[roles.machine_id].astype(str) == str(machine_id)) & (
        annotated[ROLE_COL] == GLOBAL_TRAINING_ROLE
    )
    machine = annotated[machine_mask].sort_values(TOOL_ORDER_COL, kind="stable")
    all_X = numeric_matrix(machine, roles.feature_cols)
    all_y = pd.to_numeric(machine[roles.beam], errors="coerce").to_numpy(dtype=float)
    all_finite = np.isfinite(all_X).all(axis=1) & np.isfinite(all_y)
    all_X, all_y = all_X[all_finite], all_y[all_finite]

    requested = requested_scope if requested_scope in {ENERGY_SCOPE, MACHINE_SCOPE} else ENERGY_SCOPE
    used_scope = MACHINE_SCOPE
    fallback = False
    available = len(all_X)
    X, y = all_X, all_y

    if requested == ENERGY_SCOPE:
        energy_values = pd.to_numeric(machine[roles.energy], errors="coerce").to_numpy(dtype=float)
        finite_energy_values = energy_values[all_finite]
        energy_mask = np.isfinite(finite_energy_values) & np.isclose(
            finite_energy_values, float(task_energy), rtol=0.0, atol=1e-9
        )
        energy_X, energy_y = all_X[energy_mask], all_y[energy_mask]
        available = len(energy_X)
        if available >= max(2, int(minimum_energy_rows)):
            X, y = energy_X, energy_y
            used_scope = ENERGY_SCOPE
        else:
            fallback = True

    if history_cap > 0 and len(X) > int(history_cap):
        X, y = X[-int(history_cap) :], y[-int(history_cap) :]

    info = AdapterHistoryInfo(
        requested_scope=requested,
        used_scope=used_scope,
        task_energy=float(task_energy),
        available_rows=int(available),
        used_rows=int(len(X)),
        fallback_to_all_energies=bool(fallback),
    )
    return X, y, info


def _fit_gpr(X: np.ndarray, y: np.ndarray, seed: int) -> GaussianProcessRegressor:
    dimension = X.shape[1]
    kernel = (
        ConstantKernel(1.0, (1e-3, 1e3))
        * Matern(length_scale=np.ones(dimension), length_scale_bounds=(1e-2, 5.0), nu=2.5)
        + WhiteKernel(noise_level=1.0, noise_level_bounds=(1e-6, 1e2))
    )
    model = GaussianProcessRegressor(
        kernel=kernel,
        alpha=1e-6,
        normalize_y=True,
        n_restarts_optimizer=1,
        random_state=seed,
    )
    model.fit(X, y)
    return model


class ReplayRunner:
    def __init__(
        self,
        annotated: pd.DataFrame,
        roles: ColumnRoles,
        bounds: Dict[str, ControlBound],
        tuning_order: list[int],
        globals_: GlobalModelSet,
        environments: HiddenEnvironmentSet,
        adapter_factory: RegressorFactory,
        config: ReplayConfig,
        predictor_estimator: str = "",
        simulator_estimator: str = "",
        adapter_history_scope: str = ENERGY_SCOPE,
        minimum_energy_history_rows: int = 50,
        adapter_history_cap: int = 2500,
        bridge: CoordinateBridge | None = None,
        sim_bounds: Dict[str, ControlBound] | None = None,
    ):
        config.validate()
        self.annotated = annotated
        self.roles = roles
        self.space = SearchSpace(roles.controllable_cols, bounds, tuning_order)
        self.bridge = bridge or identity_bridge(roles)
        self.sim_bounds = sim_bounds or bounds
        for name in roles.controllable_cols:
            self.sim_bounds[name].validate()
        self.globals = globals_
        self.environments = environments
        self.adapter_factory = adapter_factory
        self.config = config
        self.predictor_estimator = predictor_estimator
        self.simulator_estimator = simulator_estimator
        self.adapter_history_scope = adapter_history_scope
        self.minimum_energy_history_rows = max(2, int(minimum_energy_history_rows))
        self.adapter_history_cap = max(2, int(adapter_history_cap))
        self._adapter_priors: dict[tuple[object, ...], tuple[BeamAdapter, AdapterHistoryInfo]] = {}
        self._prior_lock = threading.Lock()
        self._control_feature_indices = [roles.feature_cols.index(x) for x in roles.controllable_cols]
        self._movement_limits_json = json.dumps(
            {
                name: {
                    "resolution": float(self.space.bounds[name].resolution),
                    "max_delta_per_probe_steps": int(
                        self.space.bounds[name].maximum_delta_steps
                    ),
                    "max_delta_per_probe": float(self.space.bounds[name].maximum_delta),
                    "max_delta_range": (
                        None
                        if self.space.bounds[name].max_delta_range is None
                        else float(self.space.bounds[name].max_delta_range)
                    ),
                    "unrestricted_within_bounds": bool(
                        self.space.bounds[name].unrestricted
                    ),
                }
                for name in self.roles.controllable_cols
            },
            ensure_ascii=False,
            separators=(",", ":"),
        )

    @staticmethod
    def _not_applicable_history(task: ReplayTask) -> AdapterHistoryInfo:
        return AdapterHistoryInfo(
            NOT_APPLICABLE_SCOPE,
            NOT_APPLICABLE_SCOPE,
            float(task.energy),
            0,
            0,
            False,
        )

    def _history_cache_key(
        self,
        adapter_name: str,
        task: ReplayTask,
        info: AdapterHistoryInfo,
    ) -> tuple[object, ...]:
        energy_key = round(float(task.energy), 9) if info.used_scope == ENERGY_SCOPE else "ALL"
        return (
            adapter_name,
            str(task.machine_id),
            energy_key,
            info.used_scope,
            self.adapter_history_cap,
        )

    def _adapter_prior(self, adapter_name: str, task: ReplayTask) -> tuple[BeamAdapter, AdapterHistoryInfo]:
        if adapter_name.lower().replace(" ", "") in {"none", "noadapter"}:
            adapter = build_adapter(
                adapter_name,
                self.globals.models[self.roles.beam],
                self.adapter_factory,
                max_keep=self.adapter_history_cap,
            )
            return adapter, self._not_applicable_history(task)

        X, y, info = select_adapter_history(
            self.annotated,
            self.roles,
            task.machine_id,
            task.energy,
            requested_scope=self.adapter_history_scope,
            minimum_energy_rows=self.minimum_energy_history_rows,
            history_cap=self.adapter_history_cap,
        )
        key = self._history_cache_key(adapter_name, task, info)
        with self._prior_lock:
            cached = self._adapter_priors.get(key)
            if cached is None:
                adapter = build_adapter(
                    adapter_name,
                    self.globals.models[self.roles.beam],
                    self.adapter_factory,
                    max_keep=self.adapter_history_cap,
                )
                if len(X):
                    adapter.fit_pre(X, y)
                cached = (adapter, info)
                self._adapter_priors[key] = cached
        return cached[0].clone_for_episode(), cached[1]

    def _prepare_adapter_priors(
        self,
        tasks: list[ReplayTask],
        algorithms: list[str],
        adapter_name: str,
        status_callback: Callable[[str], None] | None,
        cancel_event: threading.Event,
    ) -> None:
        if all(x.upper().startswith("BO") for x in algorithms):
            return
        unique: dict[tuple[str, float], ReplayTask] = {}
        for task in tasks:
            unique[(str(task.machine_id), round(float(task.energy), 9))] = task
        total = len(unique)
        for index, task in enumerate(unique.values(), 1):
            if cancel_event.is_set():
                break
            if status_callback:
                status_callback(
                    f"Preparing cached A prior {index}/{total}: machine={task.machine_id}, energy={task.energy:g}"
                )
            self._adapter_prior(adapter_name, task)

    def _sim_controls_at_start(self, task: ReplayTask, controls: np.ndarray) -> dict[str, float]:
        control_map = dict(zip(self.roles.controllable_cols, controls))
        sim_controls, _, meta = self.bridge.convert_feature_maps(
            control_map,
            task.context,
            self.roles.controllable_cols,
            self.roles.monitorable_cols,
            sim_bounds=self.sim_bounds,
        )
        if meta["invalid"]:
            raise ValueError(
                f"Task {task.task_id} has an invalid solver-to-SIM transformation: "
                f"{meta['invalid_columns']}"
            )
        return sim_controls

    def _environment_beam(
        self,
        task: ReplayTask,
        controls: np.ndarray,
        *,
        previous_sim_controls: Dict[str, float] | None = None,
        changed_parameter: str | None = None,
    ) -> tuple[float, np.ndarray, dict[str, float], dict[str, object]]:
        control_map = dict(zip(self.roles.controllable_cols, controls))
        sim_controls, sim_context, meta = self.bridge.convert_feature_maps(
            control_map,
            task.context,
            self.roles.controllable_cols,
            self.roles.monitorable_cols,
            sim_bounds=self.sim_bounds,
            previous_sim_controls=previous_sim_controls,
            changed_parameter=changed_parameter,
        )
        if meta["invalid"]:
            raise ValueError(
                f"Invalid solver-to-SIM transformation during task {task.task_id}: "
                f"{meta['invalid_columns']}"
            )
        sim_vector = feature_vector(self.roles, sim_controls, sim_context)
        solver_vector = feature_vector(self.roles, control_map, task.context)
        beam = self.environments.predict(task.machine_id, sim_vector)[self.roles.beam]
        # Adapter correction is trained in solver coordinates, whereas the
        # frozen environment is queried in SIM coordinates.
        return float(beam), solver_vector, sim_controls, meta

    def _controls_within_bounds(self, controls: Dict[str, float]) -> bool:
        for name in self.roles.controllable_cols:
            value = float(controls[name])
            bound = self.space.bounds[name]
            if not np.isfinite(value) or value < bound.minimum - 1e-12 or value > bound.maximum + 1e-12:
                return False
        return True

    def _candidate_feature_matrix(self, task: ReplayTask, normalized: np.ndarray) -> np.ndarray:
        controls = self.space.decode_many(normalized)
        base = feature_vector(self.roles, task.initial_controls, task.context)
        matrix = np.tile(base.reshape(1, -1), (len(controls), 1))
        matrix[:, self._control_feature_indices] = controls
        return matrix

    def _record_probe(
        self,
        task: ReplayTask,
        algorithm: str,
        adapter_name: str,
        history: AdapterHistoryInfo,
        phase: str,
        round_index: int,
        probe_index: int,
        parameter_index: int,
        controls: np.ndarray,
        beam: float,
        *,
        previous_value: float | None = None,
        proposed_value: float | None = None,
        sim_controls: Dict[str, float] | None = None,
        previous_sim_controls: Dict[str, float] | None = None,
        sim_meta: dict[str, object] | None = None,
    ) -> ProbeRecord:
        bound = self.space.bounds[self.roles.controllable_cols[parameter_index]]
        applied_value = float(controls[parameter_index])
        if previous_value is None:
            previous_value = applied_value
        if proposed_value is None:
            proposed_value = applied_value
        error = abs(beam - task.target_beam) / max(abs(task.target_beam), 1e-9)
        return ProbeRecord(
            task_id=task.task_id,
            machine_id=task.machine_id,
            energy=float(task.energy),
            algorithm=algorithm,
            adapter=adapter_name,
            predictor_estimator=self.predictor_estimator,
            simulator_estimator=self.simulator_estimator,
            adapter_history_requested=history.requested_scope,
            adapter_history_used=history.used_scope,
            adapter_history_available_rows=history.available_rows,
            adapter_history_used_rows=history.used_rows,
            adapter_history_fallback=history.fallback_to_all_energies,
            phase=phase,
            round_index=round_index,
            probe_index=probe_index,
            parameter=self.roles.controllable_cols[parameter_index],
            previous_parameter_value=float(previous_value),
            proposed_parameter_value=float(proposed_value),
            parameter_value=applied_value,
            requested_delta=float(proposed_value - previous_value),
            applied_delta=float(applied_value - previous_value),
            max_delta_per_probe_steps=int(bound.maximum_delta_steps),
            max_delta_per_probe=float(bound.maximum_delta),
            max_delta_range=(
                None if bound.max_delta_range is None else float(bound.max_delta_range)
            ),
            movement_clipped=not np.isclose(
                applied_value, proposed_value, rtol=0.0, atol=1e-12
            ),
            beam=float(beam),
            target=float(task.target_beam),
            relative_error_fraction=float(error),
            success=within_tolerance(beam, task.target_beam, self.config.tolerance_fraction),
            sim_parameter_value=(
                None
                if sim_controls is None
                else float(sim_controls[self.roles.controllable_cols[parameter_index]])
            ),
            sim_applied_delta=(
                None
                if sim_controls is None or previous_sim_controls is None
                else float(
                    sim_controls[self.roles.controllable_cols[parameter_index]]
                    - previous_sim_controls[self.roles.controllable_cols[parameter_index]]
                )
            ),
            sim_movement_clipped=bool((sim_meta or {}).get("sim_clipped", False)),
        )

    def run(
        self,
        manifest: TaskManifest,
        algorithms: Iterable[str],
        adapter_name: str,
        *,
        episode_workers: int = 1,
        cancel_event: threading.Event | None = None,
        progress_callback: Callable[[EpisodeSummary, list[ProbeRecord], int, int], None] | None = None,
        status_callback: Callable[[str], None] | None = None,
    ) -> ReplayResults:
        algorithms = [str(x) for x in algorithms]
        tasks = list(manifest.tasks)
        cancel_event = cancel_event or threading.Event()
        self._prepare_adapter_priors(tasks, algorithms, adapter_name, status_callback, cancel_event)
        pairs = [(task, algorithm) for task in tasks for algorithm in algorithms]
        specs = [(index, task, algorithm) for index, (task, algorithm) in enumerate(pairs)]
        total = len(specs)
        summaries_by_index: dict[int, EpisodeSummary] = {}
        probes_by_index: dict[int, list[ProbeRecord]] = {}
        completed = 0

        def execute(spec):
            index, task, algorithm = spec
            summary, episode_probes = self.run_episode(
                task, algorithm, adapter_name, cancel_event=cancel_event
            )
            return index, summary, episode_probes

        def accept(result):
            nonlocal completed
            index, summary, episode_probes = result
            summaries_by_index[index] = summary
            probes_by_index[index] = episode_probes
            completed += 1
            if progress_callback:
                progress_callback(summary, episode_probes, completed, total)

        workers = max(1, min(4, int(episode_workers)))
        if workers == 1:
            for spec in specs:
                if cancel_event.is_set():
                    break
                accept(execute(spec))
        else:
            iterator = iter(specs)
            with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="refinelab-episode") as pool:
                pending = set()
                for _ in range(workers):
                    try:
                        pending.add(pool.submit(execute, next(iterator)))
                    except StopIteration:
                        break
                while pending:
                    done, pending = wait(pending, return_when=FIRST_COMPLETED)
                    for future in done:
                        accept(future.result())
                    if not cancel_event.is_set():
                        for _ in range(len(done)):
                            try:
                                pending.add(pool.submit(execute, next(iterator)))
                            except StopIteration:
                                break

        ordered = sorted(summaries_by_index)
        return ReplayResults(
            summaries=[summaries_by_index[i] for i in ordered],
            probes=[probe for i in ordered for probe in probes_by_index[i]],
        )

    def run_episode(
        self,
        task: ReplayTask,
        algorithm: str,
        adapter_name: str,
        *,
        cancel_event: threading.Event | None = None,
    ) -> tuple[EpisodeSummary, list[ProbeRecord]]:
        cancel_event = cancel_event or threading.Event()
        name = algorithm.strip()
        if name.upper().startswith("BO"):
            return self._run_bo(task, name, cancel_event)
        return self._run_model_based(task, name, adapter_name, cancel_event)

    def _run_model_based(
        self,
        task: ReplayTask,
        algorithm: str,
        adapter_name: str,
        cancel_event: threading.Event,
    ) -> tuple[EpisodeSummary, list[ProbeRecord]]:
        seed = _stable_seed(self.config.seed, task.task_id, algorithm, adapter_name)
        rng = np.random.default_rng(seed)
        adapter, history = self._adapter_prior(adapter_name, task)
        current = np.asarray([task.initial_controls[x] for x in self.roles.controllable_cols], dtype=float)
        current_sim = self._sim_controls_at_start(task, current)
        current_beam = float(task.initial_beam)
        records: list[ProbeRecord] = []
        first_success: int | None = None
        rounds = 0

        def objective_batch(normalized: np.ndarray) -> np.ndarray:
            features = self._candidate_feature_matrix(task, normalized)
            prediction = np.asarray(adapter.predict(features), dtype=float).reshape(-1)
            return -np.abs(prediction - task.target_beam) / max(abs(task.target_beam), 1e-9)

        def objective_one(normalized: np.ndarray) -> float:
            return float(objective_batch(np.asarray(normalized).reshape(1, -1))[0])

        while rounds < self.config.max_rounds and first_success is None and not cancel_event.is_set():
            rounds += 1
            if algorithm == "RandomSearch":
                normalized = random_search_batch(
                    objective_batch, self.space.dimension, self.config.random_search_samples, rng
                )
            elif algorithm == "PSO":
                normalized = pso_batch(
                    objective_batch,
                    self.space.dimension,
                    self.config.pso_particles,
                    self.config.pso_iterations,
                    rng,
                )
            elif algorithm == "CMA-ES":
                normalized = cma_es(objective_one, self.space.dimension, 80, int(rng.integers(1, 2**31)))
            else:
                raise ValueError(f"Unknown model-based algorithm: {algorithm}")

            target_controls = self.space.decode(normalized)
            sequence = self.space.stepwise_limited(current, target_controls)
            if not sequence:
                _, fallback = self.space.local_probe(current, rng)
                sequence = self.space.stepwise_limited(current, fallback)

            batch_X: list[np.ndarray] = []
            batch_y: list[float] = []
            for transition in sequence:
                if cancel_event.is_set():
                    break
                previous_sim = dict(current_sim)
                current = transition.controls.copy()
                current_beam, vector, current_sim, sim_meta = self._environment_beam(
                    task,
                    current,
                    previous_sim_controls=previous_sim,
                    changed_parameter=self.roles.controllable_cols[transition.parameter_index],
                )
                record = self._record_probe(
                    task,
                    algorithm,
                    adapter_name,
                    history,
                    "online",
                    rounds,
                    len(records) + 1,
                    transition.parameter_index,
                    current,
                    current_beam,
                    previous_value=transition.previous_value,
                    proposed_value=transition.proposed_value,
                    sim_controls=current_sim,
                    previous_sim_controls=previous_sim,
                    sim_meta=sim_meta,
                )
                records.append(record)
                batch_X.append(vector)
                batch_y.append(current_beam)
                if record.success:
                    first_success = len(records)
                    break
            # V3.2+: one bounded adapter refit per round, never once per probe.
            if batch_X and adapter_name.lower().replace(" ", "") not in {"none", "noadapter"}:
                adapter.update(np.asarray(batch_X), np.asarray(batch_y))

        reference_within_tolerance = within_tolerance(
            task.reference_environment_beam,
            task.target_beam,
            self.config.tolerance_fraction,
        )
        reference_controls_within_bounds = self._controls_within_bounds(task.reference_controls)
        summary = EpisodeSummary(
            task_id=task.task_id,
            machine_id=task.machine_id,
            energy=float(task.energy),
            algorithm=algorithm,
            adapter=adapter_name,
            predictor_estimator=self.predictor_estimator,
            simulator_estimator=self.simulator_estimator,
            adapter_history_requested=history.requested_scope,
            adapter_history_used=history.used_scope,
            adapter_history_available_rows=history.available_rows,
            adapter_history_used_rows=history.used_rows,
            adapter_history_fallback=history.fallback_to_all_energies,
            target=task.target_beam,
            target_source=task.target_source,
            initial_state_selection=task.initial_state_selection,
            initial_beam=task.initial_beam,
            initial_target_ratio=task.initial_beam / max(abs(task.target_beam), 1e-9),
            final_beam=current_beam,
            success=first_success is not None,
            initialization_success=False,
            online_success=first_success is not None,
            cancelled=cancel_event.is_set(),
            first_success_probe=first_success,
            first_success_phase="online" if first_success is not None else None,
            first_success_parameter=(
                records[first_success - 1].parameter if first_success is not None else None
            ),
            first_success_online_probe=first_success,
            initialization_rounds_budget=0,
            online_rounds_budget=self.config.max_rounds,
            initialization_rounds=0,
            online_rounds=rounds,
            total_rounds=rounds,
            initialization_probes=0,
            initialization_probes_budget=0,
            online_probes=len(records),
            total_probes=len(records),
            total_probes_budget=self.config.max_rounds * self.space.dimension,
            max_rounds=self.config.max_rounds,
            tolerance_fraction=self.config.tolerance_fraction,
            reference_environment_beam=task.reference_environment_beam,
            reference_error_fraction=task.reference_error_fraction,
            reference_within_tolerance=reference_within_tolerance,
            reference_controls_within_bounds=reference_controls_within_bounds,
            reference_solution_in_search_space=(
                reference_within_tolerance and reference_controls_within_bounds
            ),
            initial_controls_within_bounds=self._controls_within_bounds(task.initial_controls),
            movement_limit_policy=(
                "Solver proposal clipped to current +/- max_delta_range, then solver bounds/resolution; "
                "converted candidate separately projected by SIM bounds/resolution/range"
            ),
            movement_limits_json=self._movement_limits_json,
            clipped_probe_count=sum(record.movement_clipped for record in records),
            clipped_probe_fraction=(
                sum(record.movement_clipped for record in records) / len(records)
                if records
                else 0.0
            ),
            task_seed=task.task_seed,
        )
        return summary, records

    def _run_bo(
        self,
        task: ReplayTask,
        algorithm: str,
        cancel_event: threading.Event,
    ) -> tuple[EpisodeSummary, list[ProbeRecord]]:
        seed = _stable_seed(self.config.seed, task.task_id, algorithm)
        rng = np.random.default_rng(seed)
        history = self._not_applicable_history(task)
        current = np.asarray([task.initial_controls[x] for x in self.roles.controllable_cols], dtype=float)
        current_sim = self._sim_controls_at_start(task, current)
        current_beam = float(task.initial_beam)
        X_obs = [self.space.encode(current)]
        y_obs = [current_beam]
        records: list[ProbeRecord] = []
        first_success: int | None = None
        requested_init_rounds = self.config.bo_initialization_rounds
        init_target = self.config.bo_initialization_probes(self.space.dimension)
        online_rounds_budget = self.config.bo_online_rounds_budget
        max_probes = self.config.max_rounds * self.space.dimension

        for init_index in range(min(init_target, max_probes)):
            if cancel_event.is_set():
                break
            # One initialization round is a complete sweep over the declared
            # tuning order. This makes R x D mean exactly what the GUI reports.
            parameter_index = self.space.tuning_order[init_index % self.space.dimension]
            previous_value = float(current[parameter_index])
            parameter_index, candidate = self.space.local_probe_at(current, parameter_index, rng)
            previous_sim = dict(current_sim)
            current = candidate.copy()
            current_beam, _, current_sim, sim_meta = self._environment_beam(
                task,
                current,
                previous_sim_controls=previous_sim,
                changed_parameter=self.roles.controllable_cols[parameter_index],
            )
            X_obs.append(self.space.encode(current))
            y_obs.append(current_beam)
            round_index = init_index // self.space.dimension + 1
            record = self._record_probe(
                task,
                algorithm,
                NOT_APPLICABLE_SCOPE,
                history,
                "initialization",
                round_index,
                len(records) + 1,
                parameter_index,
                current,
                current_beam,
                previous_value=previous_value,
                proposed_value=float(current[parameter_index]),
                sim_controls=current_sim,
                previous_sim_controls=previous_sim,
                sim_meta=sim_meta,
            )
            records.append(record)
            if record.success:
                first_success = len(records)
                break

        init_probes = len(records)
        init_rounds = int(np.ceil(init_probes / max(1, self.space.dimension)))
        online_rounds = 0

        while (
            online_rounds < online_rounds_budget
            and first_success is None
            and not cancel_event.is_set()
        ):
            online_rounds += 1
            model = _fit_gpr(np.asarray(X_obs), np.asarray(y_obs), int(rng.integers(1, 2**31)))
            candidates = rng.random((self.config.bo_candidates, self.space.dimension))
            mean, std = model.predict(candidates, return_std=True)
            acquisition = -np.abs(mean - task.target_beam) + self.config.bo_kappa * std
            target_controls = self.space.decode(candidates[int(np.argmax(acquisition))])
            sequence = self.space.stepwise_limited(current, target_controls)
            if not sequence:
                _, fallback = self.space.local_probe(current, rng)
                sequence = self.space.stepwise_limited(current, fallback)

            for transition in sequence:
                if len(records) >= max_probes or cancel_event.is_set():
                    break
                previous_sim = dict(current_sim)
                current = transition.controls.copy()
                current_beam, _, current_sim, sim_meta = self._environment_beam(
                    task,
                    current,
                    previous_sim_controls=previous_sim,
                    changed_parameter=self.roles.controllable_cols[transition.parameter_index],
                )
                X_obs.append(self.space.encode(current))
                y_obs.append(current_beam)
                record = self._record_probe(
                    task,
                    algorithm,
                    NOT_APPLICABLE_SCOPE,
                    history,
                    "online",
                    init_rounds + online_rounds,
                    len(records) + 1,
                    transition.parameter_index,
                    current,
                    current_beam,
                    previous_value=transition.previous_value,
                    proposed_value=transition.proposed_value,
                    sim_controls=current_sim,
                    previous_sim_controls=previous_sim,
                    sim_meta=sim_meta,
                )
                records.append(record)
                if record.success:
                    first_success = len(records)
                    break

        online_probes = len(records) - init_probes
        reference_within_tolerance = within_tolerance(
            task.reference_environment_beam,
            task.target_beam,
            self.config.tolerance_fraction,
        )
        reference_controls_within_bounds = self._controls_within_bounds(task.reference_controls)
        summary = EpisodeSummary(
            task_id=task.task_id,
            machine_id=task.machine_id,
            energy=float(task.energy),
            algorithm=algorithm,
            adapter=NOT_APPLICABLE_SCOPE,
            predictor_estimator="Episode-local GPR",
            simulator_estimator=self.simulator_estimator,
            adapter_history_requested=history.requested_scope,
            adapter_history_used=history.used_scope,
            adapter_history_available_rows=0,
            adapter_history_used_rows=0,
            adapter_history_fallback=False,
            target=task.target_beam,
            target_source=task.target_source,
            initial_state_selection=task.initial_state_selection,
            initial_beam=task.initial_beam,
            initial_target_ratio=task.initial_beam / max(abs(task.target_beam), 1e-9),
            final_beam=current_beam,
            success=first_success is not None,
            initialization_success=bool(
                first_success is not None and first_success <= init_probes
            ),
            online_success=bool(
                first_success is not None and first_success > init_probes
            ),
            cancelled=cancel_event.is_set(),
            first_success_probe=first_success,
            first_success_phase=(
                None
                if first_success is None
                else "initialization"
                if first_success <= init_probes
                else "online"
            ),
            first_success_parameter=(
                records[first_success - 1].parameter if first_success is not None else None
            ),
            first_success_online_probe=(
                None
                if first_success is None or first_success <= init_probes
                else first_success - init_probes
            ),
            initialization_rounds_budget=requested_init_rounds,
            online_rounds_budget=online_rounds_budget,
            initialization_rounds=init_rounds,
            online_rounds=online_rounds,
            total_rounds=init_rounds + online_rounds,
            initialization_probes=init_probes,
            initialization_probes_budget=init_target,
            online_probes=online_probes,
            total_probes=len(records),
            total_probes_budget=max_probes,
            max_rounds=self.config.max_rounds,
            tolerance_fraction=self.config.tolerance_fraction,
            reference_environment_beam=task.reference_environment_beam,
            reference_error_fraction=task.reference_error_fraction,
            reference_within_tolerance=reference_within_tolerance,
            reference_controls_within_bounds=reference_controls_within_bounds,
            reference_solution_in_search_space=(
                reference_within_tolerance and reference_controls_within_bounds
            ),
            initial_controls_within_bounds=self._controls_within_bounds(task.initial_controls),
            movement_limit_policy=(
                "Solver proposal clipped to current +/- max_delta_range, then solver bounds/resolution; "
                "converted candidate separately projected by SIM bounds/resolution/range"
            ),
            movement_limits_json=self._movement_limits_json,
            clipped_probe_count=sum(record.movement_clipped for record in records),
            clipped_probe_fraction=(
                sum(record.movement_clipped for record in records) / len(records)
                if records
                else 0.0
            ),
            task_seed=task.task_seed,
        )
        return summary, records
