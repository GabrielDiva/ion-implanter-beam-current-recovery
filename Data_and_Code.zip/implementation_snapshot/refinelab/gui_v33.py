from __future__ import annotations

import threading
import traceback
import json
from pathlib import Path
from typing import Callable

import pandas as pd
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .audit import audit_global_task_protocol
from .config import (
    ColumnRoles,
    ControlBound,
    GlobalTaskSplitConfig,
    ReplayConfig,
    TaskGenerationConfig,
)
from .coordinates import CoordinateBridge, identity_bridge, parse_mapping_text
from .data import (
    ROLE_COL,
    SOURCE_ORDER_COL,
    TOOL_ORDER_COL,
    derive_global_training_bounds,
    load_excel,
)
from .modeling_v33 import (
    RANDOM_FOREST_NAME,
    SUPPORTED_ESTIMATORS,
    XGBOOST_NAME,
    EstimatorFactoryV33,
    GlobalPredictorCatalog,
    SimulatorCatalog,
    train_global_predictor_catalog,
    train_simulator_catalog,
)
from .models import RegressorFactory
from .replay import ENERGY_SCOPE, MACHINE_SCOPE, ReplayResults, ReplayRunner
from .splits import GlobalTaskSplitResult, global_task_temporal_split
from .tasks import ALL_FUTURE_MODE, TaskManifest, generate_task_manifest


TASK_PREVIEW_LIMIT = 1000
_INTERNAL_PROTOCOL_COLUMNS = frozenset(
    {ROLE_COL, SOURCE_ORDER_COL, TOOL_ORDER_COL}
)


def visible_input_columns(columns) -> list:
    """Return only user-supplied columns for GUI role selection."""
    return [name for name in columns if name not in _INTERNAL_PROTOCOL_COLUMNS]


def _to_float(value: str, name: str) -> float:
    try:
        return float(value.strip())
    except Exception as exc:
        raise ValueError(f"Invalid {name}: {value!r}") from exc


def _to_int(value: str, name: str) -> int:
    try:
        return int(value.strip())
    except Exception as exc:
        raise ValueError(f"Invalid {name}: {value!r}") from exc


def _parse_order(value: str, size: int) -> list[int]:
    if not value.strip():
        return list(range(size))
    order = [int(x.strip()) - 1 for x in value.replace("，", ",").split(",") if x.strip()]
    if sorted(order) != list(range(size)):
        raise ValueError(f"Tuning order must be a permutation of 1..{size}.")
    return order


class LogBox(ttk.Frame):
    def __init__(self, master, height=8):
        super().__init__(master)
        self.text = tk.Text(self, height=height, wrap="word", state="disabled")
        bar = ttk.Scrollbar(self, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=bar.set)
        self.text.pack(side="left", fill="both", expand=True)
        bar.pack(side="right", fill="y")

    def append(self, value: str):
        self.text.configure(state="normal")
        self.text.insert("end", str(value).rstrip() + "\n")
        self.text.see("end")
        self.text.configure(state="disabled")


class RefineLabV40App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("RefineLab V4.0 — Original-space search with transformed SIM")
        self.root.geometry("1560x930")

        self.frame: pd.DataFrame | None = None
        self.columns: list[str] = []
        self.roles: ColumnRoles | None = None
        self.tuning_order: list[int] = []
        self.split_result: GlobalTaskSplitResult | None = None
        self.bounds: dict[str, ControlBound] = {}
        self.sim_bounds: dict[str, ControlBound] = {}
        self.coordinate_bridge: CoordinateBridge | None = None
        self.solver_annotated: pd.DataFrame | None = None
        self.sim_annotated: pd.DataFrame | None = None
        self.global_catalog: GlobalPredictorCatalog | None = None
        self.simulator_catalog: SimulatorCatalog | None = None
        self.manifest: TaskManifest | None = None
        self.replay_results: ReplayResults | None = None
        self.replay_cancel_event: threading.Event | None = None
        self.replay_running = False
        self.task_generation_cancel_event: threading.Event | None = None
        self.task_generation_running = False

        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill="both", expand=True)
        self.tab_data = ttk.Frame(self.notebook)
        self.tab_models = ttk.Frame(self.notebook)
        self.tab_tasks = ttk.Frame(self.notebook)
        self.tab_replay = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_data, text="1) Data and chronological split")
        self.notebook.add(self.tab_models, text="2) Predictors and SIM fidelity")
        self.notebook.add(self.tab_tasks, text="3) Frozen future tasks")
        self.notebook.add(self.tab_replay, text="4) Paired closed-loop replay")

        self._build_data_tab()
        self._build_models_tab()
        self._build_tasks_tab()
        self._build_replay_tab()

    def _start_worker(self, action: Callable[[], None], log: LogBox):
        def worker():
            try:
                action()
            except Exception as exc:
                detail = traceback.format_exc()
                message = str(exc)
                self.root.after(0, lambda d=detail: log.append(d))
                self.root.after(0, lambda m=message: messagebox.showerror("RefineLab V4.0", m))

        threading.Thread(target=worker, daemon=True).start()

    def _build_data_tab(self):
        file_box = ttk.LabelFrame(self.tab_data, text="Input table and within-machine chronology", padding=10)
        file_box.pack(fill="x", padx=10, pady=10)
        self.file_var = tk.StringVar()
        ttk.Entry(file_box, textvariable=self.file_var).grid(row=0, column=0, columnspan=6, sticky="ew")
        ttk.Button(file_box, text="Browse", command=self._browse).grid(row=0, column=6, padx=6)
        ttk.Button(file_box, text="Load table", command=self._load).grid(row=0, column=7)
        self.machine_label = ttk.Label(file_box, text="Machine ID: first column (locked)")
        self.machine_label.grid(row=1, column=0, columnspan=3, sticky="w", pady=(8, 0))
        ttk.Label(
            file_box,
            text="Chronology: original row order is used only within identical machine IDs; different IDs are never time-compared.",
        ).grid(row=1, column=3, columnspan=5, sticky="w", pady=(8, 0))
        file_box.columnconfigure(0, weight=1)

        body = ttk.Frame(self.tab_data)
        body.pack(fill="both", expand=True, padx=10)
        schema = ttk.LabelFrame(body, text="Column roles", padding=10)
        schema.pack(side="left", fill="both", expand=True, padx=(0, 5))
        protocol = ttk.LabelFrame(body, text="Chronological data roles — full names", padding=10)
        protocol.pack(side="left", fill="both", expand=True, padx=(5, 0))

        self.energy_var = tk.StringVar()
        self.output_start_var = tk.StringVar()
        self.beam_var = tk.StringVar()
        self.control_start_var = tk.StringVar(value="2")
        self.control_end_var = tk.StringVar()
        self.order_var = tk.StringVar()
        ttk.Label(schema, text="Energy column").grid(row=0, column=0, sticky="w")
        self.energy_combo = ttk.Combobox(schema, textvariable=self.energy_var, state="readonly", width=36)
        self.energy_combo.grid(row=0, column=1, sticky="ew", padx=5)
        ttk.Label(schema, text="Output start column (1-based)").grid(row=1, column=0, sticky="w", pady=3)
        ttk.Entry(schema, textvariable=self.output_start_var, width=10).grid(row=1, column=1, sticky="w", padx=5)
        ttk.Button(schema, text="Refresh output choices", command=self._refresh_outputs).grid(row=1, column=2)
        ttk.Label(schema, text="Beam output / historical target proxy").grid(row=2, column=0, sticky="w", pady=3)
        self.beam_combo = ttk.Combobox(schema, textvariable=self.beam_var, state="disabled", width=36)
        self.beam_combo.grid(row=2, column=1, sticky="ew", padx=5)
        ttk.Label(schema, text="Controllable start/end (1-based)").grid(row=3, column=0, sticky="w", pady=3)
        pair = ttk.Frame(schema)
        pair.grid(row=3, column=1, sticky="w", padx=5)
        ttk.Entry(pair, textvariable=self.control_start_var, width=8).pack(side="left")
        ttk.Label(pair, text=" to ").pack(side="left")
        ttk.Entry(pair, textvariable=self.control_end_var, width=8).pack(side="left")
        ttk.Label(schema, text="Sequential tuning order (1-based)").grid(row=4, column=0, sticky="w", pady=3)
        ttk.Entry(schema, textvariable=self.order_var).grid(row=4, column=1, sticky="ew", padx=5)
        self.column_text = tk.Text(schema, height=17, wrap="none")
        self.column_text.grid(row=5, column=0, columnspan=3, sticky="nsew", pady=(8, 0))
        schema.columnconfigure(1, weight=1)
        schema.rowconfigure(5, weight=1)

        self.global_fraction_var = tk.StringVar(value="0.85")
        self.future_fraction_var = tk.StringVar(value="0.15")
        self.min_global_var = tk.StringVar(value="60")
        self.min_future_var = tk.StringVar(value="10")
        labels = [
            (
                "Global predictor training data (first period within each machine)",
                self.global_fraction_var,
                self.min_global_var,
            ),
            (
                "Future replay task data (last period within each machine)",
                self.future_fraction_var,
                self.min_future_var,
            ),
        ]
        ttk.Label(protocol, text="Data role").grid(row=0, column=0, sticky="w")
        ttk.Label(protocol, text="Fraction").grid(row=0, column=1)
        ttk.Label(protocol, text="Minimum rows/machine").grid(row=0, column=2)
        for row, (label, fraction, minimum) in enumerate(labels, start=1):
            ttk.Label(protocol, text=label).grid(row=row, column=0, sticky="w", pady=4)
            ttk.Entry(protocol, textvariable=fraction, width=10).grid(row=row, column=1, padx=6)
            ttk.Entry(protocol, textvariable=minimum, width=10).grid(row=row, column=2, padx=6)
        ttk.Label(
            protocol,
            text="Adapter history is not a third split: it reuses the current machine's Global predictor training rows.",
            foreground="#333366",
        ).grid(row=3, column=0, columnspan=3, sticky="w", pady=(8, 4))
        buttons = ttk.Frame(protocol)
        buttons.grid(row=4, column=0, columnspan=3, sticky="ew", pady=6)
        ttk.Button(buttons, text="Build chronological roles + bounds", command=self._build_split).pack(side="left")
        ttk.Button(buttons, text="Leakage Audit", command=self._audit).pack(side="left", padx=6)
        ttk.Button(buttons, text="Export role CSV", command=self._export_roles).pack(side="left")
        ttk.Button(buttons, text="Export SIM view CSV", command=self._export_sim_roles).pack(side="left", padx=6)

        columns = ("machine", "total", "eligible", "global_training", "future_tasks", "reason")
        self.split_tree = ttk.Treeview(protocol, columns=columns, show="headings", height=13)
        headings = {
            "machine": "Machine",
            "total": "Total rows",
            "eligible": "Eligible",
            "global_training": "Global predictor training rows",
            "future_tasks": "Future replay task rows",
            "reason": "Reason",
        }
        for name in columns:
            self.split_tree.heading(name, text=headings[name])
            self.split_tree.column(name, width=170 if name in {"global_training", "future_tasks"} else 100, anchor="center")
        self.split_tree.column("reason", width=250)
        self.split_tree.grid(row=5, column=0, columnspan=3, sticky="nsew")
        protocol.rowconfigure(5, weight=1)
        protocol.columnconfigure(0, weight=1)

        coordinate_box = ttk.LabelFrame(
            self.tab_data,
            text="V4.0 coordinate mode — one file, solver view and SIM view",
            padding=8,
        )
        coordinate_box.pack(fill="x", padx=10, pady=(8, 4))
        self.ablation_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            coordinate_box,
            text="Enable coordinate ablation: search in original columns, transform candidates before SIM",
            variable=self.ablation_var,
        ).grid(row=0, column=0, columnspan=4, sticky="w")
        ttk.Label(
            coordinate_box,
            text=(
                "Mapping format: canonical solver column<TAB>original solver column<TAB>processed SIM column<TAB>"
                "expression<TAB>epsilon<TAB>denominator expression. Use {Column name} for names containing spaces or punctuation."
            ),
            foreground="#333366",
        ).grid(row=1, column=0, columnspan=4, sticky="w", pady=(5, 2))
        ttk.Label(
            coordinate_box,
            text="Example: Electric<TAB>Electric<TAB>Electric2<TAB>{Electric} / {Delta_E}<TAB>1e-6<TAB>{Delta_E}",
        ).grid(row=2, column=0, columnspan=4, sticky="w")
        self.mapping_text = tk.Text(coordinate_box, height=4, wrap="none")
        self.mapping_text.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(5, 0))
        ttk.Button(
            coordinate_box,
            text="Export coordinate config",
            command=self._export_coordinate_config,
        ).grid(row=4, column=0, sticky="w", pady=(5, 0))
        coordinate_box.columnconfigure(0, weight=1)

        bounds_box = ttk.LabelFrame(
            self.tab_data,
            text=(
                "V4.0 engineering ranges: name<TAB>minimum<TAB>maximum<TAB>resolution"
                "<TAB>max_delta_range (0 = unrestricted)"
            ),
            padding=8,
        )
        bounds_box.pack(fill="x", padx=10, pady=(8, 4))
        ttk.Label(
            bounds_box,
            text=(
                "The left table constrains optimizer search in solver/original coordinates. The right table constrains "
                "the transformed candidate after it enters SIM; the range field is a maximum single-probe change, "
                "not a physical resolution step count. For a mapped control, the right-table values use the processed "
                "source units (for example Focus_Bias), although the canonical row name remains the solver name. "
                "Internally the value is quantized using resolution."
            ),
        ).pack(anchor="w")
        bounds_tables = ttk.Frame(bounds_box)
        bounds_tables.pack(fill="x", pady=(5, 0))
        solver_box = ttk.LabelFrame(bounds_tables, text="Solver/original coordinate bounds", padding=4)
        solver_box.pack(side="left", fill="both", expand=True, padx=(0, 4))
        sim_box = ttk.LabelFrame(bounds_tables, text="SIM/transformed coordinate bounds", padding=4)
        sim_box.pack(side="left", fill="both", expand=True, padx=(4, 0))
        self.bounds_text = tk.Text(solver_box, height=7, wrap="none")
        self.bounds_text.pack(fill="both", expand=True)
        self.sim_bounds_text = tk.Text(sim_box, height=7, wrap="none")
        self.sim_bounds_text.pack(fill="both", expand=True)
        self.log_data = LogBox(self.tab_data, height=7)
        self.log_data.pack(fill="x", padx=10, pady=(4, 10))

    def _export_coordinate_config(self):
        if self.roles is None or self.coordinate_bridge is None:
            messagebox.showerror("RefineLab V4.0", "Build the chronological split first.")
            return
        try:
            solver_bounds = self._read_bounds(self.bounds_text)
            sim_bounds = self._read_bounds(self.sim_bounds_text)
        except Exception as exc:
            messagebox.showerror("RefineLab V4.0", str(exc))
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            initialfile="refinelab_v40_coordinate_config.json",
            filetypes=[("JSON", "*.json"), ("All files", "*.*")],
        )
        if not path:
            return
        payload = {
            "version": "4.0",
            "coordinate_bridge": self.coordinate_bridge.to_dict(),
            "solver_bounds": {
                name: {
                    "minimum": float(bound.minimum),
                    "maximum": float(bound.maximum),
                    "resolution": float(bound.resolution),
                    "max_delta_range": (
                        0.0
                        if bound.unrestricted
                        else float(bound.max_delta_range or bound.maximum_delta)
                    ),
                }
                for name, bound in solver_bounds.items()
            },
            "sim_bounds": {
                name: {
                    "minimum": float(bound.minimum),
                    "maximum": float(bound.maximum),
                    "resolution": float(bound.resolution),
                    "max_delta_range": (
                        0.0
                        if bound.unrestricted
                        else float(bound.max_delta_range or bound.maximum_delta)
                    ),
                }
                for name, bound in sim_bounds.items()
            },
            "roles": {
                "machine_id": self.roles.machine_id,
                "energy": self.roles.energy,
                "beam": self.roles.beam,
                "controllable_cols": list(self.roles.controllable_cols),
                "monitorable_cols": list(self.roles.monitorable_cols),
            },
        }
        Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        self.log_data.append(f"Exported V4.0 coordinate configuration: {Path(path).name}")

    def _build_models_tab(self):
        controls = ttk.LabelFrame(self.tab_models, text="Model comparison and fidelity protocol", padding=10)
        controls.pack(fill="x", padx=10, pady=10)
        self.use_xgb_var = tk.BooleanVar(value=True)
        self.use_rf_var = tk.BooleanVar(value=False)
        self.folds_var = tk.StringVar(value="5")
        ttk.Checkbutton(controls, text="XGBoost", variable=self.use_xgb_var).pack(side="left")
        ttk.Checkbutton(controls, text="Random Forest", variable=self.use_rf_var).pack(side="left", padx=10)
        ttk.Label(controls, text="Random folds").pack(side="left", padx=(20, 4))
        ttk.Entry(controls, textvariable=self.folds_var, width=6).pack(side="left")
        ttk.Button(controls, text="Train predictors + evaluate/refit SIM", command=self._train_models).pack(side="left", padx=12)
        ttk.Button(controls, text="Export metrics CSV", command=self._export_metrics).pack(side="left")

        explanation = ttk.LabelFrame(self.tab_models, text="How to read the metrics", padding=8)
        explanation.pack(fill="x", padx=10, pady=(0, 8))
        ttk.Label(
            explanation,
            text=(
                "Global Training in-sample fit is descriptive and optimistic. "
                "For drift evidence compare Global Training random-fold OOF with Future Replay Tasks out-of-time.\n"
                "Per-machine SIM random-fold OOF evaluates fidelity; after evaluation each SIM is refitted on 100% of that machine and frozen as the virtual tool."
            ),
        ).pack(anchor="w")

        columns = (
            "role",
            "estimator",
            "machine",
            "evaluation",
            "mape",
            "median_ape",
            "bias",
            "r2",
            "n_train",
            "n_eval",
            "folds",
        )
        self.metric_tree = ttk.Treeview(self.tab_models, columns=columns, show="headings", height=22)
        widths = {"role": 135, "estimator": 115, "machine": 80, "evaluation": 270}
        for name in columns:
            self.metric_tree.heading(name, text=name.replace("_", " ").title())
            self.metric_tree.column(name, width=widths.get(name, 95), anchor="center")
        self.metric_tree.pack(fill="both", expand=True, padx=10)
        self.log_models = LogBox(self.tab_models, height=10)
        self.log_models.pack(fill="x", padx=10, pady=10)

    def _build_tasks_tab(self):
        controls = ttk.LabelFrame(self.tab_tasks, text="Frozen Future Replay Tasks — scalable generation", padding=10)
        controls.pack(fill="x", padx=10, pady=10)
        self.task_sim_var = tk.StringVar(value=XGBOOST_NAME)
        self.tasks_n_var = tk.StringVar(value="100")
        self.tasks_seed_var = tk.StringVar(value="42")
        self.diff_var = tk.StringVar(value="0.1")
        self.beam_max_var = tk.StringVar(value="1000")
        self.degrade_var = tk.StringVar(value="0.90")
        self.ref_error_var = tk.StringVar(value="0.15")
        self.init_search_var = tk.StringVar(value="18")
        self.all_future_var = tk.BooleanVar(value=False)
        items = [
            ("Frozen SIM estimator", self.task_sim_var, "combo"),
            ("Tasks", self.tasks_n_var, "entry"),
            ("Seed", self.tasks_seed_var, "entry"),
            ("Difficulty >", self.diff_var, "entry"),
            ("Beam <=", self.beam_max_var, "entry"),
            ("Initial/target <", self.degrade_var, "entry"),
            ("Max SIM-reference error", self.ref_error_var, "entry"),
            ("Legacy degradation attempts", self.init_search_var, "entry"),
        ]
        for i, (label, variable, kind) in enumerate(items):
            row, col = divmod(i, 4)
            ttk.Label(controls, text=label).grid(row=row * 2, column=col * 2, sticky="w", padx=(0, 4))
            if kind == "combo":
                ttk.Combobox(controls, textvariable=variable, values=SUPPORTED_ESTIMATORS, state="readonly", width=18).grid(
                    row=row * 2 + 1, column=col * 2, sticky="w", padx=(0, 12)
                )
            else:
                entry = ttk.Entry(controls, textvariable=variable, width=12)
                entry.grid(
                    row=row * 2 + 1, column=col * 2, sticky="w", padx=(0, 12)
                )
                if label == "Tasks":
                    self.tasks_n_entry = entry
        ttk.Checkbutton(
            controls,
            text="Use every eligible Future Replay Task (ignore Tasks count)",
            variable=self.all_future_var,
            command=self._toggle_all_future_mode,
        ).grid(row=4, column=0, columnspan=4, sticky="w", pady=(10, 0))
        ttk.Label(
            controls,
            text="Legacy start: 18 random full-space attempts; first below the threshold is kept, otherwise one random original control is halved. Unrelated to BO initialization.",
            foreground="#333366",
        ).grid(row=4, column=4, columnspan=4, sticky="w", pady=(10, 0))
        ttk.Label(
            controls,
            text="Target: observed successful Beam Current in Future rows. All-Future mode still applies Difficulty, Beam and SIM-fidelity qualification.",
        ).grid(row=5, column=0, columnspan=4, sticky="w", pady=(8, 0))
        task_action_row = ttk.Frame(controls)
        task_action_row.grid(row=6, column=0, columnspan=8, sticky="w", pady=(8, 0))
        self.generate_tasks_button = ttk.Button(
            task_action_row, text="Generate frozen task manifest", command=self._generate_tasks
        )
        self.generate_tasks_button.pack(side="left")
        self.cancel_tasks_button = ttk.Button(
            task_action_row,
            text="Cancel generation",
            command=self._cancel_task_generation,
            state="disabled",
        )
        self.cancel_tasks_button.pack(side="left", padx=6)
        ttk.Button(task_action_row, text="Load task CSV", command=self._load_tasks).pack(
            side="left", padx=(0, 6)
        )
        ttk.Button(task_action_row, text="Export task CSV", command=self._export_tasks).pack(
            side="left"
        )

        self.task_progress_var = tk.DoubleVar(value=0.0)
        ttk.Progressbar(
            controls, variable=self.task_progress_var, maximum=100.0, length=520
        ).grid(row=7, column=0, columnspan=4, sticky="ew", pady=(10, 0))
        self.task_status_var = tk.StringVar(value="Idle — random subset mode")
        ttk.Label(controls, textvariable=self.task_status_var).grid(
            row=7, column=4, columnspan=4, sticky="w", padx=(8, 0), pady=(10, 0)
        )

        columns = ("task", "machine", "energy", "sim", "source_order", "target", "initial", "degradation", "reference_error")
        self.task_tree = ttk.Treeview(self.tab_tasks, columns=columns, show="headings", height=22)
        for name in columns:
            self.task_tree.heading(name, text=name.replace("_", " ").title())
            self.task_tree.column(name, width=170 if name == "task" else 120, anchor="center")
        self.task_tree.pack(fill="both", expand=True, padx=10)
        self.log_tasks = LogBox(self.tab_tasks, height=9)
        self.log_tasks.pack(fill="x", padx=10, pady=10)

    def _build_replay_tab(self):
        controls = ttk.LabelFrame(self.tab_replay, text="Paired closed-loop replay — V4.0", padding=10)
        controls.pack(fill="x", padx=10, pady=10)
        self.algorithm_list = tk.Listbox(controls, selectmode="extended", exportselection=False, height=4, width=22)
        for item in ["PSO", "RandomSearch", "BO (GPR)", "CMA-ES"]:
            self.algorithm_list.insert("end", item)
        ttk.Label(controls, text="Algorithms (multi-select)").grid(row=0, column=0, sticky="w")
        self.algorithm_list.grid(row=1, column=0, rowspan=6, padx=(0, 14))

        self.predictor_var = tk.StringVar(value=XGBOOST_NAME)
        self.replay_sim_var = tk.StringVar(value=XGBOOST_NAME)
        self.adapter_var = tk.StringVar(value="ResidualXGB")
        self.rounds_var = tk.StringVar(value="20")
        self.bo_initialization_rounds_var = tk.StringVar(value="2")
        self.replay_seed_var = tk.StringVar(value="42")
        self.adapter_history_scope_var = tk.StringVar(value=ENERGY_SCOPE)
        self.minimum_energy_rows_var = tk.StringVar(value="50")
        self.adapter_history_cap_var = tk.StringVar(value="2500")
        self.episode_workers_var = tk.StringVar(value="1")
        self.task_limit_var = tk.StringVar(value="0")
        fields = [
            ("Global predictor", self.predictor_var, SUPPORTED_ESTIMATORS),
            ("Frozen SIM", self.replay_sim_var, SUPPORTED_ESTIMATORS),
            ("Adapter", self.adapter_var, ["None", "Calibrator", "ResidualXGB", "WeightedResidualXGB"]),
        ]
        for column, (label, variable, values) in enumerate(fields, start=1):
            ttk.Label(controls, text=label).grid(row=0, column=column, sticky="w", padx=(0, 12))
            ttk.Combobox(controls, textvariable=variable, values=values, state="readonly", width=22).grid(
                row=1, column=column, sticky="w", padx=(0, 12)
            )
        ttk.Label(controls, text="Maximum total rounds").grid(row=2, column=1, sticky="w", pady=(8, 0))
        ttk.Entry(controls, textvariable=self.rounds_var, width=10).grid(row=3, column=1, sticky="w")
        ttk.Label(controls, text="Replay seed").grid(row=2, column=2, sticky="w", pady=(8, 0))
        ttk.Entry(controls, textvariable=self.replay_seed_var, width=10).grid(row=3, column=2, sticky="w")
        ttk.Label(controls, text="BO initialization rounds (1–4)").grid(
            row=2, column=3, sticky="w", pady=(8, 0)
        )
        bo_rounds_combo = ttk.Combobox(
            controls,
            textvariable=self.bo_initialization_rounds_var,
            values=["1", "2", "3", "4"],
            state="readonly",
            width=10,
        )
        bo_rounds_combo.grid(row=3, column=3, sticky="w")
        bo_rounds_combo.bind("<<ComboboxSelected>>", self._refresh_bo_budget_label)

        ttk.Label(controls, text="Adapter history scope").grid(row=4, column=1, sticky="w", pady=(8, 0))
        ttk.Combobox(
            controls,
            textvariable=self.adapter_history_scope_var,
            values=[ENERGY_SCOPE, MACHINE_SCOPE],
            state="readonly",
            width=31,
        ).grid(row=5, column=1, columnspan=2, sticky="w", padx=(0, 12))
        ttk.Label(controls, text="Minimum exact-energy rows").grid(row=4, column=3, sticky="w", pady=(8, 0))
        ttk.Entry(controls, textvariable=self.minimum_energy_rows_var, width=10).grid(row=5, column=3, sticky="w")
        ttk.Label(controls, text="Maximum recent A rows").grid(row=4, column=4, sticky="w", pady=(8, 0))
        ttk.Entry(controls, textvariable=self.adapter_history_cap_var, width=10).grid(row=5, column=4, sticky="w")

        ttk.Label(controls, text="Episode workers (1 / 2 / 4)").grid(row=0, column=4, sticky="w")
        ttk.Combobox(
            controls,
            textvariable=self.episode_workers_var,
            values=["1", "2", "4"],
            state="readonly",
            width=10,
        ).grid(row=1, column=4, sticky="w")
        ttk.Label(controls, text="Tasks to run (0 = all)").grid(row=2, column=4, sticky="w", pady=(8, 0))
        ttk.Entry(controls, textvariable=self.task_limit_var, width=10).grid(row=3, column=4, sticky="w")

        self.bo_label = ttk.Label(
            controls,
            text="BO budget: build the chronological split first. Success: observed target ±5% (locked).",
        )
        self.bo_label.grid(row=6, column=1, columnspan=4, sticky="w", pady=(10, 0))
        self.rounds_var.trace_add("write", self._refresh_bo_budget_label)

        action_row = ttk.Frame(controls)
        action_row.grid(row=7, column=1, columnspan=4, sticky="ew", pady=(8, 2))
        self.run_replay_button = ttk.Button(action_row, text="Run paired replay", command=self._run_replay)
        self.run_replay_button.pack(side="left")
        self.cancel_replay_button = ttk.Button(action_row, text="Cancel after current batch/probe", command=self._cancel_replay, state="disabled")
        self.cancel_replay_button.pack(side="left", padx=6)
        ttk.Button(action_row, text="Export summary + probes", command=self._export_results).pack(side="left")
        self.replay_progress_var = tk.DoubleVar(value=0.0)
        self.replay_progress = ttk.Progressbar(action_row, variable=self.replay_progress_var, maximum=100.0, length=260)
        self.replay_progress.pack(side="left", padx=(14, 6))
        self.replay_status_var = tk.StringVar(value="Idle — select one or more algorithms")
        ttk.Label(action_row, textvariable=self.replay_status_var).pack(side="left")

        columns = (
            "task",
            "energy",
            "algorithm",
            "predictor",
            "sim",
            "adapter",
            "history_used",
            "history_rows",
            "fallback",
            "success",
            "success_phase",
            "cancelled",
            "target",
            "initial",
            "final",
            "init_budget",
            "online_budget",
            "init_rounds",
            "online_rounds",
            "total_probes",
        )
        result_frame = ttk.Frame(self.tab_replay)
        result_frame.pack(fill="both", expand=True, padx=10)
        self.result_tree = ttk.Treeview(result_frame, columns=columns, show="headings", height=21)
        for name in columns:
            self.result_tree.heading(name, text=name.replace("_", " ").title())
            width = 220 if name == "history_used" else (170 if name == "task" else 105)
            self.result_tree.column(name, width=width, anchor="center")
        replay_ybar = ttk.Scrollbar(result_frame, orient="vertical", command=self.result_tree.yview)
        replay_xbar = ttk.Scrollbar(result_frame, orient="horizontal", command=self.result_tree.xview)
        self.result_tree.configure(yscrollcommand=replay_ybar.set, xscrollcommand=replay_xbar.set)
        self.result_tree.grid(row=0, column=0, sticky="nsew")
        replay_ybar.grid(row=0, column=1, sticky="ns")
        replay_xbar.grid(row=1, column=0, sticky="ew")
        result_frame.rowconfigure(0, weight=1)
        result_frame.columnconfigure(0, weight=1)
        self.log_replay = LogBox(self.tab_replay, height=10)
        self.log_replay.pack(fill="x", padx=10, pady=10)

    def _refresh_bo_budget_label(self, *_):
        if self.roles is None:
            self.bo_label.configure(
                text="BO budget: build the chronological split first. Success: observed target ±5% (locked)."
            )
            return
        try:
            dimension = len(self.roles.controllable_cols)
            initialization_rounds = int(self.bo_initialization_rounds_var.get())
            maximum_rounds = int(self.rounds_var.get())
            online_rounds = maximum_rounds - initialization_rounds
            if online_rounds < 0:
                detail = "invalid: initialization exceeds maximum total rounds"
            else:
                detail = (
                    f"{initialization_rounds} × {dimension} = {initialization_rounds * dimension} initialization probes; "
                    f"{online_rounds} online rounds; total budget ≤ {maximum_rounds * dimension} probes"
                )
            self.bo_label.configure(
                text=f"BO budget: {detail}. Success: observed target ±5% (locked)."
            )
        except (TypeError, ValueError):
            self.bo_label.configure(text="BO budget: enter a valid maximum total round count.")

    def _browse(self):
        path = filedialog.askopenfilename(
            filetypes=[("Excel/CSV", "*.xlsx *.xls *.csv"), ("All files", "*.*")]
        )
        if path:
            self.file_var.set(path)

    def _load(self):
        path = self.file_var.get().strip()
        if not path:
            messagebox.showerror("RefineLab V4.0", "Select an Excel or CSV file first.")
            return
        self.frame = load_excel(path)
        # ``prepare_frame`` appends protocol bookkeeping columns to the
        # in-memory frame. They remain available internally for row alignment,
        # but are not user data and can never be an output, target, predictor
        # feature or control.
        self.columns = visible_input_columns(self.frame.columns)
        self.machine_label.configure(text=f"Machine ID: {self.columns[0]} (first column, locked)")
        self.energy_combo.configure(values=self.columns)
        energy = next((x for x in self.columns if "energy" in str(x).lower()), self.columns[1])
        self.energy_var.set(str(energy))
        beam_index = next(
            (
                index
                for index, name in enumerate(self.columns)
                if "beam current" in str(name).lower()
            ),
            None,
        )
        output_start = (beam_index + 1) if beam_index is not None and beam_index >= 1 else len(self.columns)
        self.output_start_var.set(str(output_start))
        self.control_end_var.set(str(max(2, output_start - 1)))
        self.column_text.delete("1.0", "end")
        self.column_text.insert("end", "\n".join(f"{i:>3}: {name}" for i, name in enumerate(self.columns, 1)))
        self._refresh_outputs()
        self.log_data.append(
            f"Loaded {Path(path).name}: {len(self.frame)} rows, {len(self.columns)} columns; "
            f"default output start={output_start} ({self.beam_var.get()})."
        )

    def _refresh_outputs(self):
        if not self.columns:
            return
        start = max(2, min(len(self.columns), _to_int(self.output_start_var.get(), "output start")))
        outputs = self.columns[start - 1 :]
        self.beam_combo.configure(values=outputs)
        beam = next(
            (name for name in outputs if "beam current" in str(name).lower()),
            outputs[-1],
        )
        self.beam_var.set(str(beam))

    def _column_roles(self):
        if self.frame is None:
            raise RuntimeError("Load an Excel or CSV file first.")
        self._refresh_outputs()
        output_start = _to_int(self.output_start_var.get(), "output start")
        control_start = _to_int(self.control_start_var.get(), "control start")
        control_end = _to_int(self.control_end_var.get(), "control end")
        if not (2 <= control_start <= control_end < output_start <= len(self.columns)):
            raise ValueError("Require 2 <= control_start <= control_end < output_start <= number of columns.")
        inputs = self.columns[1 : output_start - 1]
        outputs = self.columns[output_start - 1 :]
        controls = self.columns[control_start - 1 : control_end]
        monitors = [x for x in inputs if x not in controls]
        roles = ColumnRoles(
            machine_id=self.columns[0],
            energy=self.energy_var.get(),
            beam=self.beam_var.get(),
            input_cols=list(inputs),
            controllable_cols=list(controls),
            monitorable_cols=list(monitors),
            output_cols=list(outputs),
            feedback_cols=list(outputs),
        )
        order = _parse_order(self.order_var.get(), len(controls))
        if not self.order_var.get().strip():
            self.order_var.set(",".join(str(i + 1) for i in order))
        return roles, order

    @staticmethod
    def _remove_mapped_shadow_columns(
        roles: ColumnRoles,
        tuning_order: list[int],
        bridge: CoordinateBridge,
    ) -> tuple[ColumnRoles, list[int], list[str]]:
        """Remove processed shadow columns from the model role lists.

        A one-file ablation keeps a processed source column beside its raw
        counterpart.  That source column is not a second physical control and
        must not enter the predictor as an independent feature.  The legacy
        GUI selected one contiguous control interval, so a shadow inserted in
        the middle of that interval could otherwise become an extra control.
        """
        shadows = sorted(
            {
                rule.sim_column
                for rule in bridge.rules.values()
                if rule.sim_column != rule.canonical
            }
        )
        if not shadows:
            return roles, list(tuning_order), []

        shadow_set = set(shadows)
        old_controls = list(roles.controllable_cols)
        ordered_names = [old_controls[index] for index in tuning_order]
        controls = [name for name in old_controls if name not in shadow_set]
        monitors = [name for name in roles.monitorable_cols if name not in shadow_set]
        inputs = [name for name in roles.input_cols if name not in shadow_set]
        # Report every mapped shadow that was present in the original feature
        # list, including one that happened to be in the contiguous controls.
        removed = sorted(set(roles.input_cols).intersection(shadow_set))
        new_roles = ColumnRoles(
            machine_id=roles.machine_id,
            energy=roles.energy,
            beam=roles.beam,
            input_cols=inputs,
            controllable_cols=controls,
            monitorable_cols=monitors,
            output_cols=list(roles.output_cols),
            feedback_cols=list(roles.feedback_cols),
        )
        new_roles.validate(list(roles.input_cols) + list(roles.output_cols) + [roles.machine_id])
        new_order_names = [name for name in ordered_names if name in controls]
        new_order = [controls.index(name) for name in new_order_names]
        if sorted(new_order) != list(range(len(controls))):
            new_order = list(range(len(controls)))
        return new_roles, new_order, removed

    def _build_split(self):
        roles, order = self._column_roles()
        config = GlobalTaskSplitConfig(
            global_training_fraction=_to_float(self.global_fraction_var.get(), "Global Training fraction"),
            future_task_fraction=_to_float(self.future_fraction_var.get(), "Future Task fraction"),
            min_global_training=_to_int(self.min_global_var.get(), "Global Training minimum"),
            min_future_tasks=_to_int(self.min_future_var.get(), "Future Task minimum"),
        )
        split = global_task_temporal_split(self.frame, roles.machine_id, config)
        mode = "ablation" if self.ablation_var.get() else "standard"
        bridge = (
            parse_mapping_text(
                self.mapping_text.get("1.0", "end"),
                roles,
                self.columns,
                mode=mode,
            )
            if mode == "ablation"
            else CoordinateBridge(mode="standard")
        )
        removed_shadows: list[str] = []
        if mode == "ablation":
            roles, order, removed_shadows = self._remove_mapped_shadow_columns(roles, order, bridge)
            if removed_shadows:
                self.log_data.append(
                    "Mapped processed shadow columns excluded from predictor/control roles: "
                    + ", ".join(removed_shadows)
                )
                self.order_var.set(",".join(str(index + 1) for index in order))
        # Validate after mapped SIM shadows have been removed.  This permits
        # the one-file ablation setup to start with both Focus Voltage(kV) and
        # Focus_Bias visible in the table, while still preventing both physical
        # representations from entering a model.
        roles.validate(self.columns)
        solver_annotated, sim_annotated = bridge.build_views(split.annotated, roles)
        solver_bounds = derive_global_training_bounds(solver_annotated, roles)
        sim_bounds = derive_global_training_bounds(sim_annotated, roles)
        self.roles = roles
        self.tuning_order = order
        self.split_result = split
        self.solver_annotated = solver_annotated
        self.sim_annotated = sim_annotated
        self.coordinate_bridge = bridge
        self.bounds = solver_bounds
        self.sim_bounds = sim_bounds
        self.global_catalog = self.simulator_catalog = None
        self.manifest = self.replay_results = None
        for item in self.split_tree.get_children():
            self.split_tree.delete(item)
        for report in split.reports:
            self.split_tree.insert(
                "", "end", values=(
                    report.machine_id,
                    report.total_rows,
                    "Yes" if report.eligible else "No",
                    report.global_training_rows,
                    report.future_task_rows,
                    report.reason,
                )
            )
        self.bounds_text.delete("1.0", "end")
        self.bounds_text.insert(
            "end",
            "\n".join(
                f"{name}\t{bound.minimum:.12g}\t{bound.maximum:.12g}\t{bound.resolution:.12g}\t0"
                for name, bound in solver_bounds.items()
            ),
        )
        self.sim_bounds_text.delete("1.0", "end")
        self.sim_bounds_text.insert(
            "end",
            "\n".join(
                f"{name}\t{bound.minimum:.12g}\t{bound.maximum:.12g}\t{bound.resolution:.12g}\t0"
                for name, bound in sim_bounds.items()
            ),
        )
        self._refresh_bo_budget_label()
        total_future = sum(x.future_task_rows for x in split.reports if x.eligible)
        self.log_data.append(
            f"Built chronological split for {len(split.eligible_machine_ids)} machines; total Future Replay Task rows={total_future}; coordinate mode={mode}."
        )
        self.log_data.append(
            "Active target=" + str(roles.beam)
            + "; controllables=" + ", ".join(map(str, roles.controllable_cols))
            + "; monitorables=" + ", ".join(map(str, roles.monitorable_cols))
        )
        if bridge.rules:
            validation = bridge.validate_existing_columns(self.frame, roles)
            self.log_data.append("Coordinate transform validation:")
            self.log_data.append(validation.to_string(index=False))
        self.log_data.append(
            "Adapter history policy: same-machine Global Training rows; exact task Energy by default, with declared fallback."
        )
        self._audit()

    def _read_bounds(self, widget: tk.Text | None = None):
        if self.roles is None:
            raise RuntimeError("Build the chronological split first.")
        widget = widget or self.bounds_text
        parsed = {}
        for line in widget.get("1.0", "end").strip().splitlines():
            parts = [x.strip() for x in line.split("\t")]
            if len(parts) in {4, 5}:
                max_delta_range = 0.0 if len(parts) == 4 else float(parts[4])
                parsed[parts[0]] = ControlBound(
                    float(parts[1]),
                    float(parts[2]),
                    float(parts[3]),
                    max_delta_per_probe=0,
                    max_delta_range=max_delta_range,
                )
        missing = [x for x in self.roles.controllable_cols if x not in parsed]
        if missing:
            raise ValueError(f"Missing control bounds: {missing}")
        for value in parsed.values():
            value.validate()
        return parsed

    def _audit(self):
        if self.split_result is None or self.roles is None or self.solver_annotated is None:
            messagebox.showinfo("Leakage Audit", "Build the chronological split first.")
            return
        report = audit_global_task_protocol(self.solver_annotated, self.roles, self.manifest)
        self.log_data.append(report.as_text())
        (messagebox.showinfo if report.passed else messagebox.showerror)("Leakage Audit", report.as_text())

    def _selected_estimators(self):
        values = []
        if self.use_xgb_var.get():
            values.append(XGBOOST_NAME)
        if self.use_rf_var.get():
            values.append(RANDOM_FOREST_NAME)
        if not values:
            raise ValueError("Select at least one estimator.")
        return values

    def _train_models(self):
        if self.split_result is None or self.roles is None or self.solver_annotated is None or self.sim_annotated is None:
            messagebox.showerror("RefineLab V4.0", "Build the chronological split first.")
            return
        estimators = self._selected_estimators()
        folds = _to_int(self.folds_var.get(), "folds")
        if not 2 <= folds <= 10:
            raise ValueError("Random folds must be between 2 and 10.")

        def progress(message: str):
            self.root.after(0, lambda m=message: self.log_models.append(m))

        def action():
            global_catalog = train_global_predictor_catalog(
                self.solver_annotated, self.roles, estimators, folds=folds, seed=42, progress=progress
            )
            simulator_catalog = train_simulator_catalog(
                self.sim_annotated, self.roles, estimators, folds=folds, seed=42, progress=progress
            )
            self.global_catalog, self.simulator_catalog = global_catalog, simulator_catalog

            def finish():
                for item in self.metric_tree.get_children():
                    self.metric_tree.delete(item)
                for metric in global_catalog.metrics + simulator_catalog.metrics:
                    self.metric_tree.insert(
                        "", "end", values=(
                            metric.model_role,
                            metric.estimator,
                            metric.machine_id,
                            metric.evaluation,
                            f"{metric.mape_percent:.3f}",
                            f"{metric.median_ape_percent:.3f}",
                            f"{metric.signed_bias_percent:.3f}",
                            f"{metric.r2:.4f}",
                            metric.n_train,
                            metric.n_evaluation,
                            metric.folds or "—",
                        )
                    )
                for estimator in estimators:
                    rows = [x for x in global_catalog.metrics if x.estimator == estimator and x.model_role == "Global predictor"]
                    oof = next(x for x in rows if "out-of-fold" in x.evaluation)
                    future = next(x for x in rows if "out-of-time" in x.evaluation)
                    self.log_models.append(
                        f"[{estimator}] Drift-oriented comparison: Global Training OOF MAPE={oof.mape_percent:.3f}% -> "
                        f"Future Tasks MAPE={future.mape_percent:.3f}% (Δ={future.mape_percent-oof.mape_percent:+.3f} points)."
                    )
                self.log_models.append(
                    "SIM cross-validation completed; every final per-machine SIM was then refitted on 100% of that machine and frozen."
                )

            self.root.after(0, finish)

        self._start_worker(action, self.log_models)

    def _toggle_all_future_mode(self):
        enabled = self.all_future_var.get()
        self.tasks_n_entry.configure(state="disabled" if enabled else "normal")
        self.task_status_var.set(
            "All eligible Future rows will be processed; Tasks count is ignored"
            if enabled
            else "Random subset mode; Tasks count is active"
        )

    def _generate_tasks(self):
        if any(x is None for x in (self.split_result, self.roles, self.solver_annotated, self.sim_annotated, self.simulator_catalog, self.coordinate_bridge)):
            messagebox.showerror("RefineLab V4.0", "Build the split and train models first.")
            return
        if self.task_generation_running:
            messagebox.showinfo("RefineLab V4.0", "Task generation is already running.")
            return
        simulator_estimator = self.task_sim_var.get()
        if simulator_estimator not in self.simulator_catalog.models:
            messagebox.showerror("RefineLab V4.0", f"SIM not trained: {simulator_estimator}")
            return
        self.bounds = self._read_bounds(self.bounds_text)
        self.sim_bounds = self._read_bounds(self.sim_bounds_text)
        all_future = self.all_future_var.get()
        config = TaskGenerationConfig(
            n_tasks=1 if all_future else _to_int(self.tasks_n_var.get(), "tasks"),
            all_future_tasks=all_future,
            seed=_to_int(self.tasks_seed_var.get(), "task seed"),
            difficulty_threshold=_to_float(self.diff_var.get(), "difficulty"),
            beam_max=_to_float(self.beam_max_var.get(), "beam max"),
            degradation_ratio=_to_float(self.degrade_var.get(), "degradation ratio"),
            max_reference_error_fraction=_to_float(self.ref_error_var.get(), "reference error"),
            initial_search_samples=_to_int(self.init_search_var.get(), "initial search samples"),
        )
        config.validate()
        environment = self.simulator_catalog.as_environment_set(simulator_estimator)
        self.task_generation_cancel_event = threading.Event()
        self.task_generation_running = True
        self.generate_tasks_button.configure(state="disabled")
        self.cancel_tasks_button.configure(state="normal")
        self.task_progress_var.set(0.0)
        self.task_status_var.set("Preparing eligible Future rows...")

        def progress(processed: int, total: int, generated: int, stage: str):
            self.root.after(
                0,
                lambda p=processed, t=total, g=generated, s=stage: self._update_task_progress(p, t, g, s),
            )

        def action():
            try:
                manifest = generate_task_manifest(
                    self.solver_annotated,
                    self.roles,
                    environment,
                    self.bounds,
                    self.tuning_order,
                    config,
                    simulator_estimator=simulator_estimator,
                    sim_annotated=self.sim_annotated,
                    bridge=self.coordinate_bridge,
                    sim_bounds=self.sim_bounds,
                    progress=progress,
                    cancel_event=self.task_generation_cancel_event,
                )
                if manifest.tasks:
                    report = audit_global_task_protocol(self.solver_annotated, self.roles, manifest)
                    if not report.passed:
                        raise RuntimeError(report.as_text())
                self.manifest = manifest
                self.root.after(0, lambda m=manifest: self._show_manifest(m))
            except Exception:
                self.root.after(0, lambda: self.task_status_var.set("Generation failed — inspect the log"))
                raise
            finally:
                self.root.after(0, self._reset_task_generation_buttons)

        self._start_worker(action, self.log_tasks)

    def _update_task_progress(self, processed: int, total: int, generated: int, stage: str):
        self.task_progress_var.set(100.0 * processed / max(total, 1))
        self.task_status_var.set(
            f"{stage}: processed {processed:,}/{total:,}; generated {generated:,}"
        )

    def _cancel_task_generation(self):
        if self.task_generation_running and self.task_generation_cancel_event is not None:
            self.task_generation_cancel_event.set()
            self.task_status_var.set("Cancellation requested; waiting for the current SIM batch...")
            self.log_tasks.append("Cancellation requested. A completed partial manifest may still be exported.")

    def _reset_task_generation_buttons(self):
        self.task_generation_running = False
        self.generate_tasks_button.configure(state="normal")
        self.cancel_tasks_button.configure(state="disabled")

    def _show_manifest(self, manifest: TaskManifest):
        for item in self.task_tree.get_children():
            self.task_tree.delete(item)
        for task in manifest.tasks[:TASK_PREVIEW_LIMIT]:
            self.task_tree.insert(
                "", "end", values=(
                    task.task_id,
                    task.machine_id,
                    f"{task.energy:g}",
                    task.simulator_estimator,
                    task.source_order,
                    f"{task.target_beam:.3f}",
                    f"{task.initial_beam:.3f}",
                    f"{task.degradation_ratio_achieved:.3f}",
                    f"{task.reference_error_fraction:.3f}",
                )
            )
        if not manifest.tasks:
            self.task_status_var.set("Cancelled before any task was completed")
            self.log_tasks.append("No completed task is available in the manifest.")
            return
        self.replay_sim_var.set(manifest.tasks[0].simulator_estimator or self.replay_sim_var.get())
        generation_mode = manifest.tasks[0].generation_mode
        initial_state_policies = sorted({task.initial_state_selection for task in manifest.tasks})
        self.log_tasks.append(
            f"Generated {len(manifest.tasks):,}/{manifest.requested_tasks:,} frozen Future Replay Tasks "
            f"using {manifest.tasks[0].simulator_estimator} SIM; mode={generation_mode}; "
            f"initial-state policy={initial_state_policies}."
        )
        if any(policy.startswith("Legacy nearest") for policy in initial_state_policies):
            self.log_tasks.append(
                "CAUTION: this is a legacy V3.3 manifest whose degraded start was chosen nearest to the threshold. "
                "Regenerate it to use the restored legacy random-degradation protocol."
            )
        if any("halved after" in policy for policy in initial_state_policies):
            self.log_tasks.append(
                "Legacy half-value fallback is recorded per task when all random degradation attempts miss; "
                "such a start is not forced to satisfy the threshold."
            )
        self.log_tasks.append(
            f"Excluded: invalid rows={manifest.excluded_invalid_rows:,}; "
            f"reference fidelity={manifest.excluded_reference_fidelity:,}; "
            f"no degraded start={manifest.excluded_no_degraded_start:,}."
        )
        if len(manifest.tasks) > TASK_PREVIEW_LIMIT:
            self.log_tasks.append(
                f"GUI preview is limited to the first {TASK_PREVIEW_LIMIT:,} rows; export and replay retain all {len(manifest.tasks):,} tasks."
            )
        if manifest.cancelled:
            self.task_status_var.set(f"Cancelled: {len(manifest.tasks):,} completed tasks available")
        else:
            self.task_progress_var.set(100.0)
            self.task_status_var.set(f"Finished: {len(manifest.tasks):,} tasks ready for export/replay")

    def _load_tasks(self):
        if self.split_result is None or self.roles is None or self.solver_annotated is None:
            messagebox.showerror("RefineLab V4.0", "Build the split first.")
            return
        path = filedialog.askopenfilename(filetypes=[("CSV", "*.csv"), ("All files", "*.*")])
        if not path:
            return
        manifest = TaskManifest.from_frame(pd.read_csv(path))
        report = audit_global_task_protocol(self.solver_annotated, self.roles, manifest)
        if not report.passed:
            messagebox.showerror("Task manifest", report.as_text())
            return
        self.manifest = manifest
        self._show_manifest(manifest)

    def _run_replay(self):
        if any(x is None for x in (self.manifest, self.roles, self.split_result, self.solver_annotated, self.global_catalog, self.simulator_catalog, self.coordinate_bridge)):
            messagebox.showerror("RefineLab V4.0", "Train models and generate/load tasks first.")
            return
        if self.replay_running:
            messagebox.showinfo("RefineLab V4.0", "A replay run is already active.")
            return
        algorithms = [self.algorithm_list.get(i) for i in self.algorithm_list.curselection()]
        if not algorithms:
            messagebox.showerror("RefineLab V4.0", "Select at least one algorithm. No algorithm is selected by default.")
            return
        predictor_estimator = self.predictor_var.get()
        simulator_estimator = self.replay_sim_var.get()
        if predictor_estimator not in self.global_catalog.models:
            raise ValueError(f"Global predictor not trained: {predictor_estimator}")
        if simulator_estimator not in self.simulator_catalog.models:
            raise ValueError(f"SIM not trained: {simulator_estimator}")
        manifest_simulators = {x.simulator_estimator for x in self.manifest.tasks if x.simulator_estimator}
        if manifest_simulators and manifest_simulators != {simulator_estimator}:
            messagebox.showerror(
                "RefineLab V4.0",
                f"Task manifest was frozen with {sorted(manifest_simulators)}, but replay selected {simulator_estimator}. Regenerate tasks or select the matching SIM.",
            )
            return
        self.bounds = self._read_bounds(self.bounds_text)
        self.sim_bounds = self._read_bounds(self.sim_bounds_text)
        maximum_rounds = _to_int(self.rounds_var.get(), "maximum rounds")
        bo_initialization_rounds = _to_int(
            self.bo_initialization_rounds_var.get(), "BO initialization rounds"
        )
        if bo_initialization_rounds > maximum_rounds:
            messagebox.showerror(
                "RefineLab V4.0",
                "BO initialization rounds cannot exceed maximum total rounds.",
            )
            return
        config = ReplayConfig(
            max_rounds=maximum_rounds,
            tolerance_fraction=0.05,
            seed=_to_int(self.replay_seed_var.get(), "replay seed"),
            bo_initialization_rounds=bo_initialization_rounds,
        )
        config.validate()
        adapter_name = self.adapter_var.get()
        history_scope = self.adapter_history_scope_var.get()
        minimum_energy_rows = _to_int(self.minimum_energy_rows_var.get(), "minimum exact-energy rows")
        history_cap = _to_int(self.adapter_history_cap_var.get(), "maximum recent A rows")
        episode_workers = _to_int(self.episode_workers_var.get(), "episode workers")
        task_limit = _to_int(self.task_limit_var.get(), "tasks to run")
        if minimum_energy_rows < 2:
            raise ValueError("Minimum exact-energy rows must be at least 2.")
        if history_cap < 2:
            raise ValueError("Maximum recent A rows must be at least 2.")
        if episode_workers not in {1, 2, 4}:
            raise ValueError("Episode workers must be 1, 2 or 4.")
        if task_limit < 0:
            raise ValueError("Tasks to run must be 0 or a positive integer.")
        selected_tasks = self.manifest.tasks if task_limit == 0 else self.manifest.tasks[:task_limit]
        run_manifest = TaskManifest(
            list(selected_tasks),
            len(selected_tasks),
            self.manifest.candidate_rows,
            self.manifest.excluded_reference_fidelity,
            self.manifest.excluded_no_degraded_start,
            self.manifest.seed,
        )
        global_set = self.global_catalog.as_model_set(predictor_estimator)
        environment_set = self.simulator_catalog.as_environment_set(simulator_estimator)
        adapter_factory_name = (
            "xgboost"
            if adapter_name in {"ResidualXGB", "WeightedResidualXGB"}
            else EstimatorFactoryV33(predictor_estimator).adapter_factory_name
        )
        adapter_factory = RegressorFactory(adapter_factory_name, seed=config.seed, profile="adapter")

        self.replay_cancel_event = threading.Event()
        self.replay_results = ReplayResults([], [])
        self.replay_running = True
        self.run_replay_button.configure(state="disabled")
        self.cancel_replay_button.configure(state="normal")
        self.replay_progress_var.set(0.0)
        self.replay_status_var.set("Preparing Adapter history cache...")
        for item in self.result_tree.get_children():
            self.result_tree.delete(item)

        total_episodes = len(run_manifest.tasks) * len(algorithms)

        def progress(summary, probes, completed: int, total: int):
            # ReplayRunner serializes progress callbacks even when episodes use workers.
            self.replay_results.summaries.append(summary)
            self.replay_results.probes.extend(probes)
            self.root.after(
                0,
                lambda s=summary, c=completed, t=total: self._append_result(s, c, t),
            )

        def status(message: str):
            self.root.after(0, lambda m=message: self.replay_status_var.set(m))

        def action():
            try:
                runner = ReplayRunner(
                    self.solver_annotated,
                    self.roles,
                    self.bounds,
                    self.tuning_order,
                    global_set,
                    environment_set,
                    adapter_factory,
                    config,
                    predictor_estimator=predictor_estimator,
                    simulator_estimator=simulator_estimator,
                    adapter_history_scope=history_scope,
                    minimum_energy_history_rows=minimum_energy_rows,
                    adapter_history_cap=history_cap,
                    bridge=self.coordinate_bridge,
                    sim_bounds=self.sim_bounds,
                )
                self.root.after(
                    0,
                    lambda: self.log_replay.append(
                        f"Running {len(run_manifest.tasks)} frozen tasks × {len(algorithms)} algorithms "
                        f"= {total_episodes} episodes; predictor={predictor_estimator}, SIM={simulator_estimator}, "
                        f"A={history_scope}, workers={episode_workers}; BO init={bo_initialization_rounds} round(s), "
                        f"BO online budget={config.bo_online_rounds_budget} round(s); "
                        f"movement-limited solver controls="
                        f"{sum(not bound.unrestricted for bound in self.bounds.values())}/"
                        f"{len(self.bounds)}."
                    ),
                )
                results = runner.run(
                    run_manifest,
                    algorithms,
                    adapter_name,
                    episode_workers=episode_workers,
                    cancel_event=self.replay_cancel_event,
                    progress_callback=progress,
                    status_callback=status,
                )
                self.replay_results = results
                self.root.after(0, lambda r=results: self._finish_replay(r))
            except Exception:
                self.root.after(0, lambda: self.replay_status_var.set("Replay failed — inspect the log"))
                raise
            finally:
                self.root.after(0, self._reset_replay_buttons)

        self._start_worker(action, self.log_replay)

    def _append_result(self, value, completed: int, total: int):
        self.result_tree.insert(
            "", "end", values=(
                value.task_id,
                f"{value.energy:g}",
                value.algorithm,
                value.predictor_estimator,
                value.simulator_estimator,
                value.adapter,
                value.adapter_history_used,
                value.adapter_history_used_rows,
                "Yes" if value.adapter_history_fallback else "No",
                "Yes" if value.success else "No",
                value.first_success_phase or "—",
                "Yes" if value.cancelled else "No",
                f"{value.target:.2f}",
                f"{value.initial_beam:.2f}",
                f"{value.final_beam:.2f}",
                value.initialization_rounds_budget,
                value.online_rounds_budget,
                value.initialization_rounds,
                value.online_rounds,
                value.total_probes,
            )
        )
        self.replay_progress_var.set(100.0 * completed / max(total, 1))
        self.replay_status_var.set(f"Completed {completed}/{total} episodes")

    def _cancel_replay(self):
        if self.replay_cancel_event is not None and self.replay_running:
            self.replay_cancel_event.set()
            self.replay_status_var.set("Cancellation requested; waiting for the current prediction batch/probe...")
            self.log_replay.append("Cancellation requested. Completed episode rows remain exportable.")

    def _reset_replay_buttons(self):
        self.replay_running = False
        self.run_replay_button.configure(state="normal")
        self.cancel_replay_button.configure(state="disabled")

    def _finish_replay(self, results: ReplayResults):
        if not results.summaries:
            self.replay_status_var.set("Stopped before any episode completed")
            self.log_replay.append("No episode completed. No result rows are available to export.")
            return
        table = results.summary_frame()
        aggregate = table.groupby(["predictor_estimator", "simulator_estimator", "algorithm"]).agg(
            physical_success_rate=("success", "mean"),
            initialization_hit_rate=("initialization_success", "mean"),
            online_success_rate=("online_success", "mean"),
            mean_total_rounds=("total_rounds", "mean"),
            mean_online_rounds=("online_rounds", "mean"),
            mean_total_probes=("total_probes", "mean"),
            mean_clipped_probe_fraction=("clipped_probe_fraction", "mean"),
        )
        self.log_replay.append(aggregate.to_string(float_format=lambda x: f"{x:.4f}"))
        if "initialization_success" in table and "online_success" in table:
            initialization_hits = table["initialization_success"].astype(bool)
            remaining = ~initialization_hits
            post_initialization_rate = (
                float(table.loc[remaining, "online_success"].mean())
                if remaining.any()
                else float("nan")
            )
            self.log_replay.append(
                f"BO initialization-hit rate={initialization_hits.mean():.2%}; "
                f"post-initialization online success among non-hit episodes="
                f"{post_initialization_rate:.2%} (n={int(remaining.sum()):,})."
            )
        reference_rate = float(table["reference_within_tolerance"].mean())
        reachable_reference_rate = float(table["reference_solution_in_search_space"].mean())
        initial_in_bounds_rate = float(table["initial_controls_within_bounds"].mean())
        median_initial_ratio = float(table["initial_target_ratio"].median())
        self.log_replay.append(
            f"Replay-difficulty audit: reference response within tolerance={reference_rate:.2%}; "
            f"reference solution inside current bounds={reachable_reference_rate:.2%}; "
            f"initial controls inside current bounds={initial_in_bounds_rate:.2%}; "
            f"median initial/target={median_initial_ratio:.3f}."
        )
        if reachable_reference_rate >= 0.95 and median_initial_ratio >= 0.85:
            self.log_replay.append(
                "CAUTION: this manifest contains mostly SIM-feasible, near-threshold tasks. "
                "Absolute virtual success rates may be optimistic; use paired efficiency and failure-stratified results."
            )
        cancelled = bool(self.replay_cancel_event and self.replay_cancel_event.is_set())
        self.replay_status_var.set(
            f"{'Cancelled' if cancelled else 'Finished'}: {len(results.summaries)} episode(s); results can be exported"
        )

    def _export_roles(self):
        if self.split_result is None or self.solver_annotated is None:
            messagebox.showerror("RefineLab V4.0", "Build the split first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="refinelab_v40_solver_roles.csv")
        if path:
            self.solver_annotated.to_csv(path, index=False, encoding="utf-8-sig")

    def _export_sim_roles(self):
        if self.sim_annotated is None:
            messagebox.showerror("RefineLab V4.0", "Build the split first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            initialfile="refinelab_v40_sim_roles.csv",
        )
        if path:
            self.sim_annotated.to_csv(path, index=False, encoding="utf-8-sig")

    def _export_metrics(self):
        if self.global_catalog is None or self.simulator_catalog is None:
            messagebox.showerror("RefineLab V4.0", "Train models first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="refinelab_v40_model_metrics.csv")
        if path:
            rows = [x.__dict__ for x in self.global_catalog.metrics + self.simulator_catalog.metrics]
            pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")

    def _export_tasks(self):
        if self.manifest is None:
            messagebox.showerror("RefineLab V4.0", "Generate tasks first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="refinelab_v40_frozen_tasks.csv")
        if path:
            self.manifest.to_frame().to_csv(path, index=False, encoding="utf-8-sig")

    def _export_results(self):
        if self.replay_results is None:
            messagebox.showerror("RefineLab V4.0", "Run paired replay first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="refinelab_v40_summary.csv")
        if not path:
            return
        summary_path = Path(path)
        probes_path = summary_path.with_name(summary_path.stem + "_probes.csv")
        snapshot = ReplayResults(
            list(self.replay_results.summaries),
            list(self.replay_results.probes),
        )
        snapshot.summary_frame().to_csv(summary_path, index=False, encoding="utf-8-sig")
        snapshot.probe_frame().to_csv(probes_path, index=False, encoding="utf-8-sig")
        messagebox.showinfo("RefineLab V4.0", f"Saved:\n{summary_path}\n{probes_path}")


RefineLabV35App = RefineLabV40App


def main():
    root = tk.Tk()
    RefineLabV40App(root)
    root.mainloop()
