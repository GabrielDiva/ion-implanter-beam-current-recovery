from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score

from .config import ColumnRoles, ROLE_ENVIRONMENT, ROLE_GLOBAL, ROLE_TASK
from .data import ROLE_COL, numeric_matrix
from .splits import grouped_chronological_validation


def safe_mape_percent(y_true: np.ndarray, y_pred: np.ndarray, eps: float = 1e-6) -> float:
    y_true = np.asarray(y_true, dtype=float).reshape(-1)
    y_pred = np.asarray(y_pred, dtype=float).reshape(-1)
    denom = np.clip(np.abs(y_true), eps, None)
    return float(np.mean(np.abs(y_true - y_pred) / denom) * 100.0)


@dataclass(frozen=True)
class ModelMetric:
    scope: str
    machine_id: str
    output: str
    mape_percent: float
    r2: float
    n_train: int
    n_test: int
    split: str
    estimator: str


class RegressorFactory:
    def __init__(self, estimator: str = "xgboost", seed: int = 42, profile: str = "research"):
        self.estimator = estimator.lower().strip()
        self.seed = int(seed)
        self.profile = profile.lower().strip()

    def create(self, seed_offset: int = 0) -> Any:
        seed = self.seed + int(seed_offset)
        if self.estimator in {"xgboost", "xgb"}:
            try:
                from xgboost import XGBRegressor
            except ImportError as exc:
                raise RuntimeError(
                    "XGBoost is not installed. Run 'pip install -r requirements.txt', "
                    "or select Random Forest."
                ) from exc
            online_profile = self.profile == "online"
            adapter_profile = self.profile in {"adapter", "online", "lightweight"}
            return XGBRegressor(
                n_estimators=60 if online_profile else (180 if adapter_profile else 1200),
                learning_rate=0.06 if adapter_profile else 0.05,
                max_depth=3 if online_profile else (4 if adapter_profile else 8),
                subsample=0.9,
                colsample_bytree=0.9,
                reg_alpha=0.1,
                reg_lambda=1.0,
                random_state=seed,
                # Adapter models may be trained by several episode workers.
                # One thread each avoids nested CPU oversubscription.
                n_jobs=1 if adapter_profile else -1,
                objective="reg:squarederror",
            )
        if self.estimator in {"random_forest", "randomforest", "rf"}:
            online_profile = self.profile == "online"
            adapter_profile = self.profile in {"adapter", "online", "lightweight"}
            return RandomForestRegressor(
                n_estimators=80 if online_profile else (160 if adapter_profile else 350),
                max_features=0.8,
                min_samples_leaf=1,
                random_state=seed,
                n_jobs=1 if adapter_profile else -1,
            )
        raise ValueError(f"Unknown estimator: {self.estimator}")


def _clean_xy(frame: pd.DataFrame, feature_cols: Iterable[str], output: str):
    feature_cols = list(feature_cols)
    X = numeric_matrix(frame, feature_cols)
    y = pd.to_numeric(frame[output], errors="coerce").to_numpy(dtype=float)
    mask = np.isfinite(X).all(axis=1) & np.isfinite(y)
    return X[mask], y[mask]


def _metric(
    model: Any,
    train_frame: pd.DataFrame,
    test_frame: pd.DataFrame,
    feature_cols: list[str],
    output: str,
    scope: str,
    machine_id: str,
    estimator: str,
    split: str,
) -> ModelMetric:
    X_train, y_train = _clean_xy(train_frame, feature_cols, output)
    X_test, y_test = _clean_xy(test_frame, feature_cols, output)
    if len(X_train) < 2 or len(X_test) < 1:
        raise ValueError(f"Insufficient clean rows for {scope}/{machine_id}/{output}")
    pred = np.asarray(model.predict(X_test), dtype=float).reshape(-1)
    r2 = float(r2_score(y_test, pred)) if len(y_test) >= 2 else float("nan")
    return ModelMetric(
        scope=scope,
        machine_id=str(machine_id),
        output=output,
        mape_percent=safe_mape_percent(y_test, pred),
        r2=r2,
        n_train=len(X_train),
        n_test=len(X_test),
        split=split,
        estimator=estimator,
    )


@dataclass
class GlobalModelSet:
    models: Dict[str, Any] = field(default_factory=dict)
    metrics: list[ModelMetric] = field(default_factory=list)

    def predict_one(self, output: str, feature_vector: np.ndarray) -> float:
        model = self.models[output]
        return float(model.predict(np.asarray(feature_vector, dtype=float).reshape(1, -1))[0])


@dataclass
class HiddenEnvironmentSet:
    models: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    metrics: list[ModelMetric] = field(default_factory=list)

    def has_machine(self, machine_id: object) -> bool:
        return str(machine_id) in self.models

    def predict(self, machine_id: object, feature_vector: np.ndarray) -> Dict[str, float]:
        key = str(machine_id)
        if key not in self.models:
            raise KeyError(f"No hidden environment for machine: {machine_id}")
        X = np.asarray(feature_vector, dtype=float).reshape(1, -1)
        return {
            output: float(model.predict(X)[0])
            for output, model in self.models[key].items()
        }

    def predict_many(self, machine_id: object, feature_matrix: np.ndarray) -> Dict[str, np.ndarray]:
        """Vectorized frozen-SIM prediction used by scalable task generation."""
        key = str(machine_id)
        if key not in self.models:
            raise KeyError(f"No hidden environment for machine: {machine_id}")
        X = np.asarray(feature_matrix, dtype=float)
        if X.ndim != 2:
            raise ValueError("feature_matrix must be a two-dimensional array")
        return {
            output: np.asarray(model.predict(X), dtype=float).reshape(-1)
            for output, model in self.models[key].items()
        }

    def predict_output_many(
        self,
        machine_id: object,
        output: str,
        feature_matrix: np.ndarray,
    ) -> np.ndarray:
        key = str(machine_id)
        if key not in self.models or output not in self.models[key]:
            raise KeyError(f"No hidden environment output {output!r} for machine: {machine_id}")
        X = np.asarray(feature_matrix, dtype=float)
        if X.ndim != 2:
            raise ValueError("feature_matrix must be a two-dimensional array")
        return np.asarray(self.models[key][output].predict(X), dtype=float).reshape(-1)


def train_global_models(
    annotated: pd.DataFrame,
    roles: ColumnRoles,
    factory: RegressorFactory,
    validation_fraction: float = 0.15,
) -> GlobalModelSet:
    visible = annotated[annotated[ROLE_COL] == ROLE_GLOBAL].copy()
    train, valid = grouped_chronological_validation(
        visible, roles.machine_id, validation_fraction=validation_fraction
    )
    result = GlobalModelSet()
    for i, output in enumerate(roles.output_cols):
        X_train, y_train = _clean_xy(train, roles.feature_cols, output)
        if len(X_train) < 10:
            continue
        evaluation_model = factory.create(seed_offset=i)
        evaluation_model.fit(X_train, y_train)
        result.metrics.append(
            _metric(
                evaluation_model,
                train,
                valid,
                roles.feature_cols,
                output,
                scope="GLOBAL",
                machine_id="ALL",
                estimator=factory.estimator,
                split="within-tool chronological tail of G",
            )
        )
        X_all, y_all = _clean_xy(visible, roles.feature_cols, output)
        final_model = factory.create(seed_offset=10_000 + i)
        final_model.fit(X_all, y_all)
        result.models[output] = final_model
    if roles.beam not in result.models:
        raise RuntimeError("Beam global model could not be trained.")
    return result


def train_hidden_environments(
    annotated: pd.DataFrame,
    roles: ColumnRoles,
    factory: RegressorFactory,
) -> HiddenEnvironmentSet:
    result = HiddenEnvironmentSet()
    machine_ids = annotated.loc[annotated[ROLE_COL] == ROLE_ENVIRONMENT, roles.machine_id].dropna().unique()
    for machine_offset, machine_id in enumerate(machine_ids):
        env_train = annotated[
            (annotated[roles.machine_id] == machine_id)
            & (annotated[ROLE_COL] == ROLE_ENVIRONMENT)
        ]
        task_test = annotated[
            (annotated[roles.machine_id] == machine_id)
            & (annotated[ROLE_COL] == ROLE_TASK)
        ]
        key = str(machine_id)
        models: Dict[str, Any] = {}
        for output_offset, output in enumerate(roles.output_cols):
            X_train, y_train = _clean_xy(env_train, roles.feature_cols, output)
            X_test, _ = _clean_xy(task_test, roles.feature_cols, output)
            if len(X_train) < 8 or len(X_test) < 1:
                continue
            model = factory.create(seed_offset=20_000 + machine_offset * 100 + output_offset)
            model.fit(X_train, y_train)
            models[output] = model
            result.metrics.append(
                _metric(
                    model,
                    env_train,
                    task_test,
                    roles.feature_cols,
                    output,
                    scope="HIDDEN_ENV",
                    machine_id=key,
                    estimator=factory.estimator,
                    split="E train -> T chronological future test",
                )
            )
        if roles.beam in models:
            result.models[key] = models
    if not result.models:
        raise RuntimeError("No eligible per-machine hidden environment could be trained.")
    return result
