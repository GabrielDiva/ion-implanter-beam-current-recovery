from __future__ import annotations

from dataclasses import dataclass, field
from numbers import Integral
from typing import Dict, List, Optional

import numpy as np


def _column_key(value: str) -> str:
    """Normalize a header for the two mutually exclusive focus encodings."""
    return "".join(character for character in str(value).casefold() if character.isalnum())


ROLE_GLOBAL = "G"
ROLE_ADAPTER = "A"
ROLE_ENVIRONMENT = "E"
ROLE_TASK = "T"
ROLE_ORDER = (ROLE_GLOBAL, ROLE_ADAPTER, ROLE_ENVIRONMENT, ROLE_TASK)

# Paper-facing names. These are deliberately verbose in the GUI and exports.
GLOBAL_TRAINING_ROLE = "Global predictor training (first 85% within each machine)"
FUTURE_TASK_ROLE = "Future replay tasks (last 15% within each machine)"
GT_ROLE_ORDER = (GLOBAL_TRAINING_ROLE, FUTURE_TASK_ROLE)


@dataclass(frozen=True)
class ColumnRoles:
    machine_id: str
    energy: str
    beam: str
    input_cols: List[str]
    controllable_cols: List[str]
    monitorable_cols: List[str]
    output_cols: List[str]
    feedback_cols: List[str] = field(default_factory=list)

    @property
    def feature_cols(self) -> List[str]:
        return list(self.controllable_cols) + list(self.monitorable_cols)

    def validate(self, available_columns: List[str]) -> None:
        available = set(available_columns)
        named = {
            self.machine_id,
            self.energy,
            self.beam,
            *self.input_cols,
            *self.controllable_cols,
            *self.monitorable_cols,
            *self.output_cols,
            *self.feedback_cols,
        }
        missing = sorted(named - available)
        if missing:
            raise ValueError(f"Missing configured columns: {missing}")
        if self.machine_id in self.feature_cols:
            raise ValueError("Machine ID cannot be a predictor feature.")
        if self.beam in self.feature_cols:
            raise ValueError("Beam Current is a target/output and cannot be a predictor feature.")
        forbidden = set(self.feedback_cols).intersection(self.feature_cols)
        if forbidden:
            raise ValueError(f"Feedback readings cannot be predictor features: {sorted(forbidden)}")
        if set(self.controllable_cols).intersection(self.monitorable_cols):
            raise ValueError("Controllable and monitorable columns must be disjoint.")
        if set(self.feature_cols) != set(self.input_cols):
            raise ValueError("Input columns must be exactly controllables + monitorables.")
        if self.beam not in self.output_cols:
            raise ValueError("Beam Current must be one of the output columns.")

        feature_keys = {_column_key(name) for name in self.feature_cols}
        has_focus_voltage = any(
            key.startswith("focusvoltage") for key in feature_keys
        )
        has_focus_bias = any(key.startswith("focusbias") for key in feature_keys)
        if has_focus_voltage and has_focus_bias:
            raise ValueError(
                "Focus Voltage(kV) and Focus_Bias are mutually exclusive representations; "
                "only one may be a predictor/control feature."
            )


@dataclass(frozen=True)
class TemporalSplitConfig:
    global_fraction: float = 0.55
    adapter_fraction: float = 0.15
    environment_fraction: float = 0.15
    task_fraction: float = 0.15
    min_global: int = 30
    min_adapter: int = 10
    min_environment: int = 25
    min_task: int = 10

    @property
    def fractions(self) -> Dict[str, float]:
        return {
            ROLE_GLOBAL: self.global_fraction,
            ROLE_ADAPTER: self.adapter_fraction,
            ROLE_ENVIRONMENT: self.environment_fraction,
            ROLE_TASK: self.task_fraction,
        }

    @property
    def minimums(self) -> Dict[str, int]:
        return {
            ROLE_GLOBAL: self.min_global,
            ROLE_ADAPTER: self.min_adapter,
            ROLE_ENVIRONMENT: self.min_environment,
            ROLE_TASK: self.min_task,
        }

    def validate(self) -> None:
        vals = list(self.fractions.values())
        if any(v <= 0 for v in vals):
            raise ValueError("All temporal fractions must be positive.")
        if abs(sum(vals) - 1.0) > 1e-8:
            raise ValueError("G/A/E/T fractions must sum to 1.0.")
        if any(v < 1 for v in self.minimums.values()):
            raise ValueError("Every role minimum must be at least one row.")


@dataclass(frozen=True)
class GlobalTaskSplitConfig:
    global_training_fraction: float = 0.85
    future_task_fraction: float = 0.15
    min_global_training: int = 60
    min_future_tasks: int = 10

    def validate(self) -> None:
        if self.global_training_fraction <= 0 or self.future_task_fraction <= 0:
            raise ValueError("Both chronological fractions must be positive.")
        if abs(self.global_training_fraction + self.future_task_fraction - 1.0) > 1e-8:
            raise ValueError("Global Training and Future Tasks fractions must sum to 1.0.")
        if self.min_global_training < 2 or self.min_future_tasks < 1:
            raise ValueError("Minimum row requirements are invalid.")


@dataclass(frozen=True)
class ControlBound:
    minimum: float
    maximum: float
    resolution: float
    # V3 compatibility field: maximum number of resolution steps per probe.
    # V4 uses max_delta_range below instead; zero means unrestricted when the
    # V4 range is not supplied.
    max_delta_per_probe: int = 0
    # V4 physical single-probe movement range. This is deliberately separate
    # from resolution: it is a range in the parameter's own units, not a step
    # count. None/0 means unrestricted movement inside the safe bounds.
    max_delta_range: float | None = None

    @property
    def maximum_delta(self) -> float:
        span = float(self.maximum - self.minimum)
        if self.max_delta_range is not None and float(self.max_delta_range) > 0:
            return min(span, float(self.max_delta_range))
        if self.max_delta_per_probe == 0:
            return max(0.0, span)
        return min(span, float(self.max_delta_per_probe) * float(self.resolution))

    @property
    def maximum_delta_steps(self) -> int:
        if self.resolution <= 0:
            return 0
        return max(1, int(np.floor(self.maximum_delta / self.resolution))) if self.maximum_delta > 0 else 0

    @property
    def unrestricted(self) -> bool:
        return (
            self.max_delta_per_probe == 0
            and (self.max_delta_range is None or float(self.max_delta_range) <= 0)
        )

    def validate(self) -> None:
        if self.maximum < self.minimum:
            raise ValueError("Control maximum must be >= minimum.")
        if self.resolution <= 0:
            raise ValueError("Control resolution must be > 0.")
        if isinstance(self.max_delta_per_probe, bool) or not isinstance(
            self.max_delta_per_probe, Integral
        ):
            raise ValueError("max_delta_per_probe must be an integer number of resolution steps.")
        if self.max_delta_per_probe < 0:
            raise ValueError("max_delta_per_probe must be >= 0; use 0 for unrestricted movement.")
        if self.max_delta_range is not None:
            if not np.isfinite(float(self.max_delta_range)) or float(self.max_delta_range) < 0:
                raise ValueError("max_delta_range must be finite and >= 0; use 0 for unrestricted movement.")


@dataclass(frozen=True)
class TaskGenerationConfig:
    n_tasks: int = 100
    all_future_tasks: bool = False
    seed: int = 42
    difficulty_threshold: float = 0.1
    beam_max: float = 1000.0
    degradation_ratio: float = 0.90
    max_reference_error_fraction: float = 0.15
    # Compatibility name retained for the exported manifest.  This is the
    # number of legacy random degradation attempts, not an optimizer search
    # budget.  The original code used 18 attempts followed by a one-control
    # half-value fallback.
    initial_search_samples: int = 18
    generation_batch_tasks: int = 64

    def validate(self) -> None:
        if not self.all_future_tasks and self.n_tasks < 1:
            raise ValueError("n_tasks must be >= 1 when all-Future mode is disabled")
        if self.initial_search_samples < 1:
            raise ValueError("initial_search_samples must be >= 1")
        if self.generation_batch_tasks < 1:
            raise ValueError("generation_batch_tasks must be >= 1")
        if not 0 < self.degradation_ratio < 1:
            raise ValueError("degradation_ratio must be between 0 and 1")
        if self.beam_max <= 0:
            raise ValueError("beam_max must be positive")
        if not 0 <= self.max_reference_error_fraction < 1:
            raise ValueError("max_reference_error_fraction must be in [0, 1)")


@dataclass(frozen=True)
class ReplayConfig:
    max_rounds: int = 20
    tolerance_fraction: float = 0.05
    seed: int = 42
    # BO initialization consumes part of max_rounds. Each initialization round
    # contains exactly one probe for every controllable parameter.
    bo_initialization_rounds: int = 2
    random_search_samples: int = 2000
    pso_particles: int = 25
    pso_iterations: int = 60
    bo_candidates: int = 3000
    bo_kappa: float = 2.0
    # V3.2+ updates the online adapter once after a complete tuning round.
    # Per-probe XGBoost refits made V3.1 computationally intractable.
    update_adapter_after_each_probe: bool = False

    def validate(self) -> None:
        if self.max_rounds < 1:
            raise ValueError("max_rounds must be >= 1")
        if self.bo_initialization_rounds < 1:
            raise ValueError("bo_initialization_rounds must be >= 1")
        if self.bo_initialization_rounds > self.max_rounds:
            raise ValueError("BO initialization rounds cannot exceed maximum total rounds")
        if not 0 < self.tolerance_fraction < 1:
            raise ValueError("tolerance_fraction must be between 0 and 1")

    def bo_initialization_probes(self, n_controllables: int) -> int:
        return int(self.bo_initialization_rounds) * int(n_controllables)

    @property
    def bo_online_rounds_budget(self) -> int:
        return int(self.max_rounds) - int(self.bo_initialization_rounds)
