from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, Iterable

import numpy as np

from .config import ControlBound


Objective = Callable[[np.ndarray], float]
BatchObjective = Callable[[np.ndarray], np.ndarray]


def quantize_value(bound: ControlBound, value: float) -> float:
    bound.validate()
    value = float(np.clip(value, bound.minimum, bound.maximum))
    if bound.maximum == bound.minimum:
        return float(bound.minimum)
    steps = round((value - bound.minimum) / bound.resolution)
    quantized = bound.minimum + steps * bound.resolution
    return float(np.clip(quantized, bound.minimum, bound.maximum))


# Backward-compatible private name used by older downstream scripts.
_quantize = quantize_value


def apply_bounded_value(
    bound: ControlBound,
    previous: float,
    desired: float,
) -> tuple[float, bool]:
    """Project one desired value under bounds, resolution and movement range."""
    desired_q = quantize_value(bound, desired)
    previous_q = quantize_value(bound, previous)
    maximum_delta = bound.maximum_delta
    executable_delta = float(np.clip(desired_q - previous_q, -maximum_delta, maximum_delta))
    applied = quantize_value(bound, previous_q + executable_delta)
    return applied, not np.isclose(applied, desired_q, rtol=0.0, atol=1e-12)


@dataclass(frozen=True)
class ControlTransition:
    parameter_index: int
    controls: np.ndarray
    previous_value: float
    proposed_value: float
    applied_value: float
    requested_delta: float
    applied_delta: float
    maximum_delta: float
    movement_clipped: bool


@dataclass
class SearchSpace:
    control_names: list[str]
    bounds: Dict[str, ControlBound]
    tuning_order: list[int]

    def __post_init__(self):
        if sorted(self.tuning_order) != list(range(len(self.control_names))):
            raise ValueError("tuning_order must be a permutation of control indices")
        for name in self.control_names:
            self.bounds[name].validate()

    @property
    def dimension(self) -> int:
        return len(self.control_names)

    def decode(self, normalized: np.ndarray) -> np.ndarray:
        normalized = np.clip(np.asarray(normalized, dtype=float).reshape(-1), 0.0, 1.0)
        if len(normalized) != self.dimension:
            raise ValueError("Normalized vector has the wrong dimension")
        values = []
        for x, name in zip(normalized, self.control_names):
            bound = self.bounds[name]
            raw = bound.minimum + x * (bound.maximum - bound.minimum)
            values.append(_quantize(bound, raw))
        return np.asarray(values, dtype=float)

    def decode_many(self, normalized: np.ndarray) -> np.ndarray:
        values = np.clip(np.asarray(normalized, dtype=float), 0.0, 1.0)
        if values.ndim != 2 or values.shape[1] != self.dimension:
            raise ValueError("Normalized matrix has the wrong shape")
        decoded = np.empty_like(values, dtype=float)
        for index, name in enumerate(self.control_names):
            bound = self.bounds[name]
            raw = bound.minimum + values[:, index] * (bound.maximum - bound.minimum)
            steps = np.rint((raw - bound.minimum) / bound.resolution)
            decoded[:, index] = np.clip(
                bound.minimum + steps * bound.resolution,
                bound.minimum,
                bound.maximum,
            )
        return decoded

    def encode(self, values: np.ndarray) -> np.ndarray:
        values = np.asarray(values, dtype=float).reshape(-1)
        result = []
        for value, name in zip(values, self.control_names):
            bound = self.bounds[name]
            span = bound.maximum - bound.minimum
            result.append(0.5 if span <= 0 else np.clip((value - bound.minimum) / span, 0.0, 1.0))
        return np.asarray(result, dtype=float)

    def stepwise(self, current: np.ndarray, target: np.ndarray) -> list[tuple[int, np.ndarray]]:
        """Return the legacy unrestricted one-parameter-at-a-time sequence."""
        current = np.asarray(current, dtype=float).copy()
        target = np.asarray(target, dtype=float)
        sequence: list[tuple[int, np.ndarray]] = []
        for index in self.tuning_order:
            if np.isclose(current[index], target[index], rtol=0.0, atol=1e-12):
                continue
            current[index] = target[index]
            sequence.append((index, current.copy()))
        return sequence

    def stepwise_limited(
        self,
        current: np.ndarray,
        target: np.ndarray,
    ) -> list[ControlTransition]:
        """Apply one ordered visit per parameter with per-probe movement limits.

        The optimizer may propose any in-bounds target. The executable value is
        clipped to the configured physical single-probe range from the current
        value, quantized, and then clipped to the declared safe range. A
        configured range of zero means unrestricted movement within that safe
        range. The legacy integer step-count field remains supported by
        ``ControlBound`` for V3 manifests.
        """
        current = np.asarray(current, dtype=float).copy()
        target = np.asarray(target, dtype=float).reshape(-1)
        if len(target) != self.dimension:
            raise ValueError("Target vector has the wrong dimension")
        sequence: list[ControlTransition] = []
        for index in self.tuning_order:
            name = self.control_names[index]
            bound = self.bounds[name]
            previous = float(current[index])
            proposed = quantize_value(bound, float(target[index]))
            requested_delta = proposed - previous
            if np.isclose(requested_delta, 0.0, rtol=0.0, atol=1e-12):
                continue
            maximum_delta = bound.maximum_delta
            executable_delta = float(np.clip(requested_delta, -maximum_delta, maximum_delta))
            applied = quantize_value(bound, previous + executable_delta)
            if np.isclose(applied, previous, rtol=0.0, atol=1e-12):
                continue
            current[index] = applied
            sequence.append(
                ControlTransition(
                    parameter_index=index,
                    controls=current.copy(),
                    previous_value=previous,
                    proposed_value=proposed,
                    applied_value=applied,
                    requested_delta=requested_delta,
                    applied_delta=applied - previous,
                    maximum_delta=maximum_delta,
                    movement_clipped=not np.isclose(applied, proposed, rtol=0.0, atol=1e-12),
                )
            )
        return sequence

    def local_probe(self, current: np.ndarray, rng: np.random.Generator) -> tuple[int, np.ndarray]:
        index = int(rng.integers(0, self.dimension))
        return self.local_probe_at(current, index, rng)

    def local_probe_at(
        self,
        current: np.ndarray,
        index: int,
        rng: np.random.Generator,
    ) -> tuple[int, np.ndarray]:
        """Perturb one declared parameter while leaving every other value fixed."""
        current = np.asarray(current, dtype=float).copy()
        index = int(index)
        if not 0 <= index < self.dimension:
            raise IndexError("control index is outside the search space")
        name = self.control_names[index]
        bound = self.bounds[name]
        maximum_offset = min(3, bound.maximum_delta_steps)
        offsets = np.asarray(
            [*range(-maximum_offset, 0), *range(1, maximum_offset + 1)],
            dtype=int,
        )
        for offset in rng.permutation(offsets):
            candidate = quantize_value(bound, current[index] + int(offset) * bound.resolution)
            if not np.isclose(candidate, current[index], rtol=0.0, atol=1e-12):
                current[index] = candidate
                break
        return index, current


def random_search(objective: Objective, dimension: int, samples: int, rng: np.random.Generator) -> np.ndarray:
    candidates = rng.random((samples, dimension))
    scores = np.asarray([objective(x) for x in candidates], dtype=float)
    return candidates[int(np.argmax(scores))]


def random_search_batch(
    objective: BatchObjective,
    dimension: int,
    samples: int,
    rng: np.random.Generator,
) -> np.ndarray:
    candidates = rng.random((samples, dimension))
    scores = np.asarray(objective(candidates), dtype=float).reshape(-1)
    if len(scores) != len(candidates):
        raise ValueError("Batch objective returned the wrong number of scores")
    return candidates[int(np.argmax(scores))]


def pso(
    objective: Objective,
    dimension: int,
    particles: int,
    iterations: int,
    rng: np.random.Generator,
) -> np.ndarray:
    position = rng.random((particles, dimension))
    velocity = np.zeros_like(position)
    personal = position.copy()
    personal_score = np.asarray([objective(x) for x in position], dtype=float)
    best_index = int(np.argmax(personal_score))
    global_best = personal[best_index].copy()
    global_score = float(personal_score[best_index])
    for _ in range(iterations):
        r1 = rng.random((particles, dimension))
        r2 = rng.random((particles, dimension))
        velocity = 0.7 * velocity + 1.5 * r1 * (personal - position) + 1.5 * r2 * (global_best - position)
        position = np.clip(position + velocity, 0.0, 1.0)
        score = np.asarray([objective(x) for x in position], dtype=float)
        improved = score > personal_score
        personal[improved] = position[improved]
        personal_score[improved] = score[improved]
        best_index = int(np.argmax(personal_score))
        if float(personal_score[best_index]) > global_score:
            global_score = float(personal_score[best_index])
            global_best = personal[best_index].copy()
    return global_best


def pso_batch(
    objective: BatchObjective,
    dimension: int,
    particles: int,
    iterations: int,
    rng: np.random.Generator,
) -> np.ndarray:
    """PSO with one model call per particle population rather than per particle."""
    position = rng.random((particles, dimension))
    velocity = np.zeros_like(position)
    personal = position.copy()
    personal_score = np.asarray(objective(position), dtype=float).reshape(-1)
    if len(personal_score) != particles:
        raise ValueError("Batch objective returned the wrong number of PSO scores")
    best_index = int(np.argmax(personal_score))
    global_best = personal[best_index].copy()
    global_score = float(personal_score[best_index])
    for _ in range(iterations):
        r1 = rng.random((particles, dimension))
        r2 = rng.random((particles, dimension))
        velocity = 0.7 * velocity + 1.5 * r1 * (personal - position) + 1.5 * r2 * (global_best - position)
        position = np.clip(position + velocity, 0.0, 1.0)
        score = np.asarray(objective(position), dtype=float).reshape(-1)
        if len(score) != particles:
            raise ValueError("Batch objective returned the wrong number of PSO scores")
        improved = score > personal_score
        personal[improved] = position[improved]
        personal_score[improved] = score[improved]
        best_index = int(np.argmax(personal_score))
        if float(personal_score[best_index]) > global_score:
            global_score = float(personal_score[best_index])
            global_best = personal[best_index].copy()
    return global_best


def cma_es(objective: Objective, dimension: int, iterations: int, seed: int) -> np.ndarray:
    try:
        import cma
    except ImportError as exc:
        raise RuntimeError("CMA-ES requires the optional 'cma' package.") from exc

    def minimize(x: Iterable[float]) -> float:
        return -float(objective(np.clip(np.asarray(x, dtype=float), 0.0, 1.0)))

    options = {
        "seed": int(seed),
        "popsize": 12,
        "maxiter": int(iterations),
        "verb_disp": 0,
        "bounds": [0.0, 1.0],
    }
    result = cma.CMAEvolutionStrategy(np.full(dimension, 0.5), 0.25, options).optimize(minimize)
    return np.clip(np.asarray(result.result.xbest, dtype=float), 0.0, 1.0)
