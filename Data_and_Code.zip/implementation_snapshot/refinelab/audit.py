from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from .config import (
    ColumnRoles,
    FUTURE_TASK_ROLE,
    GLOBAL_TRAINING_ROLE,
    ROLE_ORDER,
    ROLE_TASK,
)
from .data import ROLE_COL, SOURCE_ORDER_COL, TOOL_ORDER_COL
from .tasks import (
    ALL_FUTURE_MODE,
    LEGACY_HALF_FALLBACK_START,
    LEGACY_RANDOM_DEGRADATION_START,
    TaskManifest,
)


@dataclass
class AuditReport:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    checks: list[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not self.errors

    def as_text(self) -> str:
        lines = ["PASS" if self.passed else "FAIL"]
        lines.extend(f"[OK] {x}" for x in self.checks)
        lines.extend(f"[WARNING] {x}" for x in self.warnings)
        lines.extend(f"[ERROR] {x}" for x in self.errors)
        return "\n".join(lines)


def audit_protocol(
    annotated: pd.DataFrame,
    roles: ColumnRoles,
    manifest: TaskManifest | None = None,
) -> AuditReport:
    report = AuditReport()
    try:
        roles.validate(list(annotated.columns))
        report.checks.append("Column roles are disjoint; target and feedback are absent from predictor features.")
    except Exception as exc:
        report.errors.append(str(exc))

    required = {ROLE_COL, SOURCE_ORDER_COL, TOOL_ORDER_COL}
    missing = required - set(annotated.columns)
    if missing:
        report.errors.append(f"Missing protocol columns: {sorted(missing)}")
        return report

    eligible = annotated[annotated[ROLE_COL].isin(ROLE_ORDER)]
    if eligible.empty:
        report.errors.append("No eligible G/A/E/T rows.")
        return report

    for machine_id, group in eligible.groupby(roles.machine_id, sort=False, dropna=False):
        ranges = {}
        for role in ROLE_ORDER:
            values = group.loc[group[ROLE_COL] == role, TOOL_ORDER_COL]
            if values.empty:
                report.errors.append(f"Machine {machine_id} has no {role} rows.")
            else:
                ranges[role] = (int(values.min()), int(values.max()))
        if len(ranges) == len(ROLE_ORDER):
            for left, right in zip(ROLE_ORDER[:-1], ROLE_ORDER[1:]):
                if ranges[left][1] >= ranges[right][0]:
                    report.errors.append(
                        f"Machine {machine_id} violates temporal order: {left} overlaps/follows {right}."
                    )
    if not report.errors:
        report.checks.append("Every eligible machine satisfies within-ID G < A < E < T ordering.")

    role_sets = {
        role: set(eligible.loc[eligible[ROLE_COL] == role, SOURCE_ORDER_COL].astype(int))
        for role in ROLE_ORDER
    }
    for i, left in enumerate(ROLE_ORDER):
        for right in ROLE_ORDER[i + 1 :]:
            overlap = role_sets[left].intersection(role_sets[right])
            if overlap:
                report.errors.append(f"{left}/{right} row overlap: {len(overlap)} rows")
    if not any("row overlap" in err for err in report.errors):
        report.checks.append("G/A/E/T source-row identities are mutually exclusive.")

    if manifest is not None:
        seen = set()
        source_to_role = dict(zip(annotated[SOURCE_ORDER_COL].astype(int), annotated[ROLE_COL]))
        source_to_machine = dict(
            zip(annotated[SOURCE_ORDER_COL].astype(int), annotated[roles.machine_id].astype(str))
        )
        for task in manifest.tasks:
            if task.task_id in seen:
                report.errors.append(f"Duplicate task_id: {task.task_id}")
            seen.add(task.task_id)
            if source_to_role.get(task.source_order) != ROLE_TASK:
                report.errors.append(f"Task {task.task_id} is not anchored in T.")
            if source_to_machine.get(task.source_order) != task.machine_id:
                report.errors.append(f"Task {task.task_id} machine identity does not match its source row.")
        if len(seen) == len(manifest.tasks) and not any("anchored" in x for x in report.errors):
            report.checks.append("Task manifest is unique and every task is anchored only in T.")
        if len(manifest.tasks) < manifest.requested_tasks:
            report.warnings.append(
                f"Generated {len(manifest.tasks)} of {manifest.requested_tasks} requested tasks after fidelity/degradation qualification."
            )

    return report


def audit_global_task_protocol(
    annotated: pd.DataFrame,
    roles: ColumnRoles,
    manifest: TaskManifest | None = None,
) -> AuditReport:
    report = AuditReport()
    try:
        roles.validate(list(annotated.columns))
        report.checks.append(
            "Column roles are disjoint; Beam Current and feedback readings are excluded from predictor features."
        )
    except Exception as exc:
        report.errors.append(str(exc))

    required = {ROLE_COL, SOURCE_ORDER_COL, TOOL_ORDER_COL}
    missing = required - set(annotated.columns)
    if missing:
        report.errors.append(f"Missing protocol columns: {sorted(missing)}")
        return report

    eligible = annotated[
        annotated[ROLE_COL].isin((GLOBAL_TRAINING_ROLE, FUTURE_TASK_ROLE))
    ]
    if eligible.empty:
        report.errors.append("No eligible Global Training / Future Task rows.")
        return report

    for machine_id, group in eligible.groupby(roles.machine_id, sort=False, dropna=False):
        global_order = group.loc[group[ROLE_COL] == GLOBAL_TRAINING_ROLE, TOOL_ORDER_COL]
        future_order = group.loc[group[ROLE_COL] == FUTURE_TASK_ROLE, TOOL_ORDER_COL]
        if global_order.empty or future_order.empty:
            report.errors.append(f"Machine {machine_id} is missing one chronological role.")
            continue
        if int(global_order.max()) >= int(future_order.min()):
            report.errors.append(
                f"Machine {machine_id} violates chronology: Global Training overlaps/follows Future Tasks."
            )
    if not report.errors:
        report.checks.append(
            "Every eligible machine has Global predictor training rows strictly before Future replay task rows."
        )

    global_rows = set(
        eligible.loc[eligible[ROLE_COL] == GLOBAL_TRAINING_ROLE, SOURCE_ORDER_COL].astype(int)
    )
    task_rows = set(
        eligible.loc[eligible[ROLE_COL] == FUTURE_TASK_ROLE, SOURCE_ORDER_COL].astype(int)
    )
    if global_rows.intersection(task_rows):
        report.errors.append("Global Training and Future Tasks contain overlapping source rows.")
    else:
        report.checks.append("Global Training and Future Tasks are source-row disjoint.")

    if manifest is not None:
        source_to_role = dict(zip(annotated[SOURCE_ORDER_COL].astype(int), annotated[ROLE_COL]))
        source_to_machine = dict(
            zip(annotated[SOURCE_ORDER_COL].astype(int), annotated[roles.machine_id].astype(str))
        )
        source_to_target = dict(
            zip(
                annotated[SOURCE_ORDER_COL].astype(int),
                pd.to_numeric(annotated[roles.beam], errors="coerce"),
            )
        )
        ids = set()
        fallback_tasks = 0
        for task in manifest.tasks:
            if task.task_id in ids:
                report.errors.append(f"Duplicate task_id: {task.task_id}")
            ids.add(task.task_id)
            if source_to_role.get(task.source_order) != FUTURE_TASK_ROLE:
                report.errors.append(f"Task {task.task_id} is not anchored in Future Replay Tasks.")
            if source_to_machine.get(task.source_order) != task.machine_id:
                report.errors.append(f"Task {task.task_id} machine identity mismatch.")
            expected_target = source_to_target.get(task.source_order)
            if pd.isna(expected_target) or abs(float(expected_target) - task.target_beam) > 1e-9:
                report.errors.append(f"Task {task.task_id} target does not match its observed Future-row Beam Current.")
            if task.initial_search_samples < 1:
                report.errors.append(f"Task {task.task_id} has an invalid initial-search sample count.")
            if task.initial_state_selection == LEGACY_HALF_FALLBACK_START:
                # The old implementation always kept this fallback after the
                # random attempts, even when its Beam value did not cross the
                # requested threshold.  It is therefore a valid legacy start,
                # but it must remain visible in the audit rather than being
                # mislabeled as threshold-qualified.
                fallback_tasks += 1
                continue
            threshold_reference = task.target_beam
            if task.initial_state_selection == LEGACY_RANDOM_DEGRADATION_START:
                threshold_reference = task.reference_environment_beam
            if not (
                pd.notna(threshold_reference)
                and task.initial_beam
                < task.degradation_threshold * float(threshold_reference)
            ):
                report.errors.append(f"Task {task.task_id} does not satisfy its declared degradation threshold.")
        if len(ids) == len(manifest.tasks) and not any("anchored" in x for x in report.errors):
            report.checks.append("Frozen task manifest is unique and uses only Future Replay Task rows.")
        if not any("target does not match" in x for x in report.errors):
            report.checks.append("Every task target equals its observed successful Future-row Beam Current.")
        if not any("degradation threshold" in x for x in report.errors):
            report.checks.append(
                "Every non-fallback generated initial state satisfies its declared degradation threshold."
            )
        if fallback_tasks:
            report.warnings.append(
                f"{fallback_tasks} task(s) use the legacy one-control half-value fallback after all random degradation attempts missed; "
                "those starts are retained even if they are above the threshold."
            )
        all_mode = bool(manifest.tasks) and all(
            task.generation_mode == ALL_FUTURE_MODE for task in manifest.tasks
        )
        if all_mode and not manifest.cancelled:
            accounted = (
                len(manifest.tasks)
                + manifest.excluded_invalid_rows
                + manifest.excluded_reference_fidelity
                + manifest.excluded_no_degraded_start
            )
            if accounted != manifest.candidate_rows:
                report.errors.append(
                    f"All-Future accounting mismatch: {accounted} accounted vs {manifest.candidate_rows} eligible rows."
                )
            else:
                report.checks.append("All eligible Future rows are accounted for exactly once.")
    return report
