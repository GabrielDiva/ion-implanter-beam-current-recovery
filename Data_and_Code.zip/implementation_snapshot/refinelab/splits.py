from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

import numpy as np
import pandas as pd

from .config import (
    FUTURE_TASK_ROLE,
    GLOBAL_TRAINING_ROLE,
    GT_ROLE_ORDER,
    GlobalTaskSplitConfig,
    ROLE_ORDER,
    TemporalSplitConfig,
)
from .data import ROLE_COL, SOURCE_ORDER_COL, TOOL_ORDER_COL, add_within_tool_order


@dataclass
class ToolSplitReport:
    machine_id: str
    total_rows: int
    eligible: bool
    counts: Dict[str, int] = field(default_factory=dict)
    reason: str = ""


@dataclass
class TemporalSplitResult:
    annotated: pd.DataFrame
    reports: List[ToolSplitReport]

    @property
    def eligible_machine_ids(self) -> List[str]:
        return [r.machine_id for r in self.reports if r.eligible]

    def counts_frame(self) -> pd.DataFrame:
        rows = []
        for report in self.reports:
            row = {
                "machine_id": report.machine_id,
                "total_rows": report.total_rows,
                "eligible": report.eligible,
                "reason": report.reason,
            }
            row.update({f"n_{role}": report.counts.get(role, 0) for role in ROLE_ORDER})
            rows.append(row)
        return pd.DataFrame(rows)


def _allocate_counts(n: int, cfg: TemporalSplitConfig) -> Dict[str, int]:
    fractions = cfg.fractions
    raw = np.asarray([fractions[r] * n for r in ROLE_ORDER], dtype=float)
    counts = np.floor(raw).astype(int)
    remaining = int(n - counts.sum())
    if remaining > 0:
        order = np.argsort(-(raw - counts), kind="stable")
        for idx in order[:remaining]:
            counts[idx] += 1
    return {role: int(counts[i]) for i, role in enumerate(ROLE_ORDER)}


def temporal_role_split(
    frame: pd.DataFrame,
    machine_id_col: str,
    cfg: TemporalSplitConfig,
) -> TemporalSplitResult:
    cfg.validate()
    ordered = add_within_tool_order(frame, machine_id_col)
    ordered[ROLE_COL] = "EXCLUDED"
    reports: List[ToolSplitReport] = []

    for machine_id, group in ordered.groupby(machine_id_col, sort=False, dropna=False):
        group = group.sort_values(TOOL_ORDER_COL, kind="stable")
        n = len(group)
        counts = _allocate_counts(n, cfg)
        missing = {
            role: cfg.minimums[role] - counts[role]
            for role in ROLE_ORDER
            if counts[role] < cfg.minimums[role]
        }
        if missing:
            reports.append(
                ToolSplitReport(
                    machine_id=str(machine_id),
                    total_rows=n,
                    eligible=False,
                    counts=counts,
                    reason=f"role minimum not met: {missing}",
                )
            )
            continue

        start = 0
        for role in ROLE_ORDER:
            stop = start + counts[role]
            idx = group.index[start:stop]
            ordered.loc[idx, ROLE_COL] = role
            start = stop

        reports.append(
            ToolSplitReport(
                machine_id=str(machine_id),
                total_rows=n,
                eligible=True,
                counts=counts,
            )
        )

    ordered = ordered.sort_values(SOURCE_ORDER_COL, kind="stable").reset_index(drop=True)
    return TemporalSplitResult(annotated=ordered, reports=reports)


def grouped_chronological_validation(
    frame: pd.DataFrame,
    machine_id_col: str,
    validation_fraction: float = 0.15,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if not 0 < validation_fraction < 0.5:
        raise ValueError("validation_fraction must be between 0 and 0.5")
    train_parts = []
    valid_parts = []
    for _, group in frame.groupby(machine_id_col, sort=False, dropna=False):
        group = group.sort_values(TOOL_ORDER_COL, kind="stable")
        n_valid = max(1, int(round(len(group) * validation_fraction)))
        if len(group) - n_valid < 2:
            continue
        train_parts.append(group.iloc[:-n_valid])
        valid_parts.append(group.iloc[-n_valid:])
    if not train_parts or not valid_parts:
        raise ValueError("Insufficient rows for grouped chronological validation.")
    return pd.concat(train_parts, ignore_index=True), pd.concat(valid_parts, ignore_index=True)


@dataclass
class GlobalTaskToolReport:
    machine_id: str
    total_rows: int
    eligible: bool
    global_training_rows: int
    future_task_rows: int
    reason: str = ""


@dataclass
class GlobalTaskSplitResult:
    annotated: pd.DataFrame
    reports: List[GlobalTaskToolReport]

    @property
    def eligible_machine_ids(self) -> List[str]:
        return [x.machine_id for x in self.reports if x.eligible]

    def counts_frame(self) -> pd.DataFrame:
        return pd.DataFrame([x.__dict__ for x in self.reports])


def global_task_temporal_split(
    frame: pd.DataFrame,
    machine_id_col: str,
    cfg: GlobalTaskSplitConfig,
) -> GlobalTaskSplitResult:
    """Split each machine independently; orders across machines are never compared."""
    cfg.validate()
    ordered = add_within_tool_order(frame, machine_id_col)
    ordered[ROLE_COL] = "Excluded: insufficient rows"
    reports: List[GlobalTaskToolReport] = []

    for machine_id, group in ordered.groupby(machine_id_col, sort=False, dropna=False):
        group = group.sort_values(TOOL_ORDER_COL, kind="stable")
        n_total = len(group)
        n_future = max(1, int(round(n_total * cfg.future_task_fraction)))
        n_global = n_total - n_future
        eligible = n_global >= cfg.min_global_training and n_future >= cfg.min_future_tasks
        reason = "" if eligible else (
            f"requires >= {cfg.min_global_training} Global Training rows and "
            f">= {cfg.min_future_tasks} Future Task rows"
        )
        if eligible:
            ordered.loc[group.index[:n_global], ROLE_COL] = GLOBAL_TRAINING_ROLE
            ordered.loc[group.index[n_global:], ROLE_COL] = FUTURE_TASK_ROLE
        reports.append(
            GlobalTaskToolReport(
                machine_id=str(machine_id),
                total_rows=n_total,
                eligible=eligible,
                global_training_rows=n_global if eligible else 0,
                future_task_rows=n_future if eligible else 0,
                reason=reason,
            )
        )

    ordered = ordered.sort_values(SOURCE_ORDER_COL, kind="stable").reset_index(drop=True)
    return GlobalTaskSplitResult(annotated=ordered, reports=reports)
