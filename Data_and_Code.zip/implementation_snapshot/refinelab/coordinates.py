"""Coordinate-space configuration for RefineLab V4.0.

V4.0 keeps one input table but permits a solver view and an environment/SIM
view of the same rows.  The solver may search in raw engineering coordinates;
the resulting candidate is then converted to the frozen-SIM coordinates by a
manifest-configured, safe mathematical expression.

The module intentionally does not contain any study-specific electric-field
formula.  Expressions are supplied by the user through the GUI and saved in
the run manifest/configuration.
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Mapping

import numpy as np
import pandas as pd

from .config import ColumnRoles, ControlBound
from .optimizers import apply_bounded_value, quantize_value


_TOKEN_RE = re.compile(r"\{([^{}]+)\}")
_ALLOWED_BINARY = (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod)
_ALLOWED_UNARY = (ast.UAdd, ast.USub)


def _clip(value: float, lower: float, upper: float) -> float:
    return float(np.clip(float(value), float(lower), float(upper)))


def _minimum(*values: float) -> float:
    return float(min(float(x) for x in values))


def _maximum(*values: float) -> float:
    return float(max(float(x) for x in values))


_SAFE_FUNCTIONS = {
    "abs": abs,
    "min": _minimum,
    "max": _maximum,
    "clip": _clip,
    "sqrt": lambda x: float(np.sqrt(float(x))),
}


class SafeExpression:
    """A deliberately small scalar mathematical expression evaluator.

    Column names containing spaces or punctuation are written as
    ``{Column name}``.  Plain Python-like identifiers are also accepted for
    convenient column names such as ``Delta_E``.  No attribute access,
    subscripting, comprehensions, imports, or arbitrary function calls are
    permitted.
    """

    def __init__(self, source: str):
        self.source = str(source).strip()
        if not self.source:
            raise ValueError("Expression cannot be empty.")
        names: dict[str, str] = {}

        def replace(match: re.Match[str]) -> str:
            original = match.group(1).strip()
            if not original:
                raise ValueError("Empty column token in expression.")
            alias = f"__column_{len(names)}"
            names[alias] = original
            return alias

        normalized = _TOKEN_RE.sub(replace, self.source)
        tree = ast.parse(normalized, mode="eval")
        self._validate(tree)
        self._tree = tree
        self._token_names = names

    @classmethod
    def _validate(cls, node: ast.AST) -> None:
        for item in ast.walk(node):
            if isinstance(item, (ast.Expression, ast.Load)):
                continue
            if isinstance(item, ast.Constant):
                if not isinstance(item.value, (int, float)) or isinstance(item.value, bool):
                    raise ValueError("Only numeric constants are allowed in coordinate formulas.")
                continue
            if isinstance(item, ast.Name):
                continue
            if isinstance(item, ast.BinOp) and isinstance(item.op, _ALLOWED_BINARY):
                continue
            if isinstance(item, ast.UnaryOp) and isinstance(item.op, _ALLOWED_UNARY):
                continue
            if isinstance(item, ast.Call):
                if not isinstance(item.func, ast.Name) or item.func.id not in _SAFE_FUNCTIONS:
                    raise ValueError("Formula uses a function that is not allowed.")
                continue
            if isinstance(item, (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod, ast.UAdd, ast.USub)):
                continue
            raise ValueError(f"Unsupported syntax in coordinate formula: {type(item).__name__}")

    def evaluate(self, values: Mapping[str, Any]) -> float:
        locals_: dict[str, float] = {}
        for alias, original in self._token_names.items():
            if original not in values:
                raise KeyError(f"Formula column is unavailable: {original}")
            locals_[alias] = float(values[original])
        for name in self._names_without_tokens():
            if name in _SAFE_FUNCTIONS:
                continue
            if name not in values:
                raise KeyError(f"Formula variable is unavailable: {name}")
            locals_[name] = float(values[name])
        try:
            result = eval(compile(self._tree, "<coordinate-formula>", "eval"), {"__builtins__": {}}, {**_SAFE_FUNCTIONS, **locals_})
        except ZeroDivisionError as exc:
            raise ValueError("Coordinate formula divided by zero.") from exc
        result = float(result)
        if not np.isfinite(result):
            raise ValueError("Coordinate formula returned a non-finite value.")
        return result

    def _names_without_tokens(self) -> set[str]:
        return {
            node.id
            for node in ast.walk(self._tree)
            if isinstance(node, ast.Name) and node.id not in self._token_names
        }


@dataclass(frozen=True)
class TransformRule:
    """Map one canonical solver feature to one processed SIM source column."""

    canonical: str
    solver_column: str
    sim_column: str
    expression: str = ""
    epsilon: float = 1e-12
    denominator_columns: tuple[str, ...] = ()
    denominator_expression: str = ""
    invalid_policy: str = "mark_invalid"

    def validate(self, available_columns: Iterable[str]) -> None:
        available = set(map(str, available_columns))
        if self.canonical not in available:
            raise ValueError(f"Canonical coordinate is not a configured input column: {self.canonical}")
        if self.solver_column not in available:
            raise ValueError(f"Solver source column is missing: {self.solver_column}")
        if self.sim_column not in available:
            raise ValueError(f"SIM source column is missing: {self.sim_column}")
        if self.epsilon < 0 or not np.isfinite(self.epsilon):
            raise ValueError("Formula epsilon must be finite and >= 0.")
        missing_denominators = sorted(set(self.denominator_columns) - available)
        if missing_denominators:
            raise ValueError(f"Formula denominator columns are missing: {missing_denominators}")
        if self.denominator_expression.strip():
            SafeExpression(self.denominator_expression)
        if self.invalid_policy not in {"mark_invalid", "raise"}:
            raise ValueError("invalid_policy must be mark_invalid or raise.")
        if self.expression.strip():
            SafeExpression(self.expression)

    @property
    def is_identity(self) -> bool:
        return not self.expression.strip() and self.solver_column == self.sim_column


@dataclass
class CoordinateBridge:
    """One-file solver/SIM coordinate views and candidate conversion."""

    mode: str = "standard"
    rules: Dict[str, TransformRule] = field(default_factory=dict)
    _compiled: dict[str, SafeExpression] = field(default_factory=dict, init=False, repr=False)

    def to_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode,
            "rules": {
                canonical: {
                    "canonical": rule.canonical,
                    "solver_column": rule.solver_column,
                    "sim_column": rule.sim_column,
                    "expression": rule.expression,
                    "epsilon": float(rule.epsilon),
                    "denominator_columns": list(rule.denominator_columns),
                    "denominator_expression": rule.denominator_expression,
                    "invalid_policy": rule.invalid_policy,
                }
                for canonical, rule in self.rules.items()
            },
        }

    def validate(self, roles: ColumnRoles, available_columns: Iterable[str]) -> None:
        if self.mode not in {"standard", "ablation"}:
            raise ValueError("Coordinate mode must be standard or ablation.")
        allowed = set(roles.feature_cols)
        for canonical, rule in self.rules.items():
            if canonical not in allowed:
                raise ValueError(
                    f"Coordinate mapping {canonical!r} is not in the configured predictor inputs."
                )
            rule.validate(available_columns)
        if self.mode == "ablation" and not self.rules:
            raise ValueError("Ablation mode requires at least one coordinate mapping.")

    def build_views(
        self,
        frame: pd.DataFrame,
        roles: ColumnRoles,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Return solver and SIM views with the same canonical role columns."""
        solver = frame.copy()
        sim = frame.copy()
        for canonical in roles.feature_cols:
            rule = self.rules.get(canonical)
            if rule is None:
                if canonical not in frame.columns:
                    raise ValueError(f"Configured canonical feature is missing: {canonical}")
                solver[canonical] = frame[canonical]
                sim[canonical] = frame[canonical]
            else:
                solver[canonical] = frame[rule.solver_column]
                sim[canonical] = frame[rule.sim_column]
        return solver, sim

    def _value_map(
        self,
        controls: Mapping[str, float],
        context: Mapping[str, float],
    ) -> dict[str, float]:
        values = {str(k): float(v) for k, v in context.items()}
        values.update({str(k): float(v) for k, v in controls.items()})
        return values

    def _expression(self, rule: TransformRule) -> SafeExpression:
        compiled = self._compiled.get(rule.canonical)
        if compiled is None:
            compiled = SafeExpression(rule.expression)
            self._compiled[rule.canonical] = compiled
        return compiled

    def _denominator_expression(self, rule: TransformRule) -> SafeExpression:
        key = f"__denominator__{rule.canonical}"
        compiled = self._compiled.get(key)
        if compiled is None:
            compiled = SafeExpression(rule.denominator_expression)
            self._compiled[key] = compiled
        return compiled

    def _check_denominator(self, rule: TransformRule, values: Mapping[str, Any]) -> None:
        """Reject an actually small denominator, including composite denominators.

        ``denominator_columns`` is retained for backwards compatibility with
        early V4 configurations.  New configurations should use
        ``denominator_expression`` whenever the denominator is a combination
        of columns, e.g. ``({Ext. Voltage(kV)} - {Energy(keV)})``.
        """
        if rule.denominator_expression.strip():
            denominator = self._denominator_expression(rule).evaluate(values)
            if not np.isfinite(denominator) or abs(float(denominator)) <= rule.epsilon:
                raise ValueError("denominator expression is within epsilon")
            return
        for denominator in rule.denominator_columns:
            denominator_value = float(values[denominator])
            if abs(denominator_value) <= rule.epsilon:
                raise ValueError(f"denominator {denominator} is within epsilon")

    def convert_feature_maps(
        self,
        controls: Mapping[str, float],
        context: Mapping[str, float],
        control_names: Iterable[str],
        monitorable_names: Iterable[str],
        *,
        sim_bounds: Mapping[str, ControlBound] | None = None,
        previous_sim_controls: Mapping[str, float] | None = None,
        changed_parameter: str | None = None,
    ) -> tuple[dict[str, float], dict[str, float], dict[str, Any]]:
        """Convert solver maps to SIM maps and apply SIM engineering limits.

        ``previous_sim_controls`` and ``changed_parameter`` are supplied during
        replay.  In that case the SIM-side maximum movement range is applied
        after the solver candidate has been transformed.  During task
        construction, omit them so the complete candidate is projected only
        to the SIM bounds/resolution.
        """
        values = self._value_map(controls, context)
        for canonical, rule in self.rules.items():
            if rule.solver_column not in values and canonical in values:
                values[rule.solver_column] = values[canonical]
        converted = dict(values)
        invalid: list[str] = []
        for canonical, rule in self.rules.items():
            try:
                self._check_denominator(rule, values)
                if rule.expression.strip():
                    result = self._expression(rule).evaluate(values)
                else:
                    result = float(values[rule.solver_column])
                if not np.isfinite(result):
                    raise ValueError("non-finite transformed coordinate")
                converted[canonical] = result
            except (KeyError, ValueError, ZeroDivisionError):
                invalid.append(canonical)

        if invalid:
            if any(self.rules[name].invalid_policy == "raise" for name in invalid):
                raise ValueError(f"Invalid coordinate transformation for: {invalid}")
            return {}, {}, {"invalid": True, "invalid_columns": invalid, "sim_clipped": False}

        sim_controls = {name: float(converted[name]) for name in control_names}
        sim_context = {name: float(converted[name]) for name in monitorable_names}
        clipped = False
        sim_deltas: dict[str, float] = {}
        if sim_bounds is not None:
            for name in control_names:
                if name not in sim_bounds:
                    raise ValueError(f"SIM bounds are missing coordinate: {name}")
                bound = sim_bounds[name]
                desired = float(sim_controls[name])
                if previous_sim_controls is not None and name == changed_parameter:
                    previous = float(previous_sim_controls[name])
                    applied, was_clipped = apply_bounded_value(bound, previous, desired)
                    clipped = clipped or was_clipped
                    sim_controls[name] = applied
                    sim_deltas[name] = applied - previous
                else:
                    projected = quantize_value(bound, desired)
                    clipped = clipped or not np.isclose(projected, desired, rtol=0.0, atol=1e-12)
                    sim_controls[name] = projected
                    if previous_sim_controls is not None:
                        sim_deltas[name] = projected - float(previous_sim_controls[name])

        return sim_controls, sim_context, {
            "invalid": False,
            "invalid_columns": [],
            "sim_clipped": bool(clipped),
            "sim_deltas": sim_deltas,
        }

    def validate_existing_columns(
        self,
        frame: pd.DataFrame,
        roles: ColumnRoles,
        *,
        max_rows: int = 5000,
    ) -> pd.DataFrame:
        """Check configured formulas against already materialized SIM columns."""
        rows: list[dict[str, Any]] = []
        sample = frame if len(frame) <= max_rows else frame.iloc[np.linspace(0, len(frame) - 1, max_rows).astype(int)]
        for canonical, rule in self.rules.items():
            if not rule.expression.strip():
                rows.append({
                    "canonical": canonical,
                    "solver_column": rule.solver_column,
                    "sim_column": rule.sim_column,
                    "n_checked": 0,
                    "n_invalid": 0,
                    "mean_abs_error": 0.0,
                    "max_abs_error": 0.0,
                    "status": "identity/no formula",
                })
                continue
            errors: list[float] = []
            invalid = 0
            expression = self._expression(rule)
            for _, row in sample.iterrows():
                values = {str(k): row[k] for k in frame.columns}
                try:
                    self._check_denominator(rule, values)
                    result = expression.evaluate(values)
                    actual = float(row[rule.sim_column])
                    if not np.isfinite(actual) or not np.isfinite(result):
                        invalid += 1
                    else:
                        errors.append(abs(result - actual))
                except (KeyError, ValueError, TypeError, ZeroDivisionError):
                    invalid += 1
            mean_error = float(np.mean(errors)) if errors else float("nan")
            max_error = float(np.max(errors)) if errors else float("nan")
            rows.append({
                "canonical": canonical,
                "solver_column": rule.solver_column,
                "sim_column": rule.sim_column,
                "n_checked": len(sample),
                "n_invalid": invalid,
                "mean_abs_error": mean_error,
                "max_abs_error": max_error,
                "status": "ok" if errors and invalid == 0 else "invalid rows present",
            })
        return pd.DataFrame(rows)


def parse_mapping_text(
    text: str,
    roles: ColumnRoles,
    available_columns: Iterable[str],
    *,
    mode: str = "standard",
) -> CoordinateBridge:
    """Parse tab-separated GUI mapping lines.

    Format per non-comment line::

    canonical_solver_column<TAB>solver_source_column<TAB>processed_SIM_column<TAB>expression<TAB>epsilon<TAB>denominator_expression

    The expression may be empty for an identity mapping.  Use ``{Column name}``
    for column names containing spaces or punctuation.  The optional final
    field is the actual denominator expression; rows whose absolute denominator
    is no greater than epsilon are marked invalid.  The left-hand canonical
    column is the column used by the model role configuration. In ablation mode
    it is normally the original/raw solver column; the SIM view stores the
    processed value under the same canonical name so the predictor and SIM APIs
    remain dimensionally aligned.  A legacy comma-separated denominator-column
    list is still accepted for older configurations.
    """
    rules: dict[str, TransformRule] = {}
    for line_number, raw in enumerate(str(text).splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = [part.strip() for part in raw.split("\t")]
        if len(parts) not in {4, 5, 6}:
            raise ValueError(
                f"Coordinate mapping line {line_number} must have 4, 5 or 6 tab-separated fields."
            )
        canonical, solver_column, sim_column, expression = parts[:4]
        epsilon = float(parts[4]) if len(parts) == 5 and parts[4] else 1e-12
        if len(parts) == 6 and parts[4]:
            epsilon = float(parts[4])
        denominator_spec = parts[5].strip() if len(parts) == 6 else ""
        denominator_columns: tuple[str, ...] = ()
        denominator_expression = ""
        if denominator_spec:
            # Keep accepting the original comma-separated column list, while
            # allowing a real composite denominator such as
            # ``({Ext. Voltage(kV)} - {Energy(keV)})``.
            legacy_list = "," in denominator_spec and not any(
                operator in denominator_spec for operator in ("+", "-", "*", "/", "(", ")")
            )
            if legacy_list:
                denominator_columns = tuple(
                    item.strip().strip("{}").strip()
                    for item in denominator_spec.replace("，", ",").split(",")
                    if item.strip()
                )
            else:
                denominator_expression = denominator_spec
        if canonical in rules:
            raise ValueError(f"Duplicate coordinate mapping for {canonical!r}.")
        rules[canonical] = TransformRule(
            canonical=canonical,
            solver_column=solver_column,
            sim_column=sim_column,
            expression=expression,
            epsilon=epsilon,
            denominator_columns=denominator_columns,
            denominator_expression=denominator_expression,
        )
    bridge = CoordinateBridge(mode=mode, rules=rules)
    bridge.validate(roles, available_columns)
    return bridge


def identity_bridge(roles: ColumnRoles) -> CoordinateBridge:
    rules = {
        name: TransformRule(name, name, name, "")
        for name in roles.feature_cols
    }
    return CoordinateBridge(mode="standard", rules=rules)
