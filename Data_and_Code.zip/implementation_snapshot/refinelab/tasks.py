from __future__ import annotations

import hashlib
import json
import threading
from dataclasses import asdict, dataclass
from typing import Callable, Dict, Iterable

import numpy as np
import pandas as pd

from .config import ColumnRoles, ControlBound, FUTURE_TASK_ROLE, TaskGenerationConfig
from .coordinates import CoordinateBridge, identity_bridge
from .data import ROLE_COL, SOURCE_ORDER_COL
from .models import HiddenEnvironmentSet
from .optimizers import SearchSpace, quantize_value


ALL_FUTURE_MODE = "All eligible Future Replay Tasks"
RANDOM_SUBSET_MODE = "Random subset of eligible Future Replay Tasks"
# Kept for reading manifests produced by the intermediate V4.0 build.
FIRST_QUALIFYING_START = "First qualifying random draw"
LEGACY_NEAREST_THRESHOLD_START = "Legacy nearest-below-threshold candidate"
LEGACY_RANDOM_DEGRADATION_START = "Legacy random degradation: first qualifying random draw"
LEGACY_HALF_FALLBACK_START = "Legacy random degradation: one random control halved after misses"
LEGACY_RANDOM_DEGRADATION_ATTEMPTS = 18
GenerationProgress = Callable[[int, int, int, str], None]


def _json_map(values: Dict[str, float]) -> str:
    return json.dumps({k: float(v) for k, v in values.items()}, ensure_ascii=False, sort_keys=True)


def _parse_map(value: str | Dict[str, float]) -> Dict[str, float]:
    if isinstance(value, dict):
        return {str(k): float(v) for k, v in value.items()}
    return {str(k): float(v) for k, v in json.loads(value).items()}


def _stable_task_seed(base_seed: int, machine_id: str, source_order: int) -> int:
    payload = f"{int(base_seed)}|{machine_id}|{int(source_order)}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:4], "little") & 0x7FFFFFFF


@dataclass(frozen=True)
class ReplayTask:
    task_id: str
    machine_id: str
    source_order: int
    target_beam: float
    target_source: str
    energy: float
    difficulty: float
    context_json: str
    reference_controls_json: str
    initial_controls_json: str
    initial_beam: float
    reference_environment_beam: float
    reference_error_fraction: float
    degradation_ratio_achieved: float
    task_seed: int
    simulator_estimator: str = ""
    generation_mode: str = RANDOM_SUBSET_MODE
    # This field name is retained for CSV/config compatibility.  It is the
    # legacy degradation retry count, not a candidate optimizer.  The old
    # implementation used exactly 18 attempts before its half-value fallback.
    initial_search_samples: int = LEGACY_RANDOM_DEGRADATION_ATTEMPTS
    degradation_threshold: float = 0.90
    initial_state_selection: str = LEGACY_NEAREST_THRESHOLD_START

    @property
    def context(self) -> Dict[str, float]:
        return _parse_map(self.context_json)

    @property
    def reference_controls(self) -> Dict[str, float]:
        return _parse_map(self.reference_controls_json)

    @property
    def initial_controls(self) -> Dict[str, float]:
        return _parse_map(self.initial_controls_json)


@dataclass
class TaskManifest:
    tasks: list[ReplayTask]
    requested_tasks: int
    candidate_rows: int
    excluded_reference_fidelity: int
    excluded_no_degraded_start: int
    seed: int
    excluded_invalid_rows: int = 0
    cancelled: bool = False

    def to_frame(self) -> pd.DataFrame:
        frame = pd.DataFrame([asdict(task) for task in self.tasks])
        if frame.empty:
            return frame
        metadata = {
            "manifest_requested_tasks": self.requested_tasks,
            "manifest_candidate_rows": self.candidate_rows,
            "manifest_excluded_invalid_rows": self.excluded_invalid_rows,
            "manifest_excluded_reference_fidelity": self.excluded_reference_fidelity,
            "manifest_excluded_no_degraded_start": self.excluded_no_degraded_start,
            "manifest_seed": self.seed,
            "manifest_cancelled": self.cancelled,
        }
        for name, value in metadata.items():
            frame[name] = value
        return frame

    @classmethod
    def from_frame(cls, frame: pd.DataFrame) -> "TaskManifest":
        if frame.empty:
            raise ValueError("Task CSV is empty.")
        tasks = []
        allowed = set(ReplayTask.__dataclass_fields__)
        for raw in frame.to_dict(orient="records"):
            row = dict(raw)
            row["task_id"] = str(row["task_id"])
            row["machine_id"] = str(row["machine_id"])
            row["source_order"] = int(row["source_order"])
            row["target_source"] = str(row["target_source"])
            row["task_seed"] = int(row["task_seed"])
            row["simulator_estimator"] = str(row.get("simulator_estimator", ""))
            row["generation_mode"] = str(row.get("generation_mode", "Loaded legacy manifest"))
            row["initial_search_samples"] = int(
                row.get("initial_search_samples", LEGACY_RANDOM_DEGRADATION_ATTEMPTS)
            )
            row["degradation_threshold"] = float(row.get("degradation_threshold", 0.90))
            row["initial_state_selection"] = str(
                row.get("initial_state_selection", LEGACY_NEAREST_THRESHOLD_START)
            )
            for name in (
                "target_beam",
                "energy",
                "difficulty",
                "initial_beam",
                "reference_environment_beam",
                "reference_error_fraction",
                "degradation_ratio_achieved",
            ):
                row[name] = float(row[name])
            tasks.append(ReplayTask(**{name: row[name] for name in allowed if name in row}))
        first = frame.iloc[0]

        def metadata_int(name: str, default: int) -> int:
            value = first.get(name, default)
            return default if pd.isna(value) else int(value)

        def metadata_bool(name: str, default: bool) -> bool:
            value = first.get(name, default)
            if pd.isna(value):
                return default
            if isinstance(value, str):
                return value.strip().lower() in {"1", "true", "yes", "y"}
            return bool(value)

        return cls(
            tasks=tasks,
            requested_tasks=metadata_int("manifest_requested_tasks", len(tasks)),
            candidate_rows=metadata_int("manifest_candidate_rows", len(tasks)),
            excluded_reference_fidelity=metadata_int(
                "manifest_excluded_reference_fidelity", 0
            ),
            excluded_no_degraded_start=metadata_int(
                "manifest_excluded_no_degraded_start", 0
            ),
            seed=metadata_int("manifest_seed", 0),
            excluded_invalid_rows=metadata_int("manifest_excluded_invalid_rows", 0),
            cancelled=metadata_bool("manifest_cancelled", False),
        )


def feature_vector(
    roles: ColumnRoles,
    controls: Dict[str, float],
    context: Dict[str, float],
) -> np.ndarray:
    merged = dict(context)
    merged.update(controls)
    missing = [name for name in roles.feature_cols if name not in merged]
    if missing:
        raise ValueError(f"Missing feature values: {missing}")
    return np.asarray([float(merged[name]) for name in roles.feature_cols], dtype=float)


def _finite_row_map(row: pd.Series, columns: Iterable[str]) -> Dict[str, float] | None:
    result: Dict[str, float] = {}
    for name in columns:
        value = pd.to_numeric(pd.Series([row[name]]), errors="coerce").iloc[0]
        if not np.isfinite(value):
            return None
        result[name] = float(value)
    return result


@dataclass
class _PreparedTask:
    row: pd.Series
    machine_id: str
    source_order: int
    target: float
    energy: float
    difficulty: float
    controls: Dict[str, float]
    context: Dict[str, float]
    reference_feature: np.ndarray
    task_seed: int
    reference_environment_beam: float = float("nan")
    reference_error_fraction: float = float("nan")


def _candidate_feature_matrix(
    roles: ColumnRoles,
    task: _PreparedTask,
    control_vectors: np.ndarray,
    bridge: CoordinateBridge | None = None,
    sim_bounds: Dict[str, ControlBound] | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    bridge = bridge or identity_bridge(roles)
    matrix = np.full((len(control_vectors), len(roles.feature_cols)), np.nan, dtype=float)
    valid = np.zeros(len(control_vectors), dtype=bool)
    for row_index, controls_vector in enumerate(control_vectors):
        controls = dict(zip(roles.controllable_cols, controls_vector))
        sim_controls, sim_context, meta = bridge.convert_feature_maps(
            controls,
            task.context,
            roles.controllable_cols,
            roles.monitorable_cols,
            sim_bounds=sim_bounds,
        )
        if meta["invalid"]:
            continue
        matrix[row_index] = feature_vector(roles, sim_controls, sim_context)
        valid[row_index] = True
    return matrix, valid


def generate_task_manifest(
    annotated: pd.DataFrame,
    roles: ColumnRoles,
    environments: HiddenEnvironmentSet,
    bounds: Dict[str, ControlBound],
    tuning_order: list[int],
    cfg: TaskGenerationConfig,
    simulator_estimator: str = "",
    *,
    sim_annotated: pd.DataFrame | None = None,
    bridge: CoordinateBridge | None = None,
    sim_bounds: Dict[str, ControlBound] | None = None,
    progress: GenerationProgress | None = None,
    cancel_event: threading.Event | None = None,
) -> TaskManifest:
    """Create frozen replay tasks with the legacy degraded-start protocol.

    The initial state intentionally follows the old implementation: draw a
    small task-seeded sequence of random full-space control vectors, accept the
    first frozen-SIM result below the degradation threshold, and, if none of
    those attempts qualifies, halve one randomly selected original control and
    use that fallback.  The fallback is retained even when it does not cross
    the threshold, because that is what the old replay code executed.

    ``initial_search_samples`` is retained as the configurable number of
    legacy random attempts (default 18).  It is unrelated to BO initialization
    and is deliberately not a 512-candidate search.
    """
    cfg.validate()
    cancel_event = cancel_event or threading.Event()
    bridge = bridge or identity_bridge(roles)
    sim_bounds = sim_bounds or bounds
    selection_rng = np.random.default_rng(cfg.seed)
    search_space = SearchSpace(roles.controllable_cols, bounds, tuning_order)

    task_rows = annotated[annotated[ROLE_COL] == FUTURE_TASK_ROLE].copy()
    machine_keys = task_rows[roles.machine_id].astype(str)
    task_rows = task_rows[machine_keys.isin(environments.models.keys())]
    beam = pd.to_numeric(task_rows[roles.beam], errors="coerce")
    energy = pd.to_numeric(task_rows[roles.energy], errors="coerce")
    difficulty = beam / np.clip(energy, 1e-9, None)
    mask = (
        np.isfinite(beam)
        & np.isfinite(energy)
        & (difficulty > cfg.difficulty_threshold)
        & (beam <= cfg.beam_max)
    )
    candidates = task_rows[mask].copy()
    sim_lookup = None
    if sim_annotated is not None:
        if SOURCE_ORDER_COL not in sim_annotated.columns:
            raise ValueError("SIM view must preserve _source_order for one-file coordinate matching.")
        sim_orders = set(pd.to_numeric(sim_annotated[SOURCE_ORDER_COL], errors="coerce").dropna().astype(int))
        candidates = candidates[candidates[SOURCE_ORDER_COL].isin(sim_orders)].copy()
        sim_lookup = sim_annotated.set_index(SOURCE_ORDER_COL, drop=False)
    candidates["_difficulty"] = difficulty[mask]
    candidates = candidates.sort_values(SOURCE_ORDER_COL, kind="stable").reset_index(drop=True)
    if candidates.empty:
        raise ValueError("No Future Replay Task rows satisfy the task filters.")

    if cfg.all_future_tasks:
        positions = np.arange(len(candidates), dtype=int)
        requested = len(candidates)
        generation_mode = ALL_FUTURE_MODE
    else:
        positions = selection_rng.permutation(len(candidates))
        requested = int(cfg.n_tasks)
        generation_mode = RANDOM_SUBSET_MODE

    prepared: list[_PreparedTask] = []
    excluded_invalid = 0
    for position in positions:
        row = candidates.iloc[int(position)]
        machine_id = str(row[roles.machine_id])
        controls = _finite_row_map(row, roles.controllable_cols)
        context = _finite_row_map(row, roles.monitorable_cols)
        if controls is None or context is None:
            excluded_invalid += 1
            continue
        if sim_lookup is not None:
            try:
                sim_row = sim_lookup.loc[int(row[SOURCE_ORDER_COL])]
                if isinstance(sim_row, pd.DataFrame):
                    sim_row = sim_row.iloc[0]
                if (
                    _finite_row_map(sim_row, roles.controllable_cols) is None
                    or _finite_row_map(sim_row, roles.monitorable_cols) is None
                ):
                    excluded_invalid += 1
                    continue
            except KeyError:
                excluded_invalid += 1
                continue
        sim_controls, sim_context, transform_meta = bridge.convert_feature_maps(
            controls,
            context,
            roles.controllable_cols,
            roles.monitorable_cols,
            sim_bounds=sim_bounds,
        )
        if transform_meta["invalid"]:
            excluded_invalid += 1
            continue
        source_order = int(row[SOURCE_ORDER_COL])
        prepared.append(
            _PreparedTask(
                row=row,
                machine_id=machine_id,
                source_order=source_order,
                target=float(row[roles.beam]),
                energy=float(row[roles.energy]),
                difficulty=float(row["_difficulty"]),
                controls=controls,
                context=context,
                reference_feature=feature_vector(roles, sim_controls, sim_context),
                task_seed=_stable_task_seed(cfg.seed, machine_id, source_order),
            )
        )

    tasks: list[ReplayTask] = []
    excluded_fidelity = 0
    excluded_degradation = 0
    processed = excluded_invalid
    total = len(candidates)
    batch_size = int(cfg.generation_batch_tasks)

    if progress:
        progress(processed, total, 0, "Preparing filtered Future rows")

    for start in range(0, len(prepared), batch_size):
        if cancel_event.is_set() or (not cfg.all_future_tasks and len(tasks) >= requested):
            break
        chunk = prepared[start : start + batch_size]

        for machine_id in dict.fromkeys(item.machine_id for item in chunk):
            machine_items = [item for item in chunk if item.machine_id == machine_id]
            X_reference = np.vstack([item.reference_feature for item in machine_items])
            prediction = environments.predict_output_many(machine_id, roles.beam, X_reference)
            for item, value in zip(machine_items, prediction):
                item.reference_environment_beam = float(value)
                item.reference_error_fraction = abs(float(value) - item.target) / max(abs(item.target), 1e-9)

        qualified = []
        for item in chunk:
            if item.reference_error_fraction > cfg.max_reference_error_fraction:
                excluded_fidelity += 1
            else:
                qualified.append(item)

        degraded: dict[int, tuple[float, np.ndarray, str]] = {}
        for machine_id in dict.fromkeys(item.machine_id for item in qualified):
            machine_items = [item for item in qualified if item.machine_id == machine_id]
            feature_blocks = []
            valid_blocks = []
            control_blocks = []
            attempt_counts = []
            for item in machine_items:
                task_rng = np.random.default_rng(item.task_seed)
                normalized = task_rng.random((cfg.initial_search_samples, search_space.dimension))
                controls = search_space.decode_many(normalized)
                # Exact legacy fallback: after the random attempts, copy the
                # observed Future-row controls, choose one control uniformly,
                # halve its raw value, then quantize in solver coordinates.
                # The coordinate bridge is applied only after this operation.
                fallback = np.asarray(
                    [item.controls[name] for name in roles.controllable_cols],
                    dtype=float,
                )
                fallback_index = int(task_rng.integers(0, search_space.dimension))
                fallback_name = roles.controllable_cols[fallback_index]
                fallback_bound = search_space.bounds[fallback_name]
                fallback[fallback_index] = quantize_value(
                    fallback_bound,
                    fallback[fallback_index] * 0.5,
                )
                controls = np.vstack([controls, fallback])
                control_blocks.append(controls)
                attempt_counts.append(int(cfg.initial_search_samples))
                features, valid = _candidate_feature_matrix(
                    roles,
                    item,
                    controls,
                    bridge=bridge,
                    sim_bounds=sim_bounds,
                )
                feature_blocks.append(features)
                valid_blocks.append(valid)
            if not feature_blocks:
                continue
            all_features = np.vstack(feature_blocks)
            all_valid = np.concatenate(valid_blocks)
            prediction = np.full(len(all_features), np.nan, dtype=float)
            if np.any(all_valid):
                prediction[all_valid] = environments.predict_output_many(
                    machine_id,
                    roles.beam,
                    all_features[all_valid],
                )
            offset = 0
            for item, controls, block_valid, attempt_count in zip(
                machine_items, control_blocks, valid_blocks, attempt_counts
            ):
                values = prediction[offset : offset + len(controls)]
                offset += len(controls)
                random_values = values[:attempt_count]
                acceptable = (
                    block_valid[:attempt_count]
                    & np.isfinite(random_values)
                    & (
                        random_values
                        < cfg.degradation_ratio * item.reference_environment_beam
                    )
                )
                if np.any(acceptable):
                    selected = int(np.flatnonzero(acceptable)[0])
                    degraded[item.source_order] = (
                        float(random_values[selected]),
                        controls[selected].copy(),
                        LEGACY_RANDOM_DEGRADATION_START,
                    )
                    continue

                # The old code always retained this one-control half fallback
                # after all random attempts.  It is not silently promoted to a
                # threshold-qualified draw; the manifest records that policy.
                fallback_index = len(controls) - 1
                if not block_valid[fallback_index] or not np.isfinite(
                    values[fallback_index]
                ):
                    continue
                degraded[item.source_order] = (
                    float(values[fallback_index]),
                    controls[fallback_index].copy(),
                    LEGACY_HALF_FALLBACK_START,
                )

        for item in qualified:
            candidate = degraded.get(item.source_order)
            if candidate is None:
                excluded_degradation += 1
                continue
            initial_beam, initial_vector, selection_policy = candidate
            initial_controls = dict(zip(roles.controllable_cols, initial_vector))
            tasks.append(
                ReplayTask(
                    task_id=f"{item.machine_id}__row_{item.source_order}",
                    machine_id=item.machine_id,
                    source_order=item.source_order,
                    target_beam=item.target,
                    target_source=f"observed successful {roles.beam}",
                    energy=item.energy,
                    difficulty=item.difficulty,
                    context_json=_json_map(item.context),
                    reference_controls_json=_json_map(item.controls),
                    initial_controls_json=_json_map(initial_controls),
                    initial_beam=initial_beam,
                    reference_environment_beam=item.reference_environment_beam,
                    reference_error_fraction=item.reference_error_fraction,
                    degradation_ratio_achieved=initial_beam / max(abs(item.target), 1e-9),
                    task_seed=item.task_seed,
                    simulator_estimator=simulator_estimator,
                    generation_mode=generation_mode,
                    initial_search_samples=cfg.initial_search_samples,
                    degradation_threshold=cfg.degradation_ratio,
                    initial_state_selection=selection_policy,
                )
            )
            if not cfg.all_future_tasks and len(tasks) >= requested:
                break

        processed = min(total, processed + len(chunk))
        if progress:
            progress(processed, total, len(tasks), "Batched degraded-state search")

    if not tasks and not cancel_event.is_set():
        raise RuntimeError(
            "No valid replay tasks were generated. Inspect SIM fidelity, bounds and degradation filters."
        )
    if cfg.all_future_tasks:
        tasks.sort(key=lambda task: task.source_order)
    return TaskManifest(
        tasks=tasks,
        requested_tasks=requested,
        candidate_rows=total,
        excluded_reference_fidelity=excluded_fidelity,
        excluded_no_degraded_start=excluded_degradation,
        seed=cfg.seed,
        excluded_invalid_rows=excluded_invalid,
        cancelled=cancel_event.is_set(),
    )
