from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.model_selection import KFold

from .config import ColumnRoles, FUTURE_TASK_ROLE, GLOBAL_TRAINING_ROLE
from .data import ROLE_COL, numeric_matrix
from .models import GlobalModelSet, HiddenEnvironmentSet


XGBOOST_NAME = "XGBoost"
RANDOM_FOREST_NAME = "Random Forest"
SUPPORTED_ESTIMATORS = (XGBOOST_NAME, RANDOM_FOREST_NAME)


def _set_inference_threads(model: Any, threads: int = 1) -> Any:
    """Keep fitted estimators safe for optional episode-level parallelism."""
    try:
        model.set_params(n_jobs=max(1, int(threads)))
    except (AttributeError, ValueError):
        pass
    return model


@dataclass(frozen=True)
class EvaluationMetric:
    model_role: str
    estimator: str
    machine_id: str
    evaluation: str
    mape_percent: float
    median_ape_percent: float
    signed_bias_percent: float
    r2: float
    n_train: int
    n_evaluation: int
    folds: int | None = None


def _metric_values(y_true: np.ndarray, y_pred: np.ndarray):
    y_true = np.asarray(y_true, dtype=float).reshape(-1)
    y_pred = np.asarray(y_pred, dtype=float).reshape(-1)
    denominator = np.clip(np.abs(y_true), 1e-6, None)
    relative = (y_pred - y_true) / denominator
    mape = float(np.mean(np.abs(relative)) * 100.0)
    median_ape = float(np.median(np.abs(relative)) * 100.0)
    signed_bias = float(np.mean(relative) * 100.0)
    r2 = float(r2_score(y_true, y_pred)) if len(y_true) >= 2 else float("nan")
    return mape, median_ape, signed_bias, r2


def _clean_xy(frame: pd.DataFrame, feature_cols: Iterable[str], output: str):
    X = numeric_matrix(frame, feature_cols)
    y = pd.to_numeric(frame[output], errors="coerce").to_numpy(dtype=float)
    mask = np.isfinite(X).all(axis=1) & np.isfinite(y)
    return X[mask], y[mask]


class EstimatorFactoryV33:
    def __init__(self, estimator: str, seed: int = 42):
        if estimator not in SUPPORTED_ESTIMATORS:
            raise ValueError(f"Unsupported estimator: {estimator}")
        self.estimator = estimator
        self.seed = int(seed)

    @property
    def adapter_factory_name(self) -> str:
        return "xgboost" if self.estimator == XGBOOST_NAME else "random_forest"

    def create(self, seed_offset: int = 0) -> Any:
        seed = self.seed + int(seed_offset)
        if self.estimator == RANDOM_FOREST_NAME:
            return RandomForestRegressor(
                n_estimators=350,
                max_features=0.8,
                min_samples_leaf=1,
                random_state=seed,
                n_jobs=-1,
            )
        try:
            from xgboost import XGBRegressor
        except ImportError as exc:
            raise RuntimeError("XGBoost is not installed. Run 'pip install -r requirements.txt'.") from exc
        return XGBRegressor(
            n_estimators=800,
            learning_rate=0.05,
            max_depth=8,
            subsample=0.9,
            colsample_bytree=0.9,
            reg_alpha=0.1,
            reg_lambda=1.0,
            random_state=seed,
            n_jobs=-1,
            objective="reg:squarederror",
        )


def _random_oof_predictions(
    X: np.ndarray,
    y: np.ndarray,
    factory: EstimatorFactoryV33,
    folds: int,
    seed_offset: int,
) -> np.ndarray:
    if len(X) < folds:
        raise ValueError(f"Cannot run {folds}-fold evaluation with only {len(X)} rows.")
    predictions = np.full(len(y), np.nan, dtype=float)
    splitter = KFold(n_splits=folds, shuffle=True, random_state=factory.seed + seed_offset)
    for fold_index, (train_index, test_index) in enumerate(splitter.split(X)):
        model = factory.create(seed_offset + fold_index + 1)
        model.fit(X[train_index], y[train_index])
        predictions[test_index] = model.predict(X[test_index])
    if not np.isfinite(predictions).all():
        raise RuntimeError("Out-of-fold predictions are incomplete.")
    return predictions


@dataclass
class GlobalPredictorCatalog:
    models: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    metrics: list[EvaluationMetric] = field(default_factory=list)

    def as_model_set(self, estimator: str) -> GlobalModelSet:
        if estimator not in self.models:
            raise KeyError(f"Global predictor not trained: {estimator}")
        return GlobalModelSet(models=self.models[estimator], metrics=[])


@dataclass
class SimulatorCatalog:
    models: Dict[str, Dict[str, Dict[str, Any]]] = field(default_factory=dict)
    metrics: list[EvaluationMetric] = field(default_factory=list)

    def as_environment_set(self, estimator: str) -> HiddenEnvironmentSet:
        if estimator not in self.models:
            raise KeyError(f"SIM not trained: {estimator}")
        return HiddenEnvironmentSet(models=self.models[estimator], metrics=[])


def train_global_predictor_catalog(
    annotated: pd.DataFrame,
    roles: ColumnRoles,
    estimators: Iterable[str],
    folds: int = 5,
    seed: int = 42,
    progress: Callable[[str], None] | None = None,
) -> GlobalPredictorCatalog:
    training = annotated[annotated[ROLE_COL] == GLOBAL_TRAINING_ROLE]
    future = annotated[annotated[ROLE_COL] == FUTURE_TASK_ROLE]
    catalog = GlobalPredictorCatalog()

    for estimator_index, estimator in enumerate(estimators):
        factory = EstimatorFactoryV33(estimator, seed=seed)
        catalog.models[estimator] = {}
        for output_index, output in enumerate(roles.output_cols):
            X_train, y_train = _clean_xy(training, roles.feature_cols, output)
            X_future, y_future = _clean_xy(future, roles.feature_cols, output)
            if len(X_train) < max(20, folds) or len(X_future) < 2:
                continue
            if progress:
                progress(f"[{estimator}] Global predictor random {folds}-fold OOF: {output}")
            oof = _random_oof_predictions(
                X_train,
                y_train,
                factory,
                folds,
                seed_offset=estimator_index * 1000 + output_index * 100,
            )
            values = _metric_values(y_train, oof)
            catalog.metrics.append(
                EvaluationMetric(
                    "Global predictor",
                    estimator,
                    "ALL",
                    "Global Training random-fold out-of-fold",
                    *values,
                    n_train=len(X_train) - int(round(len(X_train) / folds)),
                    n_evaluation=len(X_train),
                    folds=folds,
                )
            )

            if progress:
                progress(f"[{estimator}] Fit final Global predictor on all Global Training rows: {output}")
            final_model = factory.create(seed_offset=50_000 + output_index)
            final_model.fit(X_train, y_train)
            _set_inference_threads(final_model)
            catalog.models[estimator][output] = final_model

            in_sample = final_model.predict(X_train)
            values = _metric_values(y_train, in_sample)
            catalog.metrics.append(
                EvaluationMetric(
                    "Global predictor",
                    estimator,
                    "ALL",
                    "Global Training in-sample fit",
                    *values,
                    n_train=len(X_train),
                    n_evaluation=len(X_train),
                )
            )

            future_prediction = final_model.predict(X_future)
            values = _metric_values(y_future, future_prediction)
            catalog.metrics.append(
                EvaluationMetric(
                    "Global predictor",
                    estimator,
                    "ALL",
                    "Future Replay Tasks out-of-time",
                    *values,
                    n_train=len(X_train),
                    n_evaluation=len(X_future),
                )
            )

        if roles.beam not in catalog.models[estimator]:
            raise RuntimeError(f"Beam Global predictor could not be trained with {estimator}.")
    return catalog


def train_simulator_catalog(
    annotated: pd.DataFrame,
    roles: ColumnRoles,
    estimators: Iterable[str],
    folds: int = 5,
    seed: int = 42,
    progress: Callable[[str], None] | None = None,
) -> SimulatorCatalog:
    eligible = annotated[annotated[ROLE_COL].isin((GLOBAL_TRAINING_ROLE, FUTURE_TASK_ROLE))]
    catalog = SimulatorCatalog()
    machine_ids = eligible[roles.machine_id].dropna().unique().tolist()

    for estimator_index, estimator in enumerate(estimators):
        factory = EstimatorFactoryV33(estimator, seed=seed)
        catalog.models[estimator] = {}
        for machine_index, machine_id in enumerate(machine_ids):
            machine_frame = eligible[eligible[roles.machine_id] == machine_id]
            key = str(machine_id)
            machine_models: Dict[str, Any] = {}
            for output_index, output in enumerate(roles.output_cols):
                X, y = _clean_xy(machine_frame, roles.feature_cols, output)
                if len(X) < max(20, folds):
                    continue
                if progress:
                    progress(
                        f"[{estimator}] SIM {key}: random {folds}-fold OOF fidelity ({len(X)} rows)"
                    )
                offset = 100_000 + estimator_index * 10_000 + machine_index * 100 + output_index * 10
                oof = _random_oof_predictions(X, y, factory, folds, offset)
                values = _metric_values(y, oof)
                catalog.metrics.append(
                    EvaluationMetric(
                        "Per-machine SIM",
                        estimator,
                        key,
                        "Random-fold out-of-fold fidelity",
                        *values,
                        n_train=len(X) - int(round(len(X) / folds)),
                        n_evaluation=len(X),
                        folds=folds,
                    )
                )
                if progress:
                    progress(f"[{estimator}] SIM {key}: refit frozen model on 100% machine rows")
                final_model = factory.create(offset + 9)
                final_model.fit(X, y)
                _set_inference_threads(final_model)
                machine_models[output] = final_model
            if roles.beam in machine_models:
                catalog.models[estimator][key] = machine_models
        if not catalog.models[estimator]:
            raise RuntimeError(f"No per-machine SIM could be trained with {estimator}.")
    return catalog
