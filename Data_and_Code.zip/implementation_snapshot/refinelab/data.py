from __future__ import annotations

from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from .config import ColumnRoles, ControlBound, GLOBAL_TRAINING_ROLE


SOURCE_ORDER_COL = "_source_order"
TOOL_ORDER_COL = "_tool_order"
ROLE_COL = "_protocol_role"


def load_excel(path: str | Path, sheet_name=0) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() == ".csv":
        frame = pd.read_csv(path)
    else:
        frame = pd.read_excel(path, sheet_name=sheet_name)
    if frame.empty:
        raise ValueError("The selected input table is empty.")
    return prepare_frame(frame)


def prepare_frame(frame: pd.DataFrame) -> pd.DataFrame:
    out = frame.copy().reset_index(drop=True)
    reserved = {SOURCE_ORDER_COL, TOOL_ORDER_COL, ROLE_COL}
    conflict = reserved.intersection(map(str, out.columns))
    if conflict:
        raise ValueError(f"Input data contains reserved columns: {sorted(conflict)}")
    out[SOURCE_ORDER_COL] = np.arange(len(out), dtype=int)
    return out


def add_within_tool_order(frame: pd.DataFrame, machine_id_col: str) -> pd.DataFrame:
    if machine_id_col not in frame.columns:
        raise ValueError(f"Machine ID column not found: {machine_id_col}")
    out = frame.copy()
    if SOURCE_ORDER_COL not in out.columns:
        out[SOURCE_ORDER_COL] = np.arange(len(out), dtype=int)
    out = out.sort_values(SOURCE_ORDER_COL, kind="stable")
    out[TOOL_ORDER_COL] = out.groupby(machine_id_col, sort=False).cumcount()
    return out.sort_values(SOURCE_ORDER_COL, kind="stable").reset_index(drop=True)


def numeric_matrix(frame: pd.DataFrame, columns: Iterable[str]) -> np.ndarray:
    return frame[list(columns)].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)


def finite_rows(frame: pd.DataFrame, columns: Iterable[str]) -> pd.Series:
    arr = numeric_matrix(frame, columns)
    return pd.Series(np.isfinite(arr).all(axis=1), index=frame.index)


def infer_resolution(values: pd.Series) -> float:
    arr = pd.to_numeric(values, errors="coerce").to_numpy(dtype=float)
    arr = arr[np.isfinite(arr)]
    if arr.size < 2:
        return 0.01
    unique = np.unique(np.round(arr, 10))
    if unique.size < 2:
        return 0.01
    if np.allclose(unique, np.round(unique)):
        return 1.0
    diff = np.diff(np.sort(unique))
    diff = diff[diff > 1e-10]
    if diff.size == 0:
        return 0.01
    raw = float(np.quantile(diff, 0.10))
    common = np.asarray([0.0001, 0.001, 0.01, 0.02, 0.05, 0.1, 0.5, 1.0])
    near = common[np.argmin(np.abs(common - raw))]
    if abs(near - raw) / max(abs(near), 1e-12) < 0.25:
        return float(near)
    return max(raw, 1e-6)


def derive_visible_bounds(
    annotated: pd.DataFrame,
    roles: ColumnRoles,
    visible_protocol_roles=("G", "A"),
) -> dict[str, ControlBound]:
    visible = annotated[annotated[ROLE_COL].isin(visible_protocol_roles)]
    if visible.empty:
        raise ValueError("No visible G/A rows are available for bound derivation.")
    bounds: dict[str, ControlBound] = {}
    for name in roles.controllable_cols:
        values = pd.to_numeric(visible[name], errors="coerce")
        values = values[np.isfinite(values)]
        if values.empty:
            raise ValueError(f"No finite visible values for controllable: {name}")
        bounds[name] = ControlBound(
            minimum=float(values.min()),
            maximum=float(values.max()),
            resolution=infer_resolution(values),
        )
    return bounds


def derive_global_training_bounds(
    annotated: pd.DataFrame,
    roles: ColumnRoles,
) -> dict[str, ControlBound]:
    return derive_visible_bounds(
        annotated,
        roles,
        visible_protocol_roles=(GLOBAL_TRAINING_ROLE,),
    )
