# -*- coding: utf-8 -*-
"""V3-based Fig. 4: new workflow panel, updated b/c, compact full-result panel d."""
from pathlib import Path
import json,sys,argparse,os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,Rectangle

ROOT=Path(__file__).resolve().parents[1]
OUT=Path(os.environ.get('REFINELAB_PLOT_OUT', str(ROOT/'recomputed_figures')));FIG=OUT/'figures';DATA=OUT/'figure_data'
OLD=Path(os.environ.get('REFINELAB_PUBLICATION_ROOT', str(ROOT)))
parser=argparse.ArgumentParser(description='Recreate TSM-V1 Fig. 4 from saved aggregate data. No fitting or replay.')
parser.add_argument('--published-data',type=Path,help='Directory containing the published Fig4 CSV/JSON source tables')
parser.add_argument('--output',type=Path,help='Output directory for PNG, PDF and SVG')
ARGS=parser.parse_args()
if ARGS.published_data:
    DATA=ARGS.published_data.resolve();FIG=(ARGS.output or Path.cwd()/'recreated_figures').resolve()
    R=pd.read_csv(DATA/'all_17_configuration_results.csv').set_index('label')
else:
    R=pd.read_csv(OLD/'analysis/configuration_results.csv').query("cohort=='main'").set_index('label')
    E=json.loads((OLD/'analysis/paper_evidence.json').read_text(encoding='utf-8'))
    if ARGS.output:FIG=ARGS.output.resolve()
FIG.mkdir(exist_ok=True,parents=True)
if not ARGS.published_data:DATA.mkdir(exist_ok=True,parents=True)
BLUE='#215d83';TEAL='#267568';GREY='#777f85';GOLD='#b78e43';INK='#253642'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,
 'axes.titlesize':8.5,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,
 'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.spines.right':False,
 'axes.spines.top':False})

def panel_a(ax):
    ax.set(xlim=(0,12),ylim=(0,4.05));ax.axis('off')
    def box(x,y,w,h,text,fill='#f4f6f7',edge='#aebbc3',fs=8,bold=False):
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.035,rounding_size=.06',
            facecolor=fill,edgecolor=edge,linewidth=.8))
        ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=fs,color=INK,
                weight='bold' if bold else 'normal',linespacing=1.35)
    def arrow(p,q,color=GREY,ls='-',lw=.9):
        ax.annotate('',xy=q,xytext=p,arrowprops=dict(arrowstyle='-|>',lw=lw,color=color,
                    linestyle=ls,shrinkA=2,shrinkB=2,mutation_scale=8))
    ax.text(0,3.99,'a',weight='bold',fontsize=11,va='top')
    ax.text(.34,3.99,'Residual-adapted tuning workflow',weight='bold',fontsize=9,va='top')
    # The small upper lane supplies historical information; the main loop is below.
    box(.25,2.80,2.25,.59,'Aligned production\nlogs',fs=7.6)
    box(3.06,2.80,3.20,.59,'Pooled global predictor',fill='#eef4f8',edge=BLUE,fs=7.9)
    box(6.85,2.80,4.15,.59,'Cached same-tool / energy residual',fill='#eef5f2',edge=TEAL,fs=7.9)
    arrow((2.5,3.095),(3.06,3.095));arrow((6.26,3.095),(6.85,3.095),ls='--')
    ax.text(.25,3.53,'BEFORE TUNING',fontsize=6.8,color=GREY,weight='bold')
    ax.text(.25,2.44,'DURING ONE TUNING ATTEMPT',fontsize=6.8,color=BLUE,weight='bold')
    box(.25,1.18,3.24,.88,'Search on corrected predictions\nPSO / CMA-ES / random shooting',fill='#e9f1f7',edge=BLUE,fs=7.2,bold=False)
    box(4.13,1.18,2.72,.88,'Apply changed controls\nin the fixed order',fill='#f5f6f7',fs=8)
    box(7.49,1.18,3.51,.88,'Frozen tool-specific SIM\nreturn beam-current feedback',fill='#fbf5e8',edge=GOLD,fs=8)
    arrow((3.49,1.62),(4.13,1.62),BLUE);arrow((6.85,1.62),(7.49,1.62),BLUE)
    arrow((4.66,2.8),(2.05,2.06),BLUE,ls='--')
    arrow((8.93,2.8),(3.04,2.06),TEAL,ls='--')
    box(3.74,.12,3.43,.58,'Update the current-task residual',fill='#eef5f2',edge=TEAL,fs=7.8)
    ax.plot([8.82,8.82,7.17],[1.18,.41,.41],lw=1,color=TEAL)
    arrow((7.52,.41),(7.17,.41),TEAL)
    ax.plot([3.74,1.85,1.85],[.41,.41,1.18],lw=1,color=TEAL)
    arrow((1.85,.76),(1.85,1.18),TEAL)
    ax.text(9.15,.65,'Target reached: stop\nOtherwise: next round',fontsize=7.1,color=INK,ha='left',va='center',linespacing=1.4)
    ax.text(.25,-.03,'The global predictor and historical residual stay fixed; current feedback is incorporated at the end of a round.',
            fontsize=6.8,color=GREY,ha='left',va='top')

def main():
    sys.stdout.reconfigure(encoding='utf-8')
    if ARGS.published_data:
        curves=pd.read_csv(DATA/'Fig4b_success_by_feedback.csv')
        bins=pd.read_csv(DATA/'Fig4c_feedback_distribution.csv')
        edges=np.r_[bins.bin_left.to_numpy(),bins.bin_right.iloc[-1]]
        count=bins.successful_tasks.to_numpy()
        saved=json.loads((DATA/'Fig4_summary.json').read_text(encoding='utf-8'))
        median=saved['median_successful_feedbacks'];mean=saved['mean_successful_feedbacks']
    else:
        curves=pd.read_csv(OLD/'figure_data/Fig2_success_by_probe.csv')
        curves.to_csv(DATA/'Fig4b_success_by_feedback.csv',index=False)
        d=pd.read_csv(OLD/'private_filtered_archive'/E['configuration_sources']['PSO_Res'])
        assert len(d)==12096
        values=d.loc[d.success,'total_probes'].to_numpy()
        edges=np.arange(0,245,4)
        count,_=np.histogram(values,bins=edges)
        median=float(np.median(values));mean=float(np.mean(values))
        pd.DataFrame({'bin_left':edges[:-1],'bin_right':edges[1:],'successful_tasks':count}).to_csv(DATA/'Fig4c_feedback_distribution.csv',index=False)
        matrix=R.loc[[p+'_'+s for p in ['PSO','CMA','RS'] for s in ['None','Cal','Res','WRes']]].copy()
        matrix.reset_index().to_csv(DATA/'Fig4d_search_adapter_results.csv',index=False)
        R.reset_index().to_csv(DATA/'all_17_configuration_results.csv',index=False)
    fig=plt.figure(figsize=(7.16,7.0))
    gs=fig.add_gridspec(3,2,height_ratios=[1.15,1.12,1.10],left=.075,right=.985,
                       top=.975,bottom=.065,hspace=.49,wspace=.30)
    panel_a(fig.add_subplot(gs[0,:]))
    ax=fig.add_subplot(gs[1,0])
    for key,label,color in [('BO',f'BO comparator ({100*R.loc["BO","success"]:.2f}%)',GREY),
                            ('PSO_Res',f'PSO + residual ({100*R.loc["PSO_Res","success"]:.2f}%)',BLUE)]:
        q=curves[curves.configuration.eq(key)]
        ax.step(np.r_[0,q.probe_budget],np.r_[0,q.cumulative_success*100],where='post',lw=1.35,color=color,label=label)
    ax.set(xlim=(0,240),ylim=(0,101),xlabel='Feedback measurements',ylabel='Tasks solved (%)')
    ax.set_xticks([0,60,120,180,240]);ax.grid(axis='y',alpha=.16)
    ax.legend(frameon=False,loc='lower right',fontsize=6.6)
    ax.set_title('b  Success within a feedback budget',loc='left',weight='bold',pad=8)
    # Label the actual final-budget effect, not an unrelated early-budget gap.
    gain=100*(R.loc['PSO_Res','success']-R.loc['BO','success'])
    ax=fig.add_subplot(gs[1,1])
    ax.bar(edges[:-1],count,width=np.diff(edges),align='edge',color=BLUE,edgecolor='white',lw=.25,alpha=.88)
    ax.axvline(median,color=GOLD,lw=1,ls='--')
    ax.text(.97,.94,f'Median {median:.0f}\nMean {mean:.2f}',transform=ax.transAxes,ha='right',va='top',fontsize=7.3,linespacing=1.4)
    ax.set(xlim=(0,240),xlabel='Feedback measurements to success',ylabel='Successful tasks')
    ax.set_xticks([0,60,120,180,240]);ax.grid(axis='y',alpha=.14)
    ax.set_title('c  Feedback use among successful tasks',loc='left',weight='bold',pad=8)
    ax=fig.add_subplot(gs[2,:]);ax.set(xlim=(0,7.8),ylim=(0,4.55));ax.axis('off')
    ax.text(-.02,4.50,'d  Search and adapter comparisons',fontsize=9,weight='bold',va='top',color=INK)
    x0=1.62;cellw=2.03;cellh=.76
    for j,title in enumerate(['PSO','CMA-ES','Random shooting']):
        ax.text(x0+(j+.5)*cellw,3.91,title,ha='center',va='center',fontsize=8.3,weight='bold',color=INK)
    for i,(s,label) in enumerate([('None','No adapter'),('Cal','Calibrator'),('Res','Residual'),('WRes','Weighted residual')]):
        y=3.48-(i+1)*cellh
        ax.text(.02,y+cellh/2,label,ha='left',va='center',fontsize=8,color=INK)
        for j,p in enumerate(['PSO','CMA','RS']):
            z=R.loc[p+'_'+s]
            fill='#ffffff'
            ax.add_patch(Rectangle((x0+j*cellw,y),cellw,cellh,facecolor=fill,edgecolor='#ccd6dd',linewidth=.6))
            ax.text(x0+(j+.5)*cellw,y+.49,f'{100*z.success:.2f}%',ha='center',va='center',fontsize=9,weight='normal',color='#111111')
            ax.text(x0+(j+.5)*cellw,y+.20,f'{z.successful_rounds:.2f} rounds  |  {z.successful_probes:.2f} meas.',
                    ha='center',va='center',fontsize=6.8,color='#111111')
    ax.text(.02,-.04,'Each cell: success rate; mean rounds and measurements among successful tasks. XGBoost global predictor; N = 12,096 per cell.',
            fontsize=6.5,va='top',color=GREY)
    for suffix in ['png','pdf','svg']:
        fig.savefig(FIG/f'Fig4_TSM-V2.{suffix}',dpi=450,facecolor='white',bbox_inches='tight',pad_inches=.06)
    plt.close(fig)
    # A stand-alone large workflow is also provided for inspection and future editing.
    fa,aa=plt.subplots(figsize=(7.16,2.42));panel_a(aa);fa.tight_layout(pad=.4)
    for suffix in ['png','pdf','svg']:fa.savefig(FIG/f'Fig4a_workflow.{suffix}',dpi=450,bbox_inches='tight',facecolor='white')
    plt.close(fa)
    if not ARGS.published_data:
        (DATA/'Fig4_summary.json').write_text(json.dumps({'tasks':12096,'PSO_residual_success':float(R.loc['PSO_Res','success']),
            'BO_success':float(R.loc['BO','success']),'median_successful_feedbacks':median,
            'mean_successful_feedbacks':mean,'b_full_feedback_range':240,'new_training_or_replay':False},indent=2),encoding='utf-8')
    print('Created Fig. 4 and panel a from the existing 12,096-task results.')

if __name__=='__main__':main()
