# -*- coding: utf-8 -*-
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];AN=ROOT/'figure_data';FIG=ROOT/'recreated_figures';FD=ROOT/'figure_data'
FIG.mkdir(exist_ok=True);FD.mkdir(exist_ok=True)
data=pd.read_csv(AN/'tolerance_results.csv');paired=pd.read_csv(AN/'tolerance_paired_contrasts.csv')
for name in ['tolerance_results.csv','tolerance_paired_contrasts.csv','RF_vs_XGB_by_equipment.csv']:
    pd.read_csv(AN/name).to_csv(FD/name,index=False)
screen=pd.DataFrame([
 ['LSBoost',.010927,.98654],['XGBoost',.008411,.99127],['Decision tree',.0095049,.98289],['Random forest',.008678,.98992],
 ['LSTM',.030726,.92221],['Bi-LSTM',.030726,.92221],['iTransformer',.037571,.94295]],columns=['model','MAE_original_screen_scale','R2'])
screen['input_variant']='10 inputs including Arc Voltage';screen['relative_MAE_to_XGBoost']=screen.MAE_original_screen_scale/.008411
screen.to_csv(FD/'early_model_screen.csv',index=False)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':9,'legend.fontsize':8,
                     'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.right':False,'axes.spines.top':False})
fig,axes=plt.subplots(1,2,figsize=(7.16,2.65),gridspec_kw={'width_ratios':[1.15,1]},layout='constrained')
styles=[('BO','BO comparator','#7b7b7b','o'),('PSO_Res','XGBoost + residual PSO','#245e83','s'),('RF_Res','RF + residual PSO','#111111','^')]
ax=axes[0]
for key,label,color,marker in styles:
    d=data[data.configuration.eq(key)].sort_values('tolerance')
    ax.plot(d.tolerance*100,d.observed_attainment*100,color=color,marker=marker,markersize=4,lw=1.2,label=label)
ax.set(xlabel='Target tolerance (±%)',ylabel='Recorded-trajectory attainment (%)',xticks=[2,3,5,7],ylim=(20,103))
ax.grid(axis='y',color='#e4e4e4',lw=.6);ax.legend(frameon=False,loc='lower right')
ax.set_title('a  Attainment across tolerances',loc='left',fontsize=9.5)
ax=axes[1]
for i,(key,label,color,marker) in enumerate(styles[1:]):
    d=paired[(paired.method==key)&(paired.baseline=='BO')].sort_values('tolerance');xx=d.tolerance.to_numpy()*100+(i-.5)*.12
    yy=d.difference.to_numpy()*100;err=np.stack([yy-d.ci_low.to_numpy()*100,d.ci_high.to_numpy()*100-yy])
    ax.errorbar(xx,yy,yerr=err,color=color,marker=marker,markersize=4,capsize=2,lw=1,label=label)
ax.axhline(0,color='#777777',ls='--',lw=.8);ax.set(xlabel='Target tolerance (±%)',ylabel='Attainment gain over BO (pp)',xticks=[2,3,5,7],ylim=(0,8.5))
ax.grid(axis='y',color='#e4e4e4',lw=.6);ax.set_title('b  Paired gain and 95% interval',loc='left',fontsize=9.5)
for ax in axes:ax.axvline(5,color='#bbbbbb',ls=':',lw=.8,zorder=0)
for suffix in ['png','pdf','svg']:fig.savefig(FIG/f'FigS1_tolerance.{suffix}',dpi=450,bbox_inches='tight',pad_inches=.07)
plt.close(fig)
print('Created tolerance figure and exported original-scale early-screen transcription.')
