"""Compose supplied SHAP panels without resampling or altering their point layers."""
from pathlib import Path
from copy import deepcopy
from lxml import etree as E
from PIL import Image
from io import BytesIO
import base64,hashlib,json,re

HERE=Path(__file__).resolve().parent
OUT=HERE.parent
WORK=HERE
SRC=HERE/'panels' if (HERE/'panels').is_dir() else HERE/'svg_sources'
DEST=HERE if (HERE/'panels').is_dir() else OUT/'publication_graphics'
SVG='http://www.w3.org/2000/svg'
XLINK='http://www.w3.org/1999/xlink'
Q=lambda n:'{'+SVG+'}'+n
WIDTH=10040/1440*72

def prepare(root,prefix,replacements):
    ids={el.get('id'):prefix+'_'+el.get('id') for el in root.iter() if el.get('id')}
    for el in list(root.iter()):
        if E.QName(el).localname in ['metadata','namedview']:
            if el.getparent() is not None:el.getparent().remove(el)
            continue
        if el.tag==Q('text'):
            s=''.join(el.itertext()).strip()
            if s in ['a','b','c','d'] or 'Data distribution of ' in s or s.startswith('SHAP dependence:'):
                el.getparent().remove(el);continue
        for k,val in list(el.attrib.items()):
            if k=='id':el.set(k,ids[val]);continue
            if val.startswith('#') and val[1:] in ids:el.set(k,'#'+ids[val[1:]])
            else:
                el.set(k,re.sub(r'url\(#([^)]+)\)',lambda m:'url(#'+ids.get(m.group(1),m.group(1))+')',val))
        if el.text:
            for old,new in replacements.items():el.text=el.text.replace(old,new)
    return root

def compose(names,filename):
    gap=10;panel_w=(WIDTH-gap)/2
    rows=1 if len(names)==2 else 2
    parsed=[];rowheights=[0]*rows;manifest=[]
    for j,name in enumerate(names):
        src=SRC/(name+'.svg');root=E.fromstring(src.read_bytes())
        view=list(map(float,root.get('viewBox').split()));scale=panel_w/view[2]
        rowheights[j//2]=max(rowheights[j//2],view[3]*scale)
        replacements={'Arc Current(mA)':'Arc Current (mA)'}
        if name=='2a':replacements['Ext. Electrode Tilt Raw']='Recorded Tilt'
        if name=='2b':replacements['Ext. Electrode Tilt']='Relative Tilt'
        if name.startswith('2'):replacements['Ext. Electrode Gap']='Gap (controller units)'
        if name=='3a':replacements['SAM Magnetic Flux(G)']='SAM field (G)'
        if name=='3b':replacements['SAM in Physical coordinate']='Normalized SAM field'
        if name=='3d':replacements['Focus_Bias_Ratio']='Focusing-bias index'
        # Do not replace generic Arc Current inside longer strings a second time.
        if name in ['3b','3d']:
            for el in root.findall('.//'+Q('text')):
                if ''.join(el.itertext()).strip()=='Arc Current':
                    for t in el.iter():
                        if t.text=='Arc Current':t.text='Arc Current (mA)'
        raster=[]
        for node in root.findall('.//'+Q('image')):
            href=node.get('{'+XLINK+'}href',node.get('href',''))
            if href.startswith('data:'):
                im=Image.open(BytesIO(base64.b64decode(href.split(',')[1])))
                raster.append({'pixels':list(im.size),'effective_dpi_at_composed_scale':im.width/(float(node.get('width'))*scale/72)})
        parsed.append((name,prepare(root,name,replacements),view,scale))
        manifest.append({'panel':name,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'embedded_rasters':raster})
    height=sum(rowheights)+(rows-1)*12
    root=E.Element(Q('svg'),nsmap={None:SVG,'xlink':XLINK},width=f'{WIDTH}pt',height=f'{height}pt',viewBox=f'0 0 {WIDTH} {height}',version='1.1')
    E.SubElement(root,Q('rect'),x='0',y='0',width=str(WIDTH),height=str(height),fill='white')
    for j,(name,panel,view,scale) in enumerate(parsed):
        x=(j%2)*(panel_w+gap);y=sum(rowheights[:j//2])+(12 if j//2 else 0)
        group=E.SubElement(root,Q('g'),transform=f'translate({x},{y}) scale({scale}) translate({-view[0]},{-view[1]})')
        for child in list(panel):group.append(deepcopy(child))
        label=E.SubElement(root,Q('text'),x=str(x+2),y=str(y+15),fill='black',style='font-family:Arial,Helvetica,sans-serif;font-size:12px;font-weight:bold')
        label.text=chr(97+j)
    p=DEST/filename;p.parent.mkdir(exist_ok=True)
    p.write_bytes(E.tostring(root,xml_declaration=True,encoding='utf-8'))
    return {'figure':filename,'width_pt':WIDTH,'height_pt':height,'panels':manifest,
            'changes':'Panel arrangement and letters unified; descriptive labels shortened; point rasters and histogram paths retained. Fig3 uses 3a, 3b, 3c and 3d, following the author correction.',
            'source_scope_confirmation_pending':False}

if __name__=='__main__':
    items=[compose(['2a','2b'],'wu2.svg'),compose(['3a','3b','3c','3d'],'wu3.svg')]
    (WORK/'svg_composition.json').write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(items,ensure_ascii=False,indent=2))
