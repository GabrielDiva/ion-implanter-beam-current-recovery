Separate figures for IEEE Access review

wu1.pdf uses the author-provided vector Illustrator PDF export, scaled proportionally
to the manuscript width. The matching TIFF is rendered at 600 dpi. The supplied
PDF and AI source files are retained unchanged outside this upload archive.

wu2 and wu3 use the supplied SVG panels, with vector text, axes and histogram
paths. Their embedded point rasters are retained, about 209 dpi at the final panel
size. A 600 dpi TIFF is a rendering format, not evidence of 600 dpi native points.
Fig. 3 uses 3a/3b/3c/3d, as confirmed by the author.

wu4, wuS1 and wuS2 retain the existing code-generated vector PDF content; TIFF
alternatives are rendered at 600 dpi. Captions are supplied separately as text.
See Figure_Quality_Checklist.csv for source hashes, pixels and quality status.
