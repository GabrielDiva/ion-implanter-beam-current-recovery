"""Reproduce Fig S2 from outward aggregate data without private job records."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--data-dir',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--out-dir',type=Path,default=None)
    args=parser.parse_args();out=args.out_dir or args.data_dir
    out.mkdir(parents=True,exist_ok=True)
    per=pd.read_csv(args.data_dir/'equipment_success_and_SIM_OOF_error.csv')
    groups=pd.read_csv(args.data_dir/'reference_agreement_subgroups.csv')
    assert len(per)==39 and len(groups)==34
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
    names={'BO':'Task-local BO','PSO_Res':'XGBoost + residual PSO','RF_Res':'RF + residual PSO'}
    colors={'BO':'#7b8187','PSO_Res':'#225f85','RF_Res':'#326b53'}
    markers={'BO':'o','PSO_Res':'s','RF_Res':'^'}
    fig,ax=plt.subplots(1,2,figsize=(10,4.1))
    for label in names:
        q=per[per.label.eq(label)]
        ax[0].scatter(q.mape_percent,100*q.success,label=names[label],marker=markers[label],color=colors[label],s=30,alpha=.82)
    ax[0].axvline(5,color='#aaa',ls='--',lw=.8)
    ax[0].set(xlabel='Tool SIM production-point OOF MAPE (%)',ylabel='Virtual recovery success (%)',ylim=(86,101))
    ax[0].set_title('a  Equipment-level diagnostic',loc='left',fontweight='bold')
    for j,label in enumerate(names):
        q=groups[groups.configuration.eq(label)].set_index('reference_agrees_5pct')
        ax[1].bar(np.array([0,1])+(j-1)*.23,[100*q.loc[True,'success_rate'],100*q.loc[False,'success_rate']],width=.23,color=colors[label])
    ax[1].set_xticks([0,1],['Reference agrees\nn = 11,133','Reference differs\nn = 963'])
    ax[1].set(ylabel='Virtual recovery success (%)',ylim=(0,103))
    ax[1].set_title('b  Recorded-reference agreement',loc='left',fontweight='bold')
    handles,labels=ax[0].get_legend_handles_labels()
    fig.legend(handles,labels,frameon=False,fontsize=9,ncol=3,loc='lower center',bbox_to_anchor=(.5,-.01))
    fig.tight_layout(rect=(0,.09,1,1))
    for ext in ['png','pdf','svg']:fig.savefig(out/('FigS2_testbed_diagnostics.'+ext),dpi=240,bbox_inches='tight')
    plt.close(fig)
    print('Fig S2 recreated from aggregate CSVs.')


if __name__=='__main__':main()
