"""Descriptive checks from frozen production-task and episode archives only.

No model fitting, recovery episodes, outcome-based exclusions, or new claims
of physical target reachability. Reference agreement is not a success ceiling.
"""
from pathlib import Path
import hashlib
import os
import json
import sys

import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
OUT=Path(os.environ.get('REFINELAB_DIAGNOSTICS_OUT', str(ROOT/'recomputed_diagnostics')))
A=Path(os.environ.get('REFINELAB_ANALYSIS_DIR', str(ROOT/'analysis')))
TASK=Path(os.environ.get('REFINELAB_FILTERED_ARCHIVE', str(ROOT/'private_filtered_archive')))/'refinelab_v40_frozen_tasks.csv'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    sys.stdout.reconfigure(encoding='utf-8')
    analysis=OUT/'analysis';fig=OUT/'figures'
    analysis.mkdir(parents=True,exist_ok=True);fig.mkdir(parents=True,exist_ok=True)
    files=[TASK,A/'episode_metrics.csv',A/'results_by_equipment_label.csv',A/'archived_model_metrics.csv',A/'configuration_results.csv']
    source_aliases={p: ('restricted_archive/' if p==TASK else 'analysis/')+p.name for p in files}
    hashes={source_aliases[p]:sha(p) for p in files}
    t=pd.read_csv(TASK);e=pd.read_csv(A/'episode_metrics.csv')
    assert len(t)==12096 and t.task_id.is_unique
    err=abs(t.reference_environment_beam-t.target_beam)/t.target_beam
    assert np.allclose(err,t.reference_error_fraction,atol=1e-12)
    t['reference_agrees_5pct']=err.le(.05+1e-12)
    assert t.reference_agrees_5pct.sum()==11133
    assert len(e)==12096*17 and not e.duplicated(['task_id','configuration']).any()
    e=e.merge(t[['task_id','reference_agrees_5pct']],on='task_id',how='left',validate='many_to_one')
    assert e.reference_agrees_5pct.notna().all()
    rows=[]
    for (label,agrees),g in e.groupby(['configuration','reference_agrees_5pct']):
        success=g.success.astype(bool)
        rows.append(dict(configuration=label,reference_agrees_5pct=bool(agrees),n=len(g),
            success_count=int(success.sum()),success_rate=success.mean(),
            successful_mean_measurements=g.loc[success,'total_probes'].mean(),
            successful_mean_rounds=g.loc[success,'total_rounds'].mean(),
            all_task_actual_measurements=g.total_probes.mean(),
            all_task_failure_charged_measurements=g.charged_probes.mean()))
    groups=pd.DataFrame(rows)
    assert groups.groupby('configuration').n.sum().eq(12096).all()
    groups.to_csv(analysis/'reference_agreement_subgroups.csv',index=False,encoding='utf-8-sig')
    paired=[]
    for agrees,g in e.groupby('reference_agrees_5pct'):
        for method,baseline in [('PSO_Res','BO'),('RF_Res','BO'),('RF_Res','PSO_Res')]:
            aa=g[g.configuration.eq(method)].set_index('task_id');bb=g[g.configuration.eq(baseline)].set_index('task_id').loc[aa.index]
            common=aa.success.astype(bool)&bb.success.astype(bool)
            paired.append(dict(reference_agrees_5pct=bool(agrees),method=method,baseline=baseline,n=len(aa),
                success_difference=(aa.success.astype(float)-bb.success.astype(float)).mean(),
                common_success_n=int(common.sum()),
                common_success_measurement_difference=(aa.loc[common,'total_probes']-bb.loc[common,'total_probes']).mean(),
                all_task_failure_charged_difference=(aa.charged_probes-bb.charged_probes).mean()))
    pd.DataFrame(paired).to_csv(analysis/'reference_agreement_paired_descriptive.csv',index=False,encoding='utf-8-sig')
    diag=pd.read_csv(A/'archived_model_metrics.csv')
    diag=diag[diag.model_role.eq('Per-machine SIM')&diag.estimator.eq('XGBoost')].copy()
    diag['group']=pd.to_numeric(diag.machine_id,errors='raise').astype(int)
    per=pd.read_csv(A/'results_by_equipment_label.csv')
    per=per[per.label.isin(['BO','PSO_Res','RF_Res'])]
    diag=diag[diag.group.isin(per.group.unique())]
    assert len(diag)==13 and diag.group.is_unique
    per=per.merge(diag[['group','mape_percent','r2','n_evaluation']],on='group',validate='many_to_one')
    assert len(per)==39 and per.mape_percent.notna().all()
    per.to_csv(analysis/'equipment_success_and_SIM_OOF_error.csv',index=False,encoding='utf-8-sig')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
    names={'BO':'Task-local BO','PSO_Res':'XGBoost + residual PSO','RF_Res':'RF + residual PSO'}
    colors={'BO':'#7b8187','PSO_Res':'#225f85','RF_Res':'#326b53'}
    markers={'BO':'o','PSO_Res':'s','RF_Res':'^'}
    figure,ax=plt.subplots(1,2,figsize=(10,4.1))
    for label in names:
        q=per[per.label.eq(label)]
        ax[0].scatter(q.mape_percent,100*q.success,label=names[label],marker=markers[label],color=colors[label],s=30,alpha=.82)
    ax[0].axvline(5,color='#aaa',ls='--',lw=.8)
    ax[0].set(xlabel='Tool SIM production-point OOF MAPE (%)',ylabel='Virtual recovery success (%)',ylim=(86,101))
    ax[0].set_title('a  Equipment-level diagnostic',loc='left',fontweight='bold')
    xpos=np.array([0,1]);width=.23
    for j,label in enumerate(names):
        q=groups[groups.configuration.eq(label)].set_index('reference_agrees_5pct')
        heights=[100*q.loc[True,'success_rate'],100*q.loc[False,'success_rate']]
        ax[1].bar(xpos+(j-1)*width,heights,width=width,color=colors[label],label=names[label])
    ax[1].set_xticks(xpos,['Reference agrees\nn = 11,133','Reference differs\nn = 963'])
    ax[1].set(ylabel='Virtual recovery success (%)',ylim=(0,103))
    ax[1].set_title('b  Recorded-reference agreement',loc='left',fontweight='bold')
    handles,labels=ax[0].get_legend_handles_labels()
    figure.legend(handles,labels,frameon=False,fontsize=9,ncol=3,loc='lower center',bbox_to_anchor=(.5,-.01))
    figure.tight_layout(rect=(0,.09,1,1))
    for suffix in ['png','pdf','svg']:figure.savefig(fig/('FigS2_testbed_diagnostics.'+suffix),dpi=240,bbox_inches='tight')
    plt.close(figure)
    summary=dict(tasks=12096,reference_agreement_n=11133,reference_disagreement_n=963,
        subgroup_results=groups[groups.configuration.isin(names)].to_dict('records'),
        original_sources_sha256=hashes,source_files_unchanged=all(sha(p)==hashes[source_aliases[p]] for p in files),
        model_fits=0,new_recovery_episodes=0,task_exclusions=0,
        interpretation='Reference-point agreement, not proof of feasible target reachability. Subgroup and tool scatter are descriptive; no causal correlation claim or new inferential interval.')
    (analysis/'diagnostic_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(groups[groups.configuration.isin(names)].to_string(index=False),flush=True)

if __name__=='__main__':main()
